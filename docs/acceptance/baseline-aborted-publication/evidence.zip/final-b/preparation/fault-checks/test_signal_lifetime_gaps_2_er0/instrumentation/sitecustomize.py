import os
from pathlib import Path
from writer_hooks import install
install('error-emit', Path('/private/tmp/bookscan-aborted-publication-gald8g5u/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_er0/barrier.json'))
