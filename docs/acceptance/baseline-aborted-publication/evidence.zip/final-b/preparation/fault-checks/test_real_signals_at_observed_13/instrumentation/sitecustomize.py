import os
from pathlib import Path
from writer_hooks import install
install('after-link', Path('/private/tmp/bookscan-aborted-publication-gald8g5u/final-b/preparation/fault-checks/test_real_signals_at_observed_13/barrier.json'))
