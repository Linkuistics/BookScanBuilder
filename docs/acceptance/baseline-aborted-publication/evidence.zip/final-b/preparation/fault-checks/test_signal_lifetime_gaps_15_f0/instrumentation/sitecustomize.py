import os
from pathlib import Path
from writer_hooks import install
install('finish', Path('/private/tmp/bookscan-aborted-publication-gald8g5u/final-b/preparation/fault-checks/test_signal_lifetime_gaps_15_f0/barrier.json'))
