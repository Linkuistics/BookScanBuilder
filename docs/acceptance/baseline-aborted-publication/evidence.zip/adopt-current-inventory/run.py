import sys,hashlib,json
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-aborted-publication-gald8g5u/adopt-current-inventory/src')
from bookscan import initial_import,assets,native_blobs,import_publications
import pytest
for module in [initial_import,assets,native_blobs,import_publications]:
 p=Path(module.__file__);assert p.is_relative_to(Path('/private/tmp/bookscan-aborted-publication-gald8g5u/adopt-current-inventory/src'))
 print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(["-q",'/Users/antony/Development/BookScanBuilder/tests/test_aborted_publication.py',"--junitxml=/private/tmp/bookscan-aborted-publication-gald8g5u/adopt-current-inventory/tests.xml"]))
