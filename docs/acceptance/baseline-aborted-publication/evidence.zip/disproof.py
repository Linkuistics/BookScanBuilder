"""Copied predecessor and deliberate ownership mistakes; no live product edits."""
import json, shutil, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for case in ['predecessor', 'no-abort-mode-check', 'adopt-current-inventory']:
    root=base/case
    shutil.copytree(base/'before/src' if case=='predecessor' else repo/'src', root/'src',ignore=shutil.ignore_patterns('__pycache__'))
    if case != 'predecessor':
        path=root/'src/bookscan/import_publications.py'
        text=path.read_text()
        a=text.index('    def aborted(');b=text.index('    def completed(',a)
        part=text[a:b]
        if case=='no-abort-mode-check':
            old='if current[:3] != self.directory_stamp[:3]:'
            assert part.count(old)==1
            part=part.replace(old,'if False:')
        else:
            old='self._files_match(directory, self._files)'
            assert part.count(old)==1
            part=part.replace(old,'self._files = {name: stamp(os.stat(name, dir_fd=directory, follow_symlinks=False)) for name in os.listdir(directory)}')
        path.write_text(text[:a]+part+text[b:])
    script=root/'run.py'
    script.write_text('import sys,hashlib,json\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(root/'src'))+')\nfrom bookscan import initial_import,assets,native_blobs,import_publications\nimport pytest\nfor module in [initial_import,assets,native_blobs,import_publications]:\n p=Path(module.__file__);assert p.is_relative_to(Path('+repr(str(root/'src'))+'))\n print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main(["-q",'+repr(str(repo/'tests/test_aborted_publication.py'))+',"--junitxml='+str(root/'tests.xml')+'"]))\n')
    with (root/'run.log').open('wb') as log:
        done=subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT)
    assert done.returncode==1,(case,done.returncode)
    cases=list(ET.parse(root/'tests.xml').iter('testcase'))
    assert len(cases)==32 and not any(c.find('error') is not None for c in cases)
    failed=[c.get('name') for c in cases if c.find('failure') is not None]
    passed=[c.get('name') for c in cases if c.find('failure') is None]
    if case=='predecessor':assert len(failed)==20 and len(passed)==12
    if case=='no-abort-mode-check':assert len(failed)==4
    if case=='adopt-current-inventory':assert len(failed)==4
    rows.append({'case':case,'exit':done.returncode,'failed':failed,'passed':passed})
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'case':r['case'],'failed':len(r['failed']),'passed':len(r['passed'])} for r in rows]))
