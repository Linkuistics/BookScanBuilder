import os
from pathlib import Path
from writer_hooks import install
install('after-link', Path('/private/tmp/bookscan-aborted-publication-gald8g5u/final-a/preparation/fault-checks/test_sigkill_observes_state_an1/barrier.json'))
