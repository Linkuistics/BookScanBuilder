import os
from pathlib import Path
from writer_hooks import install
install('plan-emit', Path('/private/tmp/bookscan-aborted-publication-gald8g5u/final-a/preparation/fault-checks/test_signal_lifetime_gaps_15_p0/barrier.json'))
