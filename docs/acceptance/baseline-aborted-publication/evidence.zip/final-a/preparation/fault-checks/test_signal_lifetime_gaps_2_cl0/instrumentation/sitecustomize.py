import os
from pathlib import Path
from writer_hooks import install
install('cleanup-error', Path('/private/tmp/bookscan-aborted-publication-gald8g5u/final-a/preparation/fault-checks/test_signal_lifetime_gaps_2_cl0/barrier.json'))
