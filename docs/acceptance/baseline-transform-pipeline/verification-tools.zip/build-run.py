import hashlib,importlib.metadata,json,sys,subprocess,sysconfig
from pathlib import Path
root=Path('/Users/antony/Development/BookScanBuilder');out=Path(sys.argv[1]);out.mkdir()
assert importlib.metadata.version('hatchling')=='1.27.0'
subjects={Path(__file__),Path(sys.executable).resolve(),root/'pyproject.toml',root/'uv.lock',root/'README.md',root/'.gitignore'}
subjects|={p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
module_roots=set()
for distribution in importlib.metadata.distributions():
 folder=Path(distribution.locate_file('')).resolve();module_roots.add(str(folder))
 subjects|={p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
subjects|={p for p in Path(sysconfig.get_path('stdlib')).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(subjects)}
a=hashes();r=subprocess.run([sys.executable,'-m','hatchling','build','-t','wheel','--directory',str(out)],cwd=root,capture_output=True,text=True)
(out/'build.stdout').write_text(r.stdout);(out/'build.stderr').write_text(r.stderr);assert r.returncode==0,r.stdout+r.stderr
b=hashes();assert a==b
(out/'build-verification.json').write_text(json.dumps({'read_subjects_before':a,'read_subjects_after':b,'package_roots':sorted(module_roots),'hatchling_version':'1.27.0','exit_code':r.returncode},indent=2)+'\n')
print('Actual build package provenance:',len(a),'subjects',module_roots)
