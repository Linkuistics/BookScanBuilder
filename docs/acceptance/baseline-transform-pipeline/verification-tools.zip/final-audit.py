import gzip,hashlib,json,re,subprocess,zipfile
from pathlib import Path
root=Path('/Users/antony/Development/BookScanBuilder');base=Path('/private/tmp/bookscan-k63-pipeline-work');out=base/'evidence';dest=root/'docs/acceptance/baseline-transform-pipeline'
def sha(data):return hashlib.sha256(data).hexdigest()
def equal(a,b):assert a==b,'Byte/identity mismatch'
try:equal(b'actual',b'altered')
except AssertionError:pass
else:raise AssertionError('Wrong-byte control credited')
paths=subprocess.check_output(['jj','file','list'],cwd=root,text=True).splitlines()
current={p:sha((root/p).read_bytes()) for p in paths}
before=json.loads((base/'before.json').read_text())
changed={p for p in before if before[p]!=current.get(p)}
allowed={'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md','docs/acceptance/baseline-finite.md','Taskfile.yml'}
equal(changed,allowed);assert set(before)<=set(current)
new_code={'tests/pipeline_acceptance.py','tests/transform_pipeline.py','tests/test_transform_pipeline.py','tests/native/transform_pipeline_observer.c','tests/native/lcms2_internal.h'}
assert new_code<=set(current)-set(before)
assert all(p in new_code or p.startswith('docs/acceptance/baseline-transform-pipeline/') for p in set(current)-set(before))
for path in allowed:
 previous=subprocess.check_output(['jj','file','show','-r','9554dcf1',path],cwd=root)
 equal(sha(previous),before[path]);assert (root/path).read_bytes().startswith(previous)
protected=[]
for p in subprocess.check_output(['jj','file','list','-r','@-'],cwd=root,text=True).splitlines():
 if p not in {'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md','Taskfile.yml','pyproject.toml','uv.lock'}:
  equal((root/p).read_bytes(),subprocess.check_output(['jj','file','show','-r','@-',p],cwd=root));protected.append(p)
equal(len(protected),166)
def expand(value):
 if isinstance(value,dict):
  if set(value)=={'$gzip'}:
   ref=value['$gzip'];data=(dest/ref['file']).read_bytes();equal(sha(data),ref['sha256']);return expand(json.loads(gzip.decompress(data)))
  return {k:expand(v) for k,v in value.items()}
 if isinstance(value,list):return [expand(v) for v in value]
 return value
def restored(name,keys):
 value=expand(json.loads(gzip.decompress((dest/name).read_bytes())))
 for key in keys:
  ref=value[key];data=(dest/ref['file']).read_bytes();equal(sha(data),ref['sha256']);value[key]=expand(json.loads(gzip.decompress(data)))
 return value
record=restored('verification.json.gz',['read_subjects_before','read_subjects_after','build_verification'])
equal((json.dumps(record,indent=2)+'\n').encode(),(out/'verification.json').read_bytes())
installed=restored('installed-verification.json.gz',['read_subjects_before','read_subjects_after'])
equal((json.dumps(installed,indent=2)+'\n').encode(),(out/'installed/installed-verification.json').read_bytes())
excluded={str(root/'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'),str(root/'docs/acceptance/baseline-finite.md')}
rehashes={}
for name,subjects in [('primary',record['read_subjects_before']),('builder',record['build_verification']['read_subjects_before']),('installed',installed['read_subjects_before']),('fixture',record['fixture_subjects_before'])]:
 count=0
 for path,expected in subjects.items():
  if path not in excluded:equal(sha(Path(path).read_bytes()),expected);count+=1
 rehashes[name]=count
archive_index=json.loads((dest/'archive-index.json').read_text());members={};retained_sources=set()
for filename,index in archive_index.items():
 with zipfile.ZipFile(dest/filename) as z:
  equal(set(z.namelist()),set(index));equal(len(z.namelist()),len(index))
  members[filename]={}
  for key,source in index.items():
   data=z.read(key);equal(data,Path(source).read_bytes());members[filename][key]=sha(data);retained_sources.add(source)
report_index=json.loads((dest/'report-index.json').read_text())
for source,reference in report_index.items():
 value=expand(json.loads(gzip.decompress((dest/reference['file']).read_bytes())))
 for key in reference['keys']:value=value[key]
 data=(json.dumps(value,indent=2)+'\n').encode();equal(sha(data),reference['sha256']);equal(data,(out/source).read_bytes());retained_sources.add(str(out/source))
for folder in [out/'native-a',out/'native-b',out/'installed/measured',base/'final-fixtures',out/'rebuilt-fixtures']:
 assert all(str(p) in retained_sources for p in folder.rglob('*') if p.is_file())
for repeat in ['a','b']:equal((json.dumps(expand(json.loads(gzip.decompress((dest/f'pipeline-{repeat}.json.gz').read_bytes()))),indent=2)+'\n').encode(),(out/f'native-{repeat}/report.json').read_bytes())
equal((dest/'truth.json').read_bytes(),(base/'final-fixtures/truth.json').read_bytes())
# Independently read every raw final-stage/probe transcript and observed disassembly.
quantization={}
for path in (out/'native-a/capture').glob('*-pipeline.txt'):
 lines=path.read_text().splitlines();equal(lines[0].split()[-1],'3')
 stages=[line for line in lines if line.startswith('stage ')]
 equal([line.split()[2] for line in stages],['1668707188','1835103334','1668707188'])
 probes=[line.split() for line in lines if line.startswith('probe ')]
 equal(len(probes),256)
 for v,line in enumerate(probes):
  equal(int(line[1]),v);equal([int(x) for x in line[5:]],[(int(x)+128)//257 for x in line[2:5]])
 changed=list(probes[0]);changed[-1]=str((int(changed[-1])+1)%256)
 try:equal([int(x) for x in changed[5:]],[(int(x)+128)//257 for x in changed[2:5]])
 except AssertionError:pass
 else:raise AssertionError('Wrong probe credited')
 quantization[path.name]={'sha256':sha(path.read_bytes()),'complete_probes':256,'three_final_stages':stages}
equal(len(quantization),2)
source_header=(root/'tests/native/lcms2_internal.h').read_bytes();equal(source_header,(base/'lcms2_internal.h').read_bytes())
disassembly=(base/'final-fixtures/native-disassembly.txt').read_text();assert 'ldr\tx0, [x19, #0x70]' in disassembly and 'ldr\tx8, [x0, #0x8]' in disassembly
# Read every complete tracked file and every historical archive member directly.
archive_reads={}
for path in paths:
 p=root/path
 if p.suffix=='.gz':
  data=gzip.decompress(p.read_bytes());json.loads(data);archive_reads[path]={'sha256':sha(data),'decoded_bytes':len(data)}
 elif p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:archive_reads[path]={key:sha(z.read(key)) for key in z.namelist()}
missed={p:(root/p).read_text().splitlines()[0] for p in ['docs/design/rotation-processor/baseline-delivery.html','docs/design/rotation-processor/contract.html']}
# Direct source fallback for every newly reported internal-header missed range.
header_lines=(root/'tests/native/lcms2_internal.h').read_text().splitlines()
header_fallback={}
for number in range(1,6):
 raw=json.loads((base/f'coverage-{number}.json').read_text())
 data=raw.get('structuredContent') or json.loads(next(c['text'] for c in raw['content'] if c['type']=='text'))
 for row in data['paths']:
  if row['path']=='tests/native/lcms2_internal.h':
   for gap in row['coverage']:
    for span in gap.get('ranges',[]):
     for line in range(span['start'],span['end']+1):header_fallback[str(line)]=header_lines[line-1]
assert header_fallback
for target in re.findall(r'\]\((baseline-transform-pipeline/[^)]+)\)',(root/'docs/acceptance/baseline-finite.md').read_text()):assert (root/'docs/acceptance'/target).is_file(),target
identity=subprocess.check_output(['jj','log','--no-pager','--no-graph','-r','@','-T','change_id'],cwd=root,text=True)
parent=subprocess.check_output(['jj','log','--no-pager','--no-graph','-r','@-','-T','commit_id'],cwd=root,text=True)
equal(identity,'ryouonnvvlkzyyxmxrpqxnuqrysrqtvy');assert parent.startswith('03eb30ab')
equal(current,{p:sha((root/p).read_bytes()) for p in paths})
result={'before_paths':len(before),'tracked_paths':len(paths),'protected_originals':protected,'allowed_changed_paths':sorted(changed),'new_paths':sorted(set(current)-set(before)),'tracked_digests':current,'rehashes':rehashes,'measurement_excluded_later_prose_only':sorted(excluded),'primary_and_installed_records_byte_exact':True,'zip_members':members,'all_measured_native_and_fixture_files_retained':True,'raw_final_stage_and_probe_binding':quantization,'wrong_byte_and_probe_controls_rejected':True,'archive_reads':archive_reads,'coverage_missed_html_ranges_read':missed,'coverage_missed_header_lines_read':header_fallback,'f_change_id':identity,'parent_commit':parent,'audit_script_sha256':sha(Path(__file__).read_bytes()),'actual_final_pipeline_observed':True,'test_abi_portable':False,'cmm_precision_verified':False,'cairo_fidelity_verified':False,'runtime_resources_verified':False,'accepted_project_delivered':False}
(base/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('AUDITED',len(paths),'tracked files;',len(before),'previous paths preserved;',len(protected),'protected originals; exact archives/all captures/frozen subjects/quantizers/open jj boundary')
