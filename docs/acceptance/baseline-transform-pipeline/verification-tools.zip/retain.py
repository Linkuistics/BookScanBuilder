import gzip,hashlib,json,shutil,zipfile,zlib
from pathlib import Path
base=Path('/private/tmp/bookscan-k63-pipeline-work');out=base/'evidence'
dest=Path('/Users/antony/Development/BookScanBuilder/docs/acceptance/baseline-transform-pipeline');dest.mkdir(exist_ok=True)
previous_archives=json.loads((dest/'archive-index.json').read_text()) if (dest/'archive-index.json').exists() else {}
extra_reports={}
def compressed(name,value):
 original=(json.dumps(value,indent=2)+'\n').encode()
 value=json.loads(original)
 encoded=gzip.compress(original,mtime=0)
 while len(encoded)>800000:
  candidates=[(len(gzip.compress((json.dumps(v,indent=2)+'\n').encode(),mtime=0)),k) for k,v in value.items() if isinstance(v,(dict,list)) and not (isinstance(v,dict) and '$gzip' in v)]
  assert candidates,'No factorable record'
  _,key=max(candidates)
  ref=compressed(name.removesuffix('.json.gz')+'-'+key+'.json.gz',value[key])
  value[key]={'$gzip':ref}
  encoded=gzip.compress((json.dumps(value,indent=2)+'\n').encode(),mtime=0)
 (dest/name).write_bytes(encoded)
 assert (json.dumps(expand(json.loads(gzip.decompress(encoded))),indent=2)+'\n').encode()==original
 return {'file':name,'sha256':hashlib.sha256(encoded).hexdigest()}
def expand(value):
 if isinstance(value,dict):
  if set(value)=={'$gzip'}:
   ref=value['$gzip'];data=(dest/ref['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==ref['sha256']
   return expand(json.loads(gzip.decompress(data)))
  return {k:expand(v) for k,v in value.items()}
 if isinstance(value,list):return [expand(v) for v in value]
 return value
record=json.loads((out/'verification.json').read_text())
original=(out/'verification.json').read_bytes()
record['read_subjects_before']=compressed('primary-subjects.json.gz',record['read_subjects_before'])
record['read_subjects_after']=dict(record['read_subjects_before'])
record['build_verification']=compressed('build-verification.json.gz',record['build_verification'])
compressed('verification.json.gz',record)
installed=json.loads((out/'installed/installed-verification.json').read_text())
installed['read_subjects_before']=compressed('installed-subjects.json.gz',installed['read_subjects_before'])
installed['read_subjects_after']=dict(installed['read_subjects_before'])
compressed('installed-verification.json.gz',installed)
restored=expand(json.loads(gzip.decompress((dest/'verification.json.gz').read_bytes())))
for key in ['read_subjects_before','read_subjects_after','build_verification']:
 ref=restored[key];data=(dest/ref['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==ref['sha256'];restored[key]=json.loads(gzip.decompress(data))
assert (json.dumps(restored,indent=2)+'\n').encode()==original
for repeat in ['a','b']:compressed(f'pipeline-{repeat}.json.gz',json.loads((out/f'native-{repeat}/report.json').read_text()))
shutil.copy(base/'final-fixtures/truth.json',dest/'truth.json')
command_files=[]
for path in out.iterdir():
 if not path.is_file() or path.suffix not in ['.stdout','.stderr','.xml']:continue
 if len(zlib.compress(path.read_bytes()))>700000:
  value=json.loads(path.read_text());ref=compressed('command-'+path.name+'.json.gz',value)
  equal=(json.dumps(value,indent=2)+'\n').encode();assert equal==path.read_bytes()
  extra_reports[str(path.relative_to(out))]={'file':ref['file'],'keys':[],'sha256':hashlib.sha256(equal).hexdigest()}
 else:command_files.append((path,path.name))
archives={
 'failed-intent-diagnostic.zip':[(base/'failed-intent-observer.c','source.c'),(base/'draft-observer.dylib','observer.dylib')]+[(p,'capture/'+p.name) for p in (base/'draft-capture').iterdir() if p.is_file()],
 'fixtures.zip': [(p,'fixtures/'+str(p.relative_to(base/'final-fixtures'))) for p in (base/'final-fixtures').rglob('*') if p.is_file()]+[(p,'rebuilt-fixtures/'+str(p.relative_to(out/'rebuilt-fixtures'))) for p in (out/'rebuilt-fixtures').rglob('*') if p.is_file()]+[(p,'wheel/'+p.name) for p in (out/'wheel').glob('*.whl')],
 'verification-tools.zip':[(base/n,n) for n in ['verify.py','installed-run.py','build-run.py','preparation_semantics.py','before.json','retain.py','lcms2.h','lcms2_plugin.h','cmsxform.c','cmsopt.c','cmscnvrt.c','cmslut.c','lcms2_internal.h','failed-intent-observer.c','final-audit.py','coverage-1.json','coverage-2.json','coverage-3.json','coverage-4.json','coverage-5.json']]+[(p,'runners/'+p.name) for p in (out/'installed/runners').iterdir() if p.is_file()],
 'command-records.zip':command_files+[(out/f'prepare-{r}/report.json',f'prepare-{r}-report.json') for r in ['a','b']]+[(out/'installed/units.xml','installed-units.xml')]+[(out/'installed/units.stdout','installed-units.stdout')]
}
report_index=dict(extra_reports)
for name,folder,ref,key in [('native-a-captures.zip','native-a','pipeline-a.json.gz',[]),('native-b-captures.zip','native-b','pipeline-b.json.gz',[]),('installed-captures.zip','installed/measured','installed-verification.json.gz',['report'])]:
 paths=[p for p in (out/folder).rglob('*') if p.is_file()]
 archives[name]=[(p,folder+'/'+str(p.relative_to(out/folder))) for p in paths if p.name!='report.json']
 for source in [p for p in paths if p.name=='report.json']:
  keys=key+['legacy']*source.relative_to(out/folder).parts.count('legacy')
  record=expand(json.loads(gzip.decompress((dest/ref).read_bytes())))
  for entry in keys:record=record[entry]
  restored=(json.dumps(record,indent=2)+'\n').encode()
  assert restored==source.read_bytes()
  report_index[str(source.relative_to(out))]={'file':ref,'keys':keys,'sha256':hashlib.sha256(restored).hexdigest()}
(dest/'report-index.json').write_text(json.dumps(report_index,indent=2)+'\n')
archives['verification-tools.zip'] += [(Path('/Users/antony/Development/BookScanBuilder/tests/native')/n,'native/'+n) for n in ['profile_memory_observer.c','target_observer.c','transform_formatter_observer.c','transform_pipeline_observer.c','lcms2_internal.h']]
archive_index={}
for name,members in archives.items():
 chunks=[];chunk=[];size=0
 for path,key in members:
  estimate=len(zlib.compress(path.read_bytes()))+len(key)*2+200
  if chunk and size+estimate>800000:chunks.append(chunk);chunk=[];size=0
  chunk.append((path,key));size+=estimate
 if chunk:chunks.append(chunk)
 for number,chunk in enumerate(chunks,1):
  actual=name if len(chunks)==1 else name.removesuffix('.zip')+f'-{number:02d}.zip'
  with zipfile.ZipFile(dest/actual,'w',zipfile.ZIP_DEFLATED) as z:
   for path,key in chunk:z.writestr(key,path.read_bytes())
  with zipfile.ZipFile(dest/actual) as z:
   assert len(z.namelist())==len(chunk)
   for path,key in chunk:assert z.read(key)==path.read_bytes()
  archive_index[actual]={key:str(path) for path,key in chunk}
(dest/'archive-index.json').write_text(json.dumps(archive_index,indent=2)+'\n')
for name in previous_archives:
 if name not in archive_index:(dest/name).unlink()
assert all(p.stat().st_size<1048576 for p in dest.iterdir())
print('Retained exact measured record, captures/ICC/PNG/wheel/tools/commands:',{p.name:p.stat().st_size for p in dest.iterdir()})
