import json,re
from pathlib import Path
def normalize(value,folder):
    if isinstance(value,dict): return {k:normalize(v,folder) for k,v in value.items() if k != 'pid'}
    if isinstance(value,list): return [normalize(v,folder) for v in value]
    if isinstance(value,str): return re.sub(r'\.bookscan-prepare-[0-9a-f]{32}\.tmp',
                                            '<OWNED_PRIVATE_NAME>',value.replace(str(folder),'<RUN>'))
    return value
def pages(report,folder):
    return {case['case']:[{'output_page':p['output_page'],'source':Path(p['source']).name,
        'source_page':p['source_page'],'role':p['role'],'geometry':p['geometry'],
        'raw_streams':p['raw_streams'],'renders':normalize(p['renders'],folder)}
        for p in case['pages']] for case in report['cases']}
def faults(report,folder):
    rows = {}
    for item in report['fault_checks']['observed_signal_and_kill_cases']:
        assert item['pid'] == item['observed_barrier']['pid'] and item['writer_reaped'] and item['source_unchanged']
        key = json.dumps([item['hook'],item.get('dry_run',False),item['signal'],item.get('signals_sent',1)])
        assert key not in rows; rows[key] = normalize(item,folder)
    return rows
