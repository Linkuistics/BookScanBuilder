/* Test child only. Public intent callback; no private transform ABI. */
#include <lcms2_plugin.h>
#include <dlfcn.h>
#define __attribute__(x)
#include "profile_memory_observer.c"
#undef __attribute__

static _Thread_local cmsHPROFILE wanted_input, wanted_target;
static _Thread_local cmsPipeline *linked_pipeline;
static _Thread_local unsigned link_count;
static _Thread_local cmsUInt32Number linked_intents[2];
static _Thread_local cmsBool linked_bpc[2];
static _Thread_local cmsFloat64Number linked_adaptation[2];

static cmsPipeline *observed_intent(cmsContext context, cmsUInt32Number count,
        cmsUInt32Number intents[], cmsHPROFILE profiles[], cmsBool bpc[],
        cmsFloat64Number adaptation[], cmsUInt32Number flags) {
    /* The actual built-in intent table references this public plugin callback.
       Observe its real return, never build a replacement or register a plugin.
       https://raw.githubusercontent.com/mm2/Little-CMS/lcms2.19.1/src/cmscnvrt.c */
    cmsPipeline *result = _cmsDefaultICCintents(context, count, intents, profiles, bpc,
                                               adaptation, flags);
    if (wanted_input && count == 2 && profiles[0] == wanted_input
        && profiles[1] == wanted_target && flags == 8448) {
        linked_pipeline = result;
        link_count++;
        for (unsigned i = 0; i < 2; i++) {
            linked_intents[i] = intents[i]; linked_bpc[i] = bpc[i];
            linked_adaptation[i] = adaptation[i];
        }
    }
    return result;
}

static void final_pipeline(unsigned seq, cmsHTRANSFORM transform,
                           cmsHPROFILE input, cmsHPROFILE target) {
    /* Under these exact NOOPTIMIZE flags, PreOptimize simplifies in place, but
       no pipeline replacement optimization runs. Read AFTER transform creation.
       https://raw.githubusercontent.com/mm2/Little-CMS/lcms2.19.1/src/cmsopt.c
       https://raw.githubusercontent.com/mm2/Little-CMS/lcms2.19.1/src/cmsxform.c */
    cmsPipeline *lut = linked_pipeline;
    if (link_count != 1 || lut == NULL || cmsPipelineInputChannels(lut) != 3
        || cmsPipelineOutputChannels(lut) != 3) _exit(111);
    FILE *file = reserve(seq, "pipeline.txt");
    fprintf(file, "pipeline-v1 %d %u %" PRIuPTR " %u %u %u %u %" PRIuPTR " %u\n",
        getpid(), seq, (uintptr_t)transform, cmsGetTransformInputFormat(transform),
        cmsGetTransformOutputFormat(transform), _cmsGetTransformFlags(transform),
        cmsGetEncodedCMMversion(), (uintptr_t)lut, cmsPipelineStageCount(lut));
    fprintf(file, "link %" PRIuPTR " %" PRIuPTR " %u %u %d %d %a %a\n",
        (uintptr_t)input, (uintptr_t)target, linked_intents[0], linked_intents[1],
        linked_bpc[0], linked_bpc[1], linked_adaptation[0], linked_adaptation[1]);
    unsigned index = 0;
    for (cmsStage *stage = cmsPipelineGetPtrToFirstStage(lut); stage;
         stage = cmsStageNext(stage), index++) {
        if (cmsStageInputChannels(stage) != 3 || cmsStageOutputChannels(stage) != 3)
            _exit(112);
        fprintf(file, "stage %u %u 3 3\n", index, cmsStageType(stage));
        /* Public plugin stage-data structures, not transform/pipeline internals.
           https://raw.githubusercontent.com/mm2/Little-CMS/lcms2.19.1/include/lcms2_plugin.h */
        if (cmsStageType(stage) == cmsSigMatrixElemType) {
            const _cmsStageMatrixData *data = cmsStageData(stage);
            if (!data || !data->Double) _exit(113);
            fprintf(file, "matrix %d", data->Offset != NULL);
            for (unsigned i = 0; i < 9; i++) fprintf(file, " %a", data->Double[i]);
            for (unsigned i = 0; i < 3; i++)
                fprintf(file, " %a", data->Offset ? data->Offset[i] : 0.0);
            fprintf(file, "\n");
        } else if (cmsStageType(stage) == cmsSigCurveSetElemType) {
            const _cmsStageToneCurvesData *data = cmsStageData(stage);
            if (!data || data->nCurves != 3 || !data->TheCurves) _exit(114);
            for (unsigned c = 0; c < 3; c++) {
                const cmsToneCurve *curve = data->TheCurves[c];
                const cmsCurveSegment *s = cmsGetToneCurveSegment(0, curve);
                if (!s || cmsGetToneCurveSegment(1, curve)
                    || s->Type != cmsGetToneCurveParametricType(curve)) _exit(115);
                fprintf(file, "curve %u %d %a %a", c, s->Type, (double)s->x0, (double)s->x1);
                for (unsigned i = 0; i < 10; i++) fprintf(file, " %a", s->Params[i]);
                fprintf(file, "\n");
            }
        } else _exit(116);
    }
    if (index != cmsPipelineStageCount(lut)) _exit(117);
    for (unsigned v = 0; v < 256; v++) {
        cmsUInt8Number source[3] = {v, 255-v, (v*73)%256}, actual[3];
        cmsUInt16Number words[3], result[3];
        for (unsigned c = 0; c < 3; c++) words[c] = source[c]*257;
        cmsPipelineEval16(words, result, lut);
        cmsDoTransform(transform, source, actual, 1);
        fprintf(file, "probe %u %u %u %u %u %u %u\n", v, result[0], result[1], result[2],
            actual[0], actual[1], actual[2]);
    }
    if (ferror(file) || fclose(file)) _exit(118);
    Dl_info info;
    if (!dladdr((const void *)_cmsDefaultICCintents, &info) || !info.dli_fname || !info.dli_fbase)
        _exit(119);
    file = reserve(seq, "link-pipeline-module.txt");
    fprintf(file, "module-v1 %d %u link %" PRIuPTR " %" PRIuPTR "\n%s\n",
        getpid(), seq, (uintptr_t)_cmsDefaultICCintents, (uintptr_t)info.dli_fbase, info.dli_fname);
    if (ferror(file) || fclose(file)) _exit(120);
}

static cmsHTRANSFORM pipeline_transform(cmsHPROFILE input, cmsUInt32Number in,
        cmsHPROFILE target, cmsUInt32Number out, cmsUInt32Number intent, cmsUInt32Number flags) {
    (void)hooks;
    int selected = (in == 262169 || in == 25) && out == 262169;
    if (selected) {
        if (flags != 8448 || intent != 1 || wanted_input) _exit(121);
        wanted_input = input; wanted_target = target; linked_pipeline = NULL; link_count = 0;
    }
    cmsHTRANSFORM result = observed_transform(input, in, target, out, intent, flags);
    if (selected) {
        if (!result) _exit(122);
        final_pipeline(atomic_load(&sequence), result, input, target);
        wanted_input = NULL; wanted_target = NULL; linked_pipeline = NULL;
    }
    return result;
}

__attribute__((used, section("__DATA,__interpose")))
static const struct { const void *replacement; const void *original; } pipeline_hooks[] = {
    { (const void *)observed_srgb, (const void *)cmsCreate_sRGBProfile },
    { (const void *)pipeline_transform, (const void *)cmsCreateTransform },
    { (const void *)observed_intent, (const void *)_cmsDefaultICCintents }
};
