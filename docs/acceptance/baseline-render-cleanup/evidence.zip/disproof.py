"""Run checked copied predecessor and isolating guard mutations, never live edits."""
import hashlib,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent;repo=Path.cwd();rows=[]
for label in ['predecessor','no-native-file-core','no-post-native-stamp','no-root-stamp-inventory','no-empty-root-mode']:
 folder=base/'controls-final'/label;shutil.copytree(repo/'src',folder/'src',ignore=shutil.ignore_patterns('__pycache__'))
 path=folder/'src/bookscan/render_workspace.py';text=path.read_text();selection=''
 if label=='predecessor':
  path=folder/'src/bookscan/render.py';path.write_bytes((base/'before/src/bookscan/render.py').read_bytes())
  selection='native_boundary_preserves or decode_boundary_preserves or unchanged_output_cleanup'
 elif label=='no-native-file-core':
  old='stamp(held)[:4] != self.file_stamp[:4]';assert text.count(old)==1;path.write_text(text.replace(old,'False'))
 elif label=='no-post-native-stamp':
  for old in ['                or stamp(os.fstat(self.descriptor)) != self.file_stamp\n','                or stamp(self.path.lstat()) != self.file_stamp\n']:
   assert text.count(old)==1;text=text.replace(old,'')
  old='"page.png", matches=lambda entry: stamp(entry) == self.file_stamp';assert text.count(old)==1
  path.write_text(text.replace(old,'"page.png", matches=lambda entry: True'))
 elif label=='no-root-stamp-inventory':
  old='                stamp(self.reservation.path.lstat()) != self.directory_stamp\n                or {p.name for p in self.reservation.path.iterdir()} != {"page.png"}\n                or stamp(os.fstat(self.descriptor)) != self.file_stamp\n';assert text.count(old)==1
  text=text.replace(old,'                stamp(os.fstat(self.descriptor)) != self.file_stamp\n')
  for old in ['                    or stamp(self.reservation.path.lstat()) != self.directory_stamp\n','                    or {p.name for p in self.reservation.path.iterdir()} != {"page.png"}\n']:
   assert text.count(old)==1;text=text.replace(old,'')
  path.write_text(text)
 else:
  old='if root[:3] != self.directory_stamp[:3] or list(self.reservation.path.iterdir()):';assert text.count(old)==1
  path.write_text(text.replace(old,'if list(self.reservation.path.iterdir()):'))
 args=['-q',str(repo/'tests/test_render_cleanup.py'),'--junitxml='+str(folder/'tests.xml')]
 if selection:args+=['-k',selection]
 script=folder/'run.py';script.write_text('import sys,hashlib,json\nfrom pathlib import Path\n'+'sys.path.insert(0,'+repr(str(folder/'src'))+')\nfrom bookscan import render,render_workspace\nimport pytest\nfor module in [render,render_workspace]:\n p=Path(module.__file__);assert p.is_relative_to(Path('+repr(str(folder/'src'))+'))\n print(json.dumps({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main('+repr(args)+'))\n')
 with (folder/'run.log').open('wb') as stream:done=subprocess.run([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT)
 assert done.returncode==1,(label,done.returncode)
 cases=list(ET.parse(folder/'tests.xml').iter('testcase'));assert cases and not any(c.find('error') is not None for c in cases)
 failed=[c.get('name') for c in cases if c.find('failure') is not None];passed=[c.get('name') for c in cases if c.find('failure') is None]
 rows.append({'case':label,'mutated':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'failed':failed,'passed':passed})
 print(label,len(failed),len(passed),flush=True)
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
