import sys,hashlib,json
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-render-cleanup-work/controls-final/predecessor/src')
from bookscan import render,render_workspace
import pytest
for module in [render,render_workspace]:
 p=Path(module.__file__);assert p.is_relative_to(Path('/private/tmp/bookscan-render-cleanup-work/controls-final/predecessor/src'))
 print(json.dumps({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(['-q', '/Users/antony/Development/BookScanBuilder/tests/test_render_cleanup.py', '--junitxml=/private/tmp/bookscan-render-cleanup-work/controls-final/predecessor/tests.xml', '-k', 'native_boundary_preserves or decode_boundary_preserves or unchanged_output_cleanup']))
