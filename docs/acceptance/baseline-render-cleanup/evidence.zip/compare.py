"""Validate the paired per-item records before normalizing run-specific identity."""
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text())

def outcomes(path):
    result = {}
    for case in ET.parse(path).iter('testcase'):
        key = case.get('classname')+'::'+case.get('name')
        assert key not in result, ('duplicate case', key)
        tags = [v.tag for v in case if v.tag in {'error','failure','skipped'}]
        result[key] = tags or ['passed']
    assert result and all(v == ['passed'] for v in result.values()), str(path)
    return result

def normal(value, run, key=''):
    if isinstance(value, dict):
        result = {normal(k, run):normal(v, run, k) for k,v in value.items()}
        assert len(result) == len(value), 'Normalized keys collided'
        return result
    if isinstance(value, list):
        return [normal(v, run, key) for v in value]
    if key in {'writer_pid','pid'}:
        assert type(value) is int and value > 0
        return '<positive-pid>'
    if isinstance(value, str):
        value = value.replace(str(run), '<run>')
        return re.sub(r'\.bookscan-prepare-[a-f0-9]{32}\.tmp', '.bookscan-prepare-<uuid>.tmp', value)
    return value

def checked_workers(run):
    folder=run/'source-workers'
    report=read(folder/'report.json')
    result=[]
    assert len(report['cases']) == 40
    for case in report['cases']:
        record=read(folder/(case['id']+'.json'))
        assert case == record['reading']
        event=record['event']
        assert case['writer_pid'] == event['writer_pid'] and case['writer_pid'] > 0
        project=folder/case['id']
        header=read(project/'project.json')
        assert header == event['header']
        info=(project/'project.json').stat()
        assert header['header'] == {'device':info.st_dev,'inode':info.st_ino}
        info=project.stat()
        assert (header['lock']['project_device'],header['lock']['project_inode']) == (info.st_dev,info.st_ino)
        for key,name in [('assets','assets'),('checkpoints','checkpoints'),('native_blobs','native-blobs')]:
            info=(project/name).stat()
            assert header[key] == {'device':info.st_dev,'inode':info.st_ino}
        info=(project/'writer.lock').stat()
        assert (header['lock']['lock_device'],header['lock']['lock_inode']) == (info.st_dev,info.st_ino)
        digest=case['checkpoint_sha256']
        if digest is not None:
            raw=(project/'checkpoints'/(digest+'.json')).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == digest
            assert (project/'checkpoints/current').readlink().name == digest+'.json'
        else:
            assert not (project/'checkpoints/current').is_symlink()
        source=event['source']
        source_path=project/'source.pdf'
        source_raw=source_path.read_bytes()
        assert hashlib.sha256(source_raw).hexdigest() == source['source_sha256'] == case['source_sha256']
        info=source_path.stat()
        assert source['snapshot_identity'] == {'device':info.st_dev,'inode':info.st_ino,'size':info.st_size,
                                               'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns}
        assert not Path(source['original_path']).exists() and case['original_missing'] is True
        assert [p['source_pdf_page'] for p in source['pages']] == [1,2,3]
        assert [p['geometry']['pixels'] for p in source['pages']] == [[300,150],[150,300],[300,150]]
        if digest:
            saved=json.loads(raw)
            assert saved['checkpoint_revision'] == case['revision']
            assert saved['state']['source'] == source
            assert saved['state']['baseline'] == event['reference']
            assert saved['state']['note'] == ('next' if case['committed'] else 'first')
        pattern=rb'/ID\s*\[\s*<[0-9a-fA-F]{32}>\s*<[0-9a-fA-F]{32}>\s*\]'
        assert len(re.findall(pattern,source_raw)) == 1
        source_normal=re.sub(pattern,b'/ID[<generated><generated>]',source_raw)
        copied=dict(case)
        copied['source_sha256'] = hashlib.sha256(source_normal).hexdigest()
        copied['checkpoint_sha256'] = '<verified-sha256>' if digest else None
        copied['source_pages'] = source['pages']
        copied['source_document'] = source['document']
        result.append(normal(copied,run))
    return {'truth':report['truth'],'cases':result}

def input_identity(path, run):
    raw=path.read_bytes()
    if path.is_relative_to(run/'preparation'):
        # The generated input PDFs differ only in their generated trailer ID.
        # Preserve/verify raw file digests separately; never normalize page bytes.
        pattern=rb'/ID\s*\[\s*<[0-9a-fA-F]{32}>\s*<[0-9a-fA-F]{32}>\s*\]'
        assert path.suffix == '.pdf' and len(re.findall(pattern,raw)) <= 1
        raw=re.sub(pattern,b'/ID[<generated><generated>]',raw)
    return hashlib.sha256(raw).hexdigest()

def checked_preparation(run):
    report=read(run/'preparation/report.json')
    assert report['digests_before'] == report['digests_after']
    for path,digest in report['digests_before'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
    assert len(report['cases']) == 9
    evidence=report['fault_checks']['observed_signal_and_kill_cases']
    assert len(evidence) == 38
    return {
        'cases':normal(report['cases'],run),
        'signals':normal(evidence,run),
        'faults':outcomes(run/'preparation/fault-checks.xml'),
        'inputs':normal({path:input_identity(Path(path), run) for path in report['digests_before']},run),
        'versions':report['versions'],
    }

def checked_assets(run):
    from PIL import Image
    folder=run/'asset-workers'
    report=read(folder/'result.json')
    assert len(report['records'])==8
    assert report['product_sha256']==hashlib.sha256(Path(report['product']).read_bytes()).hexdigest()
    rows={}
    for record in report['records']:
        key=record['case'];assert key not in rows
        event=record['barrier'];assert event['writer_pid']>0 and event['phase']==key.rsplit('-',1)[0]
        project=folder/key
        info=project.stat();lock=event['lock']
        assert (lock['project_device'],lock['project_inode'])==(info.st_dev,info.st_ino)
        info=(project/'writer.lock').stat()
        assert (lock['lock_device'],lock['lock_inode'])==(info.st_dev,info.st_ino)
        info=(project/'assets').stat()
        assert event['directory']=={'device':info.st_dev,'inode':info.st_ino}
        reference=event['reference']
        for name in record['visible_after']:
            raw=(project/'assets'/name).read_bytes()
            assert hashlib.sha256(raw).hexdigest()==reference['png_sha256']
            with Image.open(project/'assets'/name) as image:
                assert image.mode=='RGB' and list(image.size)==report['truth']['size']
                assert image.tobytes().hex()==report['truth']['rgb_hex']
        for name in record['private_names']:assert re.fullmatch(r'\.rgb-[0-9a-f]{32}',name)
        rows[key]={k:record[k] for k in ['exit','visible_before','visible_after','immediate_reacquisition','checkpoint']}
        rows[key]['private_count']=len(record['private_names'])
        rows[key]['reference']=reference
    return {'truth':report['truth'],'records':rows}

def checked_native(run):
    from PIL import Image
    folder=run/'native';report=read(folder/'report.json')
    fields=read(root/'native-prior.json')['per_case']
    assert {k:report[k] for k in fields}==fields
    assert report['public_finite_delivery'] is False and report['composition_fidelity_verified'] is False
    state=report['state'];project=folder/'project'
    raw=(project/'checkpoints'/(report['checkpoint_sha256']+'.json')).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==report['checkpoint_sha256']
    assert json.loads(raw)['state']==state
    assert (project/'checkpoints/current').readlink().name==report['checkpoint_sha256']+'.json'
    assert hashlib.sha256((project/'source.pdf').read_bytes()).hexdigest()==state['source']['source_sha256']
    digests=[]
    for record,occurrence in zip(state['baselines'],state['occurrences'],strict=True):
        path=project/'assets'/(record['id']+'.png');raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==record['png_sha256'] and len(raw)==record['png_size']
        with Image.open(path) as image:
            assert image.mode=='RGB' and list(image.size)==record['size']
            digest=hashlib.sha256(image.tobytes()).hexdigest()
        assert digest==record['rgb_sha256']==occurrence['rgb_sha256']
        digests.append(digest)
    assert digests==report['baseline_sha256'] and len(digests)==7
    return fields


def checked_render(run):
    report=read(run/'native-render/report.json')
    assert report['all_exact_workspaces_removed'] is True and report['public_create_delivered'] is False
    construction=report['construction']
    assert len(construction['pages'])==14 and len(construction['controls'])==10
    writes=[]
    for row in report['native_writes']:
        before,after=row['file_before'],row['file_after']
        assert before[:4]==after[:4] and before[3]==1 and before[4]==0 and after[4]>0
        assert before[2]&0o170000==0o100000 and before[2]&0o777==0o600
        assert row['exit_code']==0 and not Path(row['command'][-1]).parent.exists()
        command=list(row['command']);command[-1]='<verified-private-prefix>'
        writes.append({'command':normal(command,run),'png_size':after[4],'mode':before[2]})
    assert len(writes)==16
    return {'construction':normal(construction,run),'writes':writes}

def main():
    a,b=(root/'final-a',root/'final-b')
    assert read(a/'subjects-before.json') == read(a/'subjects-after.json')
    assert read(a/'subjects-before.json') == read(b/'subjects-before.json')
    assert read(b/'subjects-before.json') == read(b/'subjects-after.json')
    counts={}
    for name in ['focused','product','staff']:
        first,second=outcomes(a/(name+'.xml')),outcomes(b/(name+'.xml'))
        assert first == second
        counts[name]=len(first)
    pa,pb=checked_preparation(a),checked_preparation(b)
    assert pa == pb, 'Preparation item mismatch'
    wa,wb=checked_workers(a),checked_workers(b)
    assert wa == wb, 'Worker item mismatch'
    aa,ab=checked_assets(a),checked_assets(b)
    assert aa==ab
    na,nb=checked_native(a),checked_native(b)
    assert na==nb
    ra,rb=checked_render(a),checked_render(b)
    assert ra==rb, 'Native renderer item mismatch'
    summary={'native_render_writes':len(ra['writes']), 'native_render_cases':len(ra['construction']['pages']), 'native_render_controls':len(ra['construction']['controls']),'asset_worker_cases':len(aa['records']),'native_occurrences':len(na['baseline_sha256']),'paired_test_outcomes':counts,'preparation_cases':len(pa['cases']),
             'preparation_faults':len(pa['faults']),'preparation_signal_records':len(pa['signals']),
             'source_workers':len(wa['cases']),
             'frozen_subjects':len(read(a/'subjects-before.json')),'passed':True}
    (root/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__ == "__main__":
    main()
