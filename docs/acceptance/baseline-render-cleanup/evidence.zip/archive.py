"""Retain measured subjects and outputs without chmod or following symlinks."""
import hashlib
import json
import os
import stat
import zipfile
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path.cwd()
out = repo / 'docs/acceptance/baseline-render-cleanup'

archive = out / 'evidence.zip'
entries = []
unreadable = []
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for path in sorted(base.rglob('*')):
        if '__pycache__' in path.parts:
            continue
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        rel = path.relative_to(base).as_posix()
        if stat.S_ISLNK(info.st_mode):
            raw = os.fsencode(os.readlink(path))
            kind = 'symlink'
        elif stat.S_ISREG(info.st_mode):
            try:
                raw = path.read_bytes()
            except PermissionError:
                unreadable.append({'path':rel,'mode':info.st_mode,'size':info.st_size})
                continue
            kind = 'file'
        else:
            raise AssertionError('Unexpected archive member: ' + rel)
        item = zipfile.ZipInfo(rel)
        item.create_system = 3
        item.external_attr = info.st_mode << 16
        item.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(item,raw)
        entries.append({'path':rel,'kind':kind,'mode':info.st_mode,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
index = {'format':'BookScanBuilderRenderCleanupEvidence','version':1,
         'archive':'evidence.zip','archive_size':archive.stat().st_size,
         'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
         'members':entries,'unreadable':unreadable,
         'repository_root':str(repo),'measurement_root':str(base),'comparison':json.loads((base/'comparison.json').read_text())}
(out / 'index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'size':index['archive_size'],'sha256':index['archive_sha256'],'members':len(entries),'unreadable':unreadable},indent=2))
