"""Challenge actual comparison readers without altering measured files."""
import copy
import hashlib
import json
from pathlib import Path

root=Path('/private/tmp/bookscan-bootstrap-close-kwms8lo0')
source=(root/'compare.py').read_text()
original_hash=hashlib.sha256(source.encode()).hexdigest()
results=[]
for name in ['source-digest','preparation-case','worker-commit','missing-test']:
    ns={'__name__':'comparison_control'}
    exec(compile(source,str(root/'compare.py'),'exec'),ns)
    original_read=ns['read']
    original_outcomes=ns['outcomes']
    hit=[]
    def read(path):
        value=copy.deepcopy(original_read(path))
        if name in {'source-digest','preparation-case'} and path==root/'final-b/preparation/report.json':
            if name=='source-digest':
                key=next(iter(value['digests_before']))
                value['digests_before'][key]='0'*64
                value['digests_after'][key]='0'*64
            else:
                value['cases'][0]['expected_order']=['wrong-page']
            hit.append(str(path))
        elif name=='worker-commit' and path==root/'final-b/header-workers/report.json':
            value['cases'][0]['committed']=not value['cases'][0]['committed']
            hit.append(str(path))
        return value
    def outcomes(path):
        value=original_outcomes(path)
        if name=='missing-test' and path==root/'final-b/product.xml':
            value.pop(next(iter(value)))
            hit.append(str(path))
        return value
    ns['read']=read
    ns['outcomes']=outcomes
    try:
        ns['main']()
    except AssertionError:
        assert len(hit)==1, (name,hit)
        results.append({'control':name,'rejected':True,'path':hit[0]})
    else:
        raise RuntimeError('Wrong record was accepted: '+name)
assert hashlib.sha256((root/'compare.py').read_bytes()).hexdigest()==original_hash
for name in ['predecessor','ignore-parent','ignore-store-activity','inode-only-header']:
    folder=root/'final-disproof'/name
    first=json.loads((folder/'run.log').read_text().splitlines()[0])
    module=folder/'src/bookscan/project_header.py'
    assert first=={'module':str(module),'sha256':hashlib.sha256(module.read_bytes()).hexdigest()}
record={'comparator_sha256_before':original_hash,'comparator_sha256_after':original_hash,
        'controls':results,'copied_module_identities_verified':True}
(root/'comparison-controls.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
