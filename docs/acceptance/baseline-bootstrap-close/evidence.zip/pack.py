"""Retain ordinary ZIP evidence with explicit inaccessible-output metadata."""
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

root=Path('/private/tmp/bookscan-bootstrap-close-kwms8lo0')
folder=Path('/Users/antony/Development/BookScanBuilder/docs/acceptance/baseline-bootstrap-close')
members={}
unreadable=[]
paths=[]
for directory,dirs,files in os.walk(root):
    dirs[:]=sorted(d for d in dirs if d not in {'__pycache__','.cache','.pytest_cache'})
    paths.extend(Path(directory)/name for name in sorted(files) if not name.endswith('.pyc'))
with zipfile.ZipFile(folder/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(paths):
        name=path.relative_to(root).as_posix()
        info=path.lstat()
        try:
            raw=os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
        except PermissionError:
            unreadable.append({'path':name,'mode':info.st_mode,'device':info.st_dev,'inode':info.st_ino,'size':info.st_size,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns})
            continue
        entry=zipfile.ZipInfo(name)
        entry.create_system=3
        entry.external_attr=info.st_mode<<16
        entry.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(entry,raw)
        members[name]={'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'kind':'symlink' if stat.S_ISLNK(info.st_mode) else 'file'}
        after=os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
        assert raw==after, name
index={'archive':'evidence.zip','archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest(),'measurement_root':str(root),'members':members,'unreadable_generated_files':unreadable}
(folder/'index.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
print(json.dumps({'members':len(members),'zip_bytes':(folder/'evidence.zip').stat().st_size,'unreadable_outputs':len(unreadable)},indent=2))
