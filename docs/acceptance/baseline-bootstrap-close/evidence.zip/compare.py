"""Validate the paired per-item records before normalizing run-specific identity."""
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path('/private/tmp/bookscan-bootstrap-close-kwms8lo0')

def read(path):
    return json.loads(path.read_text())

def outcomes(path):
    result = {}
    for case in ET.parse(path).iter('testcase'):
        key = case.get('classname')+'::'+case.get('name')
        assert key not in result, ('duplicate case', key)
        tags = [v.tag for v in case if v.tag in {'error','failure','skipped'}]
        result[key] = tags or ['passed']
    assert result and all(v == ['passed'] for v in result.values()), str(path)
    return result

def normal(value, run, key=''):
    if isinstance(value, dict):
        result = {normal(k, run):normal(v, run, k) for k,v in value.items()}
        assert len(result) == len(value), 'Normalized keys collided'
        return result
    if isinstance(value, list):
        return [normal(v, run, key) for v in value]
    if key in {'writer_pid','pid'}:
        assert type(value) is int and value > 0
        return '<positive-pid>'
    if isinstance(value, str):
        value = value.replace(str(run), '<run>')
        return re.sub(r'\.bookscan-prepare-[a-f0-9]{32}\.tmp', '.bookscan-prepare-<uuid>.tmp', value)
    return value

def checked_workers(run):
    folder=run/'header-workers'
    report=read(folder/'report.json')
    result=[]
    assert len(report['cases']) == 40
    for case in report['cases']:
        record=read(folder/(case['id']+'.json'))
        assert case == record['reading']
        event=record['event']
        assert case['writer_pid'] == event['writer_pid'] and case['writer_pid'] > 0
        project=folder/case['id']
        header=read(project/'project.json')
        assert header == event['header']
        info=(project/'project.json').stat()
        assert header['header'] == {'device':info.st_dev,'inode':info.st_ino}
        info=project.stat()
        assert (header['lock']['project_device'],header['lock']['project_inode']) == (info.st_dev,info.st_ino)
        for key,name in [('assets','assets'),('checkpoints','checkpoints'),('native_blobs','native-blobs')]:
            info=(project/name).stat()
            assert header[key] == {'device':info.st_dev,'inode':info.st_ino}
        info=(project/'writer.lock').stat()
        assert (header['lock']['lock_device'],header['lock']['lock_inode']) == (info.st_dev,info.st_ino)
        digest=case['checkpoint_sha256']
        if digest is not None:
            raw=(project/'checkpoints'/(digest+'.json')).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == digest
            assert (project/'checkpoints/current').readlink().name == digest+'.json'
        else:
            assert not (project/'checkpoints/current').is_symlink()
        copied=dict(case)
        copied['checkpoint_sha256'] = '<verified-sha256>' if digest else None
        result.append(normal(copied,run))
    return {'truth':report['truth'],'cases':result}

def input_identity(path, run):
    raw=path.read_bytes()
    if path.is_relative_to(run/'preparation'):
        # The generated input PDFs differ only in their generated trailer ID.
        # Preserve/verify raw file digests separately; never normalize page bytes.
        pattern=rb'/ID\s*\[\s*<[0-9a-fA-F]{32}>\s*<[0-9a-fA-F]{32}>\s*\]'
        assert path.suffix == '.pdf' and len(re.findall(pattern,raw)) <= 1
        raw=re.sub(pattern,b'/ID[<generated><generated>]',raw)
    return hashlib.sha256(raw).hexdigest()

def checked_preparation(run):
    report=read(run/'preparation/report.json')
    assert report['digests_before'] == report['digests_after']
    for path,digest in report['digests_before'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
    assert len(report['cases']) == 9
    evidence=report['fault_checks']['observed_signal_and_kill_cases']
    assert len(evidence) == 38
    return {
        'cases':normal(report['cases'],run),
        'signals':normal(evidence,run),
        'faults':outcomes(run/'preparation/fault-checks.xml'),
        'inputs':normal({path:input_identity(Path(path), run) for path in report['digests_before']},run),
        'versions':report['versions'],
    }

def main():
    a,b=(root/'final-a',root/'final-b')
    assert read(a/'subjects-before.json') == read(a/'subjects-after.json')
    assert read(a/'subjects-before.json') == read(b/'subjects-before.json')
    assert read(b/'subjects-before.json') == read(b/'subjects-after.json')
    counts={}
    for name in ['focused','product','staff']:
        first,second=outcomes(a/(name+'.xml')),outcomes(b/(name+'.xml'))
        assert first == second
        counts[name]=len(first)
    pa,pb=checked_preparation(a),checked_preparation(b)
    assert pa == pb, 'Preparation item mismatch'
    wa,wb=checked_workers(a),checked_workers(b)
    assert wa == wb, 'Worker item mismatch'
    summary={'paired_test_outcomes':counts,'preparation_cases':len(pa['cases']),
             'preparation_faults':len(pa['faults']),'preparation_signal_records':len(pa['signals']),
             'header_workers':len(wa['cases']),
             'frozen_subjects':len(read(a/'subjects-before.json')),'passed':True}
    (root/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__ == "__main__":
    main()
