import os
from pathlib import Path
from writer_hooks import install
install('pending', Path('/private/tmp/bookscan-bootstrap-close-kwms8lo0/final-b/preparation/fault-checks/test_real_signals_at_observed_10/barrier.json'))
