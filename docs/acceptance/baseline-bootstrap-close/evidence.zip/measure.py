"""Run final paired checks against explicitly frozen filesystem read subjects."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

repo = Path('/Users/antony/Development/BookScanBuilder')
root = Path('/private/tmp/bookscan-bootstrap-close-kwms8lo0')

def digest(path):
    info = path.lstat()
    value = {'mode': info.st_mode, 'device': info.st_dev, 'inode': info.st_ino,
             'size': info.st_size, 'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns}
    if path.is_symlink():
        value['target'] = os.readlink(path)
        if path.is_file():
            value['resolved_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    else:
        value['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    return value

def subjects():
    paths = set()
    roots = [repo/'src', repo/'tests', repo/'experiments', repo/'.venv', Path(sys.base_prefix),
             Path('/Users/antony/.cache/uv/environments-v2')]
    # uv's isolated --no-project environment is ephemeral; record it separately.
    staff = json.loads((root/'staff-environment.json').read_text())
    roots.pop()
    roots.append(Path(staff['base_prefix']))
    for tree in roots:
        if not tree.is_dir():
            raise RuntimeError('Missing frozen tree: '+str(tree))
        for directory, dirs, files in os.walk(tree):
            dirs[:] = [d for d in dirs if d not in {'__pycache__', '.pytest_cache', '.ruff_cache'}]
            for name in files:
                if name.endswith('.pyc'):
                    continue
                p = Path(directory)/name
                if p.is_file() or p.is_symlink():
                    paths.add(p)
    for name in ['Taskfile.yml', 'pyproject.toml', 'uv.lock', 'README.md', 'CONTEXT.md',
                 '.grove/_BRIEF.md', '.grove/40-k47/_page-review.md',
                 '.grove/40-k47/01-k53/_baseline-review.md',
                 '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md']:
        paths.add(repo/name)
    for tree in [repo/'docs/specs', repo/'docs/adr']:
        paths.update(tree.rglob('*.*'))
    for name in ['measure.py', 'disproof.py', 'compare.py', 'staff-environment.json']:
        paths.add(root/name)
    for tool in ['task', 'uv', 'pdftoppm', 'pdftotext']:
        selected = Path(shutil.which(tool))
        paths.add(selected)
        paths.add(selected.resolve())
    return {str(p): digest(p) for p in sorted(paths)}

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

for label in ['a', 'b']:
    run = root/('final-'+label)
    run.mkdir()
    before = subjects()
    write(run/'subjects-before.json', before)
    commands = [
        ('focused', ['task', 'process:bootstrap-close-check']),
        ('product', ['task', 'prepare:check']),
        ('staff', ['task', 'geometry:staff-check']),
        ('preparation', ['task', 'prepare:acceptance', 'MODE=synthetic', 'ARTIFACTS='+str(run/'preparation')]),
        ('header-workers', ['task', 'process:header-acceptance', 'ARTIFACTS='+str(run/'header-workers')]),
    ]
    results = []
    for name, command in commands:
        env = dict(os.environ)
        if name in {'focused', 'product', 'staff'}:
            env['PYTEST_ADDOPTS'] = '--junitxml='+str(run/(name+'.xml'))
        start = time.monotonic()
        with (run/(name+'.log')).open('w') as stream:
            result = subprocess.run(command, cwd=repo, env=env, stdout=stream, stderr=subprocess.STDOUT)
        results.append({'name':name, 'command':command, 'exit_code':result.returncode,
                        'seconds':time.monotonic()-start})
        write(run/'commands.json', results)
        print(label, name, result.returncode, round(time.monotonic()-start, 2), flush=True)
        if result.returncode:
            raise RuntimeError('Command failed: '+name+' see '+str(run/(name+'.log')))
    after = subjects()
    write(run/'subjects-after.json', after)
    assert before == after, 'Frozen inputs changed in '+label
    print(label, 'unchanged subjects', len(before), flush=True)
