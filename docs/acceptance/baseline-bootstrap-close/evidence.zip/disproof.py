import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

repo = Path('/Users/antony/Development/BookScanBuilder')
root = Path('/private/tmp/bookscan-bootstrap-close-kwms8lo0')
current = (repo / 'src/bookscan/project_header.py').read_text()
start = current.index('def _rollback_closed_bootstrap(')
end = current.index('\n\nclass Stores:', start)
block = current[start:end]
variants = {
    'predecessor': (root / 'before/src/bookscan/project_header.py').read_text(),
    'ignore-parent': current[:start] + block.replace('if _native(os.fstat(parent)) != original_parent:', 'if False:', 1) + current[end:],
    'ignore-store-activity': current[:start] + block.replace('        _unchanged_stores(directory, created)\n', '', 1) + current[end:],
    'inode-only-header': current[:start] + block.replace('return _stamp(entry) == saved.stamp', 'return (entry.st_dev, entry.st_ino) == saved.stamp[:2]', 1) + current[end:],
}
for name, source in variants.items():
    target = root / 'final-disproof' / name
    shutil.copytree(repo / 'src', target / 'src', ignore=shutil.ignore_patterns('__pycache__'))
    (target / 'tests').mkdir()
    shutil.copy2(repo / 'tests/test_bootstrap_close.py', target / 'tests/test_bootstrap_close.py')
    module = target / 'src/bookscan/project_header.py'
    module.write_text(source)
    env = dict(os.environ, PYTHONPATH=str(target/'src'), PYTHONDONTWRITEBYTECODE='1')
    code = "import bookscan.project_header as m, pathlib, hashlib, json, pytest; p=pathlib.Path(m.__file__); print(json.dumps({'module':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True); raise SystemExit(pytest.main(['-q','tests/test_bootstrap_close.py','--junitxml=outcomes.xml','-o','cache_dir=.cache']))"
    with (target / 'run.log').open('w') as output:
        result = subprocess.run([str(repo / '.venv/bin/python'), '-c', code], cwd=target, env=env, stdout=output, stderr=subprocess.STDOUT)
    assert result.returncode == 1, (name, result.returncode)
    assert hashlib.sha256(module.read_bytes()).hexdigest() == hashlib.sha256(source.encode()).hexdigest()
    print(name, (target / 'run.log').read_text().splitlines()[-1], flush=True)
