"""Verify the advancing F change without sealing, retiring or changing another task."""

import copy
import gzip
import hashlib
import io
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path('/Users/antony/Development/BookScanBuilder')
HERE = ROOT / 'docs/acceptance/baseline-source'
BASE = '9d17b25ef7e30f44bdeaf5f8b0f854166287ff74'
TASK = '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'
EXPECTED = {
    TASK, 'Taskfile.yml', 'docs/acceptance/baseline-finite.md',
    'src/bookscan/intake.py', 'src/bookscan/source_record.py',
    'tests/checkpoint_acceptance.py', 'tests/checkpoint_worker.py', 'tests/test_source_record.py',
    *('docs/acceptance/baseline-source/' + name for name in (
        'verify.py', 'controls.py', 'controls-result.json', 'index.json.gz',
        'boundary.py.gz', 'boundary-result.json',
        *(f'raw-{number:03}.zippart' for number in range(5))
    ))
}


def jj(*arguments):
    return subprocess.check_output(['jj', *arguments, '--no-pager'], cwd=ROOT, text=True)


def validate(facts):
    assert facts['change'] == 'ryouonnvvlkzyyxmxrpqxnuqrysrqtvy'
    assert facts['parent'] == '03eb30abe1ae485696e5deec25bfb229a42ecf69'
    assert facts['description'] == ''
    assert facts['paths'] == EXPECTED
    assert facts['live'] and facts['index'] and not facts['conflicts']


def main():
    index = json.loads(gzip.decompress((HERE / 'index.json.gz').read_bytes()))
    encoded = b''.join((HERE / row['name']).read_bytes() for row in index['parts'])
    with zipfile.ZipFile(io.BytesIO(encoded)) as archive:
        def read(name):
            entry = index['entries'][name]
            data = archive.read('blobs/' + entry['sha256'])
            assert hashlib.sha256(data).hexdigest() == entry['sha256']
            return data

        for prefix, path in (
            ('task', TASK), ('acceptance', 'docs/acceptance/baseline-finite.md')
        ):
            assert (ROOT / path).read_bytes().startswith(read('prefix/' + prefix + '-before'))
        prior_recipe = read('prefix/Taskfile-before')
        recipe = (ROOT / 'Taskfile.yml').read_bytes()
        addition = b'''  process:source-acceptance:
    desc: Verify saved sole-PDF meaning and source-loss restart at actual checkpoint writer barriers
    requires:
      vars: [ARTIFACTS]
    cmds:
      - uv run --locked python tests/checkpoint_acceptance.py --source --artifacts {{.ARTIFACTS | shellQuote}} {{if .PYTHON}}--python {{.PYTHON | shellQuote}}{{end}}

'''
        assert recipe.count(addition) == 1 and recipe.replace(addition, b'') == prior_recipe
        assert recipe == read('contract/Taskfile.yml')
        for name in index['entries']:
            if name.startswith('product/'):
                assert (ROOT / 'src' / name.removeprefix('product/')).read_bytes() == read(name)
            if name.startswith('tests/'):
                assert (ROOT / name).read_bytes() == read(name)
        controls = json.loads((HERE / 'controls-result.json').read_bytes())
        assert controls['unchanged'] and {c['control'] for c in controls['controls']} == {'unit', 'source', 'commit'}
        assert all(c['refused'] and c['exit_code'] == 1 for c in controls['controls'])
        for name, digest in controls['subjects'].items():
            assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == digest
    facts = {
        'change': jj('log', '-r', '@', '--no-graph', '-T', 'change_id').strip(),
        'parent': jj('log', '-r', '@-', '--no-graph', '-T', 'commit_id').strip(),
        'description': jj('log', '-r', '@', '--no-graph', '-T', 'description'),
        'conflicts': jj('log', '-r', '@ & conflicts()', '--no-graph', '-T', 'commit_id').strip(),
        'paths': set(jj('diff', '--from', BASE, '--name-only').splitlines()),
        'live': (ROOT / TASK).is_file(),
        'index': (HERE / 'index.json.gz').is_file(),
    }
    validate(facts)
    refused = []
    for key, value in (
        ('change', 'wrong'), ('parent', 'wrong'), ('description', 'partial sealing'),
        ('paths', EXPECTED | {'foreign.py'}), ('live', False), ('index', False), ('conflicts', 'wrong')
    ):
        wrong = copy.deepcopy(facts)
        wrong[key] = value
        try:
            validate(wrong)
        except AssertionError:
            refused.append(key)
        else:
            raise ValueError('Broken boundary predicate: ' + key)
    print(json.dumps({'change': facts['change'], 'parent': facts['parent'],
                      'paths': sorted(facts['paths']), 'refused_controls': refused,
                      'notes_prefixes': True, 'frozen_product_tests_recipe': True,
                      'live_unsealed': True, 'verified': True}, sort_keys=True))


if __name__ == '__main__':
    main()
