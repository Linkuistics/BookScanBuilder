import gzip,hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path('/Users/antony/Development/BookScanBuilder')
HERE=Path('/private/tmp/bookscan-k63-analysis.KJLDIB')
CORPUS=ROOT/'docs/acceptance/baseline-analysis-record'
TASK='.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'
CHANGE='ryouonnvvlkzyyxmxrpqxnuqrysrqtvy'
START='becda7d74e4038ad341ecfd7739487ec29037351'
PARENT='03eb30abe1ae485696e5deec25bfb229a42ecf69'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def jj(*args):return subprocess.check_output(['jj','--no-pager',*args],cwd=ROOT,text=True)
def require(facts):
    assert facts['change']==CHANGE,'wrong task-owned change'
    assert facts['parent']==PARENT,'wrong parent or partial sealing'
    assert facts['description']=='','partial description/sealing'
    assert not facts['conflicts'],'unresolved conflicts'
    assert facts['live'],'terminal or missing mandated leaf'
    assert facts['paths']==expected,'foreign or missing changed path'
    assert facts['index'],'missing corpus index'
expected={TASK,'Taskfile.yml','docs/acceptance/baseline-finite.md','src/bookscan/analysis_record.py','src/bookscan/assessment.py','tests/test_analysis_record.py','tests/test_assessment.py'}
expected|={'docs/acceptance/baseline-analysis-record/'+name for name in ('verify.py','controls.py','controls-result.json','index.json.gz','boundary.py.gz','boundary-result.json',*(f'raw-{n:03d}.zippart' for n in range(6)))}
text=jj('log','-r','@','--no-graph','-T','change_id ++ "\\n" ++ commit_id ++ "\\n" ++ description').splitlines()
change,current=text[:2];description='\n'.join(text[2:])
facts={'change':change,'parent':jj('log','-r','@-','--no-graph','-T','commit_id').strip(),'description':description,'conflicts':bool(jj('log','-r','@ & conflicts()','--no-graph','-T','commit_id').strip()),'live':[p.relative_to(ROOT).as_posix() for p in (ROOT/'.grove').rglob('*-k63.md')]==[TASK],'paths':{line[2:] for line in jj('diff','--from',START,'--summary').splitlines()},'index':(CORPUS/'index.json.gz').is_file()}
require(facts)
controls=[]
for key,value in [('change','wrong'),('parent','wrong'),('description','partial'),('conflicts',True),('live',False),('paths',set()),('index',False)]:
    try:require({**facts,key:value})
    except AssertionError:controls.append(key)
    else:raise AssertionError('broken boundary predicate: '+key)
assert gzip.decompress((CORPUS/'boundary.py.gz').read_bytes())==Path(__file__).read_bytes()
subjects=json.loads(gzip.decompress((HERE/'frozen/subjects-before.json.gz').read_bytes()))
notes={str(ROOT/TASK),str(ROOT/'docs/acceptance/baseline-finite.md')}
observed={}
for name,saved in subjects.items():
    path=Path(name);raw=os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
    observed[name]=sha(raw)
    if name in notes:
        frozen=(HERE/'before'/path.relative_to(ROOT)).read_bytes()
        assert raw.startswith(frozen),'earlier note bytes replaced'
        # All bytes present at the frozen run must remain a prefix too.
        # These are retained directly in the ordinary evidence archive.
        import io,zipfile
        index=json.loads(gzip.decompress((CORPUS/'index.json.gz').read_bytes()))
        encoded=b''.join((CORPUS/p['name']).read_bytes() for p in index['parts'])
        with zipfile.ZipFile(io.BytesIO(encoded)) as archive:
            key='contracts/grove/'+path.name if path.name.startswith('11-') else 'contracts/docs/acceptance/baseline-finite.md'
            if path.name.startswith('11-'):key='contracts/grove/'+str(path.relative_to(ROOT/'.grove'))
            prefix=archive.read('blobs/'+index['entries'][key]['sha256'])
        assert sha(prefix)==saved['sha256'] and raw.startswith(prefix),'frozen note prefix replaced'
    else:
        assert (sha(raw),len(raw))==(saved['sha256'],saved['size']),name
# Re-read every current subject after boundary validation; the result is output.
for name,digest in observed.items():
    p=Path(name); raw=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
    assert sha(raw)==digest,name
result={'verified':True,'change':change,'commit':current,'parent':facts['parent'],'from_commit':START,'changed_paths':sorted(expected),'preserved_frozen_subjects':len(subjects)-len(notes),'append_only_notes':sorted(notes),'predicate_controls_refused':controls,'boundary_sha256':sha(Path(__file__).read_bytes()),'live_leaf':TASK,'retired':False,'sealed':False,'current_subjects_unchanged':True}
print(json.dumps(result,indent=2))
