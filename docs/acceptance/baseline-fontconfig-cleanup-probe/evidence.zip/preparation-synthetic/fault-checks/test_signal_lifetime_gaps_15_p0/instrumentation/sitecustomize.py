import os
from pathlib import Path
from writer_hooks import install
install('plan-emit', Path('/private/tmp/bookscan-k63-fontconfig-cleanup-diagnostic/preparation-synthetic/fault-checks/test_signal_lifetime_gaps_15_p0/barrier.json'))
