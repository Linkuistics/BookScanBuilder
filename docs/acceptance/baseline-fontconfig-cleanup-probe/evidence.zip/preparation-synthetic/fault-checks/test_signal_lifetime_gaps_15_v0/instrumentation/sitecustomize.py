import os
from pathlib import Path
from writer_hooks import install
install('validation', Path('/private/tmp/bookscan-k63-fontconfig-cleanup-diagnostic/preparation-synthetic/fault-checks/test_signal_lifetime_gaps_15_v0/barrier.json'))
