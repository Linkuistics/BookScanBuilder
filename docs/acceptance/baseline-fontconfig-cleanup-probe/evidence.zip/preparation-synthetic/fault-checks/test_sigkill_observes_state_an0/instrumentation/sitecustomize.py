import os
from pathlib import Path
from writer_hooks import install
install('writing', Path('/private/tmp/bookscan-k63-fontconfig-cleanup-diagnostic/preparation-synthetic/fault-checks/test_sigkill_observes_state_an0/barrier.json'))
