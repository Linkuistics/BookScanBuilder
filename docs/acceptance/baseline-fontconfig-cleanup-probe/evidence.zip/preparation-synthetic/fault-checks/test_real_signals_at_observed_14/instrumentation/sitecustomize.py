import os
from pathlib import Path
from writer_hooks import install
install('committed', Path('/private/tmp/bookscan-k63-fontconfig-cleanup-diagnostic/preparation-synthetic/fault-checks/test_real_signals_at_observed_14/barrier.json'))
