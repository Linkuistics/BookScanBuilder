import os
from pathlib import Path
from writer_hooks import install
install('error-emit', Path('/private/tmp/bookscan-k63-fontconfig-cleanup-diagnostic/preparation-synthetic/fault-checks/test_signal_lifetime_gaps_2_er0/barrier.json'))
