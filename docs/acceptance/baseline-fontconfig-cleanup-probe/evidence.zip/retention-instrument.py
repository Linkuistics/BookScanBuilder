"""Retain this diagnostic's exact ordinary files and symlink spellings."""

import hashlib
import json
import os
import stat
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path("/Users/antony/Development/BookScanBuilder")
DESTINATION = REPO / "docs/acceptance/baseline-fontconfig-cleanup-probe"
members: list[dict[str, object]] = []
unreadable: list[dict[str, object]] = []
paths: dict[str, Path] = {}
for relative in ("final", "preparation-synthetic"):
    root = ROOT / relative
    for path in sorted(root.rglob("*")):
        paths[
            str(path.relative_to(ROOT)) + ("/" if path.is_dir() and not path.is_symlink() else "")
        ] = path
for name in ("staff.log", "preparation-synthetic.log", "controls.xml", "diagnostic-initial.xml"):
    paths[name] = ROOT / name
for name in ("fccache.c", "fcatomic.c", "fcint.h", "fccfg.c", "native-symbols.txt"):
    paths["native/" + name] = ROOT / name
paths["native/fontconfig.h"] = Path(
    "/opt/homebrew/Cellar/fontconfig/2.18.3/include/fontconfig/fontconfig.h"
)
for path in sorted((REPO / "src").rglob("*")):
    if path.is_file() and "__pycache__" not in path.parts:
        paths["subjects/" + str(path.relative_to(REPO))] = path
for relative in (
    "Taskfile.yml",
    "pyproject.toml",
    "uv.lock",
    "docs/acceptance/baseline-fontconfig-cleanup-probe/measure.py",
    "docs/acceptance/baseline-fontconfig-cleanup-probe/preservation_cases.py",
):
    paths["subjects/" + relative] = REPO / relative
paths["Taskfile.before.yml"] = ROOT / "Taskfile.before.yml"
paths["changed-paths.txt"] = ROOT / "changed-paths.txt"
paths["retention-instrument.py"] = ROOT / "retain.py"
paths["content-reader.py"] = ROOT / "verify.py"
archive_path = DESTINATION / "evidence.zip"
with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(paths.items()):
        metadata = path.lstat()
        if stat.S_ISLNK(metadata.st_mode):
            raw = os.fsencode(os.readlink(path))
        elif stat.S_ISDIR(metadata.st_mode):
            raw = b""
        else:
            try:
                raw = path.read_bytes()
            except PermissionError:
                if not name.startswith("preparation-synthetic/fault-checks/"):
                    raise
                # Preserve the deliberately unreadable permission-fault outputs
                # without chmod, invented bytes or a silent archive omission.
                unreadable.append(
                    {"path": name, "mode": metadata.st_mode, "size": metadata.st_size}
                )
                continue
        info = zipfile.ZipInfo(name)
        info.create_system = 3
        info.external_attr = metadata.st_mode << 16
        archive.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED)
        members.append(
            {
                "path": name,
                "sha256": hashlib.sha256(raw).hexdigest(),
                "size": len(raw),
                "mode": metadata.st_mode,
            }
        )
raw = archive_path.read_bytes()
index = {
    "archive_sha256": hashlib.sha256(raw).hexdigest(),
    "archive_size": len(raw),
    "members": members,
    "unreadable_preparation_fault_outputs": unreadable,
    "official_sources": {
        name: "https://raw.githubusercontent.com/fontconfig/fontconfig/2.18.3/src/" + name
        for name in ("fccache.c", "fcatomic.c", "fcint.h", "fccfg.c")
    },
    "exploratory_diagnostic": (
        "diagnostic-initial.xml is invalid: source changed during execution; "
        "its counts are not evidence"
    ),
    "limitation": (
        "Content verification cannot establish historical native inode identity "
        "or execution independently of the recorded observations."
    ),
}
(DESTINATION / "index.json").write_text(json.dumps(index, indent=2, sort_keys=True) + "\n")
print(json.dumps({"size": len(raw), "members": len(members), "sha256": index["archive_sha256"]}))
