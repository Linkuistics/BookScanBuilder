import copy
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT=Path('/Users/antony/Development/BookScanBuilder')
BASE=ROOT/'docs/acceptance/baseline-header'
HERE=Path('/private/tmp/bookscan-header.LyKiUU')
index=json.loads(gzip.decompress((BASE/'index.json.gz').read_bytes()))
raw=b''.join((BASE/p['name']).read_bytes() for p in index['parts'])
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    blobs={name.removeprefix('blobs/'):z.read(name) for name in z.namelist()}

def read(name):
    return blobs[index['entries'][name]['sha256']]

def sha(raw): return hashlib.sha256(raw).hexdigest()

controls=[]
for kind in ('unit','header','commit'):
    changed=copy.deepcopy(index)
    replacements={}
    if kind=='unit':
        name='frozen/gate-a.xml'
        payload=read(name).replace(b'<testcase ',b'<testcase INVALID="truth" ',1)
        # A well-formed pass-count-preserving JUnit changes one stable identity.
        payload=payload.replace(b'name="test_',b'name="wrong_test_',1)
    elif kind=='header':
        name='frozen/header-source-a/initial-assets-complete-0/project.json'
        record=json.loads(read(name))
        record['header']['inode']+=1
        payload=json.dumps(record).encode()
    else:
        name='frozen/header-source-a/report.json'
        record=json.loads(read(name))
        record['cases'][0]['committed']=False
        payload=json.dumps(record).encode()
    replacements[name]=payload
    digest=sha(payload)
    changed['entries'][name]['sha256']=digest
    changed['entries'][name]['size']=len(payload)
    edited_blobs=dict(blobs)
    edited_blobs[digest]=payload
    retained={row['sha256'] for row in changed['entries'].values()}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for key in sorted(retained): z.writestr('blobs/'+key,edited_blobs[key])
    encoded=buffer.getvalue()
    scratch=HERE/('wrong-'+kind)
    scratch.mkdir()
    shutil.copyfile(BASE/'verify.py',scratch/'verify.py')
    parts=[]
    for number,offset in enumerate(range(0,len(encoded),900000)):
        data=encoded[offset:offset+900000]
        part=f'raw-{number:03}.zippart'
        (scratch/part).write_bytes(data)
        parts.append({'name':part,'size':len(data),'sha256':sha(data)})
    changed['parts']=parts
    changed['archive_size']=len(encoded)
    changed['archive_sha256']=sha(encoded)
    raw_index=gzip.compress(json.dumps(changed,sort_keys=True).encode(),mtime=0)
    (scratch/'index.json.gz').write_bytes(raw_index)
    result=subprocess.run([sys.executable,str(scratch/'verify.py')],capture_output=True,text=True)
    assert result.returncode!=0 and ('ValueError' in result.stderr or 'KeyError' in result.stderr),kind
    log=kind+'-refusal.txt'
    (BASE/log).write_text(result.stdout+result.stderr)
    (BASE/(kind+'-control-index.json.gz')).write_bytes(raw_index)
    controls.append({'kind':kind,'deltas':{name:payload.decode()},'exit_code':result.returncode,'refusal':log,'valid_repacked_index':kind+'-control-index.json.gz'})
(BASE/'control-deltas.json.gz').write_bytes(gzip.compress(json.dumps({'controls':controls},sort_keys=True).encode(),mtime=0))
shutil.copyfile(Path(__file__),BASE/'controls.py')
print(json.dumps({'valid_repacked_wrong_readings_refused':[c['kind'] for c in controls]}))
