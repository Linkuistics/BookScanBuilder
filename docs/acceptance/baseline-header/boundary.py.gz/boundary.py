import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT=Path('/Users/antony/Development/BookScanBuilder')
HERE=Path('/private/tmp/bookscan-header.LyKiUU')
start='9a41a71d7f036802710ab5ba26a92061b38d26c3'

def jj(*args):
 return subprocess.check_output(['jj',*args],cwd=ROOT,text=True).strip()
paths=set(jj('diff','--from',start,'--to','@','--name-only','--no-pager').splitlines())
base={'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md','Taskfile.yml','docs/acceptance/baseline-finite.md','src/bookscan/project_header.py','tests/checkpoint_worker.py','tests/checkpoint_acceptance.py','tests/test_project_header.py'}
corpus={'index.json.gz','verify.py','reconstruct-controls.py','control-deltas.json.gz','control-zip-metadata.json.gz','controls.py.gz','boundary.py.gz','boundary-result.json'}
corpus|={f'raw-{number:03}.zippart' for number in range(5)}
corpus|={kind+'-'+suffix for kind in ('unit','header','commit') for suffix in ('control-index.json.gz','refusal.txt')}
expected=base|{'docs/acceptance/baseline-header/'+name for name in corpus}
change=jj('log','-r','@','--no-graph','--no-pager','-T','change_id')
parent=jj('log','-r','@-','--no-graph','--no-pager','-T','commit_id')
description=jj('log','-r','@','--no-graph','--no-pager','-T','description')
conflicts=jj('log','-r','conflicts() & @','--no-graph','--no-pager','-T','commit_id')
task=ROOT/'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'

def correct(change,parent,description,paths,index_exists,live):
 return change=='ryouonnvvlkzyyxmxrpqxnuqrysrqtvy' and parent=='03eb30abe1ae485696e5deec25bfb229a42ecf69' and not description and paths==expected and index_exists and live
assert correct(change,parent,description,paths,(ROOT/'docs/acceptance/baseline-header/index.json.gz').exists(),task.exists()) and not conflicts
for wrong in (
 ('foreign',parent,description,paths,True,True),
 (change,'foreign',description,paths,True,True),
 (change,parent,'partial sealing',paths,True,True),
 (change,parent,description,paths|{'other-leaf.md'},True,True),
 (change,parent,description,paths,False,True),
 (change,parent,description,paths,True,False),
): assert not correct(*wrong)
for path,prefix in [(task,HERE/'task-before.md'),(ROOT/'docs/acceptance/baseline-finite.md',HERE/'acceptance-before.md')]:
 assert path.read_bytes().startswith(prefix.read_bytes()),path
subjects=json.loads(gzip.decompress((HERE/'frozen/subjects-before.json.gz').read_bytes()))
for name in ('src/bookscan/project_header.py','tests/checkpoint_worker.py','tests/checkpoint_acceptance.py','tests/test_project_header.py','Taskfile.yml','pyproject.toml','uv.lock'):
 path=ROOT/name
 assert hashlib.sha256(path.read_bytes()).hexdigest()==subjects[str(path)]['sha256'],name
old=(HERE/'Taskfile-before.yml').read_text()
new=(ROOT/'Taskfile.yml').read_text()
added='''  process:header-acceptance:
    desc: Verify saved native header identities and complete checkpoint history on actual writer restart
    requires:
      vars: [ARTIFACTS]
    cmds:
      - uv run --locked python tests/checkpoint_acceptance.py --header --artifacts {{.ARTIFACTS | shellQuote}} {{if .PYTHON}}--python {{.PYTHON | shellQuote}}{{end}}

'''
assert new.replace(added,'')==old
print(json.dumps({'exact_changed_paths':len(paths),'same_change':change,'same_parent':parent,'empty_description':True,'live_leaf':True,'no_conflicts':True,'prefixes_preserved':True,'measured_operated_bytes_match':True,'wrong_boundaries_refused':6}))
