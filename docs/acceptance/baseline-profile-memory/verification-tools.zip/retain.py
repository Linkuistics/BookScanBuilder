import gzip,hashlib,json,shutil,zipfile
from pathlib import Path
base=Path('/private/tmp/bookscan-k63-memory-work');out=base/'evidence'
dest=Path('/Users/antony/Development/BookScanBuilder/docs/acceptance/baseline-profile-memory');dest.mkdir(exist_ok=True)
def compressed(name,value):
 data=(json.dumps(value,indent=2)+'\n').encode();encoded=gzip.compress(data,mtime=0)
 (dest/name).write_bytes(encoded);assert gzip.decompress(encoded)==data
 return {'file':name,'sha256':hashlib.sha256(encoded).hexdigest()}
record=json.loads((out/'verification.json').read_text())
original=(out/'verification.json').read_bytes()
record['read_subjects_before']=compressed('primary-subjects.json.gz',record['read_subjects_before'])
record['read_subjects_after']=dict(record['read_subjects_before'])
record['build_verification']=compressed('build-verification.json.gz',record['build_verification'])
compressed('verification.json.gz',record)
compressed('installed-verification.json.gz',json.loads((out/'installed/installed-verification.json').read_text()))
restored=json.loads(gzip.decompress((dest/'verification.json.gz').read_bytes()))
for key in ['read_subjects_before','read_subjects_after','build_verification']:
 ref=restored[key];data=(dest/ref['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==ref['sha256'];restored[key]=json.loads(gzip.decompress(data))
assert (json.dumps(restored,indent=2)+'\n').encode()==original
for repeat in ['a','b']:compressed(f'memory-{repeat}.json.gz',json.loads((out/f'native-{repeat}/report.json').read_text()))
shutil.copy(base/'final-fixtures/truth.json',dest/'truth.json')
archives={
 'fixtures.zip': [(p,'fixtures/'+str(p.relative_to(base/'final-fixtures'))) for p in (base/'final-fixtures').rglob('*') if p.is_file()]+[(p,'rebuilt-fixtures/'+str(p.relative_to(out/'rebuilt-fixtures'))) for p in (out/'rebuilt-fixtures').rglob('*') if p.is_file()]+[(p,'wheel/'+p.name) for p in (out/'wheel').glob('*.whl')],
 'verification-tools.zip':[(base/n,n) for n in ['verify.py','installed-run.py','build-run.py','preparation_semantics.py','before.json','retain.py','lcms2.h','cmsgamma.c','cmsvirt.c','cmsio0.c']]+[(p,'runners/'+p.name) for p in (out/'installed/runners').iterdir() if p.is_file()],
 'command-records.zip':[(p,p.name) for p in out.iterdir() if p.is_file() and p.suffix in ['.stdout','.stderr','.xml']]+[(out/f'prepare-{r}/report.json',f'prepare-{r}-report.json') for r in ['a','b']]+[(out/'installed/units.xml','installed-units.xml')]+[(out/'installed/units.stdout','installed-units.stdout')]
}
report_index={}
for name,folder,ref,key in [('native-a-captures.zip','native-a','memory-a.json.gz',[]),('native-b-captures.zip','native-b','memory-b.json.gz',[]),('installed-captures.zip','installed/measured','installed-verification.json.gz',['report'])]:
 paths=[p for p in (out/folder).rglob('*') if p.is_file()]
 archives[name]=[(p,folder+'/'+str(p.relative_to(out/folder))) for p in paths if p.name!='report.json']
 for source in [p for p in paths if p.name=='report.json']:
  keys=key+(['legacy'] if source.parent.name=='legacy' else [])
  record=json.loads(gzip.decompress((dest/ref).read_bytes()))
  for entry in keys:record=record[entry]
  restored=(json.dumps(record,indent=2)+'\n').encode()
  assert restored==source.read_bytes()
  report_index[str(source.relative_to(out))]={'file':ref,'keys':keys,'sha256':hashlib.sha256(restored).hexdigest()}
(dest/'report-index.json').write_text(json.dumps(report_index,indent=2)+'\n')
archives['verification-tools.zip'] += [(Path('/Users/antony/Development/BookScanBuilder/tests/native')/n,'native/'+n) for n in ['profile_memory_observer.c','target_observer.c']]
for name,members in archives.items():
 with zipfile.ZipFile(dest/name,'w',zipfile.ZIP_DEFLATED) as z:
  for path,key in members:z.writestr(key,path.read_bytes())
 with zipfile.ZipFile(dest/name) as z:
  assert len(z.namelist())==len(members)
  for path,key in members:assert z.read(key)==path.read_bytes()
assert all(p.stat().st_size<1048576 for p in dest.iterdir())
print('Retained exact measured record, captures/ICC/PNG/wheel/tools/commands:',{p.name:p.stat().st_size for p in dest.iterdir()})
