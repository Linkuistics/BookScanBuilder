import gzip,hashlib,json,subprocess,zipfile,re
from fractions import Fraction
from pathlib import Path
root=Path('/Users/antony/Development/BookScanBuilder');base=Path('/private/tmp/bookscan-k63-memory-work');out=base/'evidence';dest=root/'docs/acceptance/baseline-profile-memory'
def sha(data):return hashlib.sha256(data).hexdigest()
def equal(a,b):assert a==b,'byte/digest comparison failed'
try:equal(b'actual',b'altered')
except AssertionError:pass
else:raise AssertionError('unchanged-file comparator accepted altered byte')
paths=subprocess.check_output(['jj','file','list'],cwd=root,text=True).splitlines()
current={p:sha((root/p).read_bytes()) for p in paths}
before=json.loads((base/'before.json').read_text())
changes={p for p in before if before[p]!=current.get(p)}
allowed={'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md','docs/acceptance/baseline-finite.md','Taskfile.yml'}
assert changes==allowed
assert set(before)<=set(current)
prior=subprocess.check_output(['jj','file','list','-r','@-'],cwd=root,text=True).splitlines()
original_allowed={'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md','Taskfile.yml','pyproject.toml','uv.lock'}
protected=[]
for path in prior:
 data=subprocess.check_output(['jj','file','show','-r','@-',path],cwd=root)
 if path not in original_allowed:equal(data,(root/path).read_bytes());protected.append(path)
 elif path in ['Taskfile.yml','.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md']:assert (root/path).read_bytes().startswith(data)
assert len(protected)==166
new_code={'tests/profile_memory.py','tests/test_profile_memory.py','tests/memory_acceptance.py','tests/native/profile_memory_observer.c'}
assert all(p.startswith('docs/acceptance/baseline-profile-memory/') or p in new_code for p in set(current)-set(before))
assert new_code<=set(current)-set(before)
for p in changes:assert (root/p).read_bytes().startswith(subprocess.check_output(['jj','file','show','-r','9eb8da6a',p],cwd=root))
record=json.loads((out/'verification.json').read_text());raw=(out/'verification.json').read_bytes()
retained=json.loads(gzip.decompress((dest/'verification.json.gz').read_bytes()))
for key in ['read_subjects_before','read_subjects_after','build_verification']:
 ref=retained[key];data=(dest/ref['file']).read_bytes();equal(sha(data),ref['sha256']);retained[key]=json.loads(gzip.decompress(data))
equal((json.dumps(retained,indent=2)+'\n').encode(),raw)
installed=json.loads((out/'installed/installed-verification.json').read_text())
equal(gzip.decompress((dest/'installed-verification.json.gz').read_bytes()),(out/'installed/installed-verification.json').read_bytes())
excluded={str(root/'.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'),str(root/'docs/acceptance/baseline-finite.md')}
rehash={}
for name,subjects in [('primary',record['read_subjects_before']),('builder',record['build_verification']['read_subjects_before']),('installed',installed['read_subjects_before']),('fixture',record['fixture_subjects_before'])]:
 count=0
 for path,expected in subjects.items():
  if path not in excluded:equal(sha(Path(path).read_bytes()),expected);count+=1
 rehash[name]=count
zip_members={}
for filename in ['fixtures.zip','native-a-captures.zip','native-b-captures.zip','installed-captures.zip','verification-tools.zip','command-records.zip']:
 with zipfile.ZipFile(dest/filename) as z:
  digests={}
  for key in z.namelist():
   data=z.read(key);digests[key]=sha(data)
   if filename=='fixtures.zip':
    if key.startswith('fixtures/'):source=base/'final-fixtures'/key.removeprefix('fixtures/')
    else:source=out/key
   elif filename in ['native-a-captures.zip','native-b-captures.zip','installed-captures.zip']:source=out/key
   elif filename=='verification-tools.zip':
    if key.startswith('native/'):source=root/'tests'/key
    elif key.startswith('runners/'):source=out/'installed'/key
    else:source=base/key
   elif key in ['prepare-a-report.json','prepare-b-report.json']:source=out/key[:9]/'report.json'
   elif key.startswith('installed-units.'):source=out/'installed'/key.removeprefix('installed-')
   else:source=out/key
   equal(data,source.read_bytes())
  zip_members[filename]=digests
# Decode every archive, including coverage-untracked historical evidence; read
# all member bytes directly. No structural or native claim relies on graph gaps.
archive_reads={}
for path in paths:
 p=root/path
 if p.suffix=='.gz':
  data=gzip.decompress(p.read_bytes());json.loads(data);archive_reads[path]={'decoded_bytes':len(data),'sha256':sha(data)}
 elif p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:archive_reads[path]={k:sha(z.read(k)) for k in z.namelist()}
ranges={p: (root/p).read_text().splitlines()[0] for p in ['docs/design/rotation-processor/baseline-delivery.html','docs/design/rotation-processor/contract.html']}
# Exact reports omitted as duplicate ZIP members reconstruct from declared keys.
report_index=json.loads((dest/'report-index.json').read_text())
for relative,reference in report_index.items():
 value=json.loads(gzip.decompress((dest/reference['file']).read_bytes()))
 for key in reference['keys']:value=value[key]
 data=(json.dumps(value,indent=2)+'\n').encode()
 equal(sha(data),reference['sha256']);equal(data,(out/relative).read_bytes())
for repeat in ['a','b']:equal(gzip.decompress((dest/f'memory-{repeat}.json.gz').read_bytes()),(out/f'native-{repeat}/report.json').read_bytes())
equal((dest/'truth.json').read_bytes(),(base/'final-fixtures/truth.json').read_bytes())
# Independently compare native input XYZ columns with the actual hand-encoded
# source tags, directly from raw native tokens and big-endian ICC bytes. A
# deliberately transposed nonsymmetric matrix must fail this same comparison.
import struct
r=json.loads((out/'native-a/report.json').read_text());pid=r['native']['pid']
event=next(e for e in r['captured']['raw']['events'] if e['input_format']==262169)
line=(out/'native-a/capture'/f"{pid}-{event['sequence']}-{event['input_handle']}-memory.txt").read_text().splitlines()[1].split()[1:]
native=[Fraction(float.fromhex(v)) for v in line]
source=(base/'final-fixtures/base/input.icc').read_bytes();tags={}
for pos in range(132,132+12*int.from_bytes(source[128:132],'big'),12):
 name=source[pos:pos+4];offset,size=struct.unpack('>II',source[pos+4:pos+12]);tags[name]=source[offset:offset+size]
literal=[Fraction(v,65536) for tag in [b'rXYZ',b'gXYZ',b'bXYZ',b'wtpt'] for v in struct.unpack('>iii',tags[tag][8:20])]
equal(native,literal)
transposed=[native[j*3+i] for i in range(3) for j in range(3)]+native[9:]
try:equal(transposed,literal)
except AssertionError:pass
else:raise AssertionError('Wrong matrix column-order control credited')
# The reported deltas must describe those exact raw binary/serialized subjects.
assert any(Fraction(v)!=0 for row in r['captured']['exact_memory_minus_serialized']['7-target']['matrix'] for v in row)
# Check all new local evidence references, relative to the durable note.
text=(root/'docs/acceptance/baseline-finite.md').read_text()
for target in re.findall(r'\]\((baseline-profile-memory/[^)]+)\)',text):assert (root/'docs/acceptance'/target).is_file()
identity=subprocess.check_output(['jj','log','--no-pager','--no-graph','-r','@','-T','change_id'],cwd=root,text=True)
parent=subprocess.check_output(['jj','log','--no-pager','--no-graph','-r','@-','-T','commit_id'],cwd=root,text=True)
assert identity=='ryouonnvvlkzyyxmxrpqxnuqrysrqtvy' and parent.startswith('03eb30ab')
assert current=={p:sha((root/p).read_bytes()) for p in paths}
result={'before_paths':len(before),'tracked_paths':len(paths),'protected_originals':protected,'allowed_changed_paths':sorted(changes),'new_paths':sorted(set(current)-set(before)),'rehashes':rehash,'measurement_excluded_after_prose_only':sorted(excluded),'retained_verification_byte_exact':True,'zip_member_sha256':zip_members,'archive_reads':archive_reads,'coverage_missed_html_ranges_read':ranges,'raw_input_xyz_matches_independent_source_tag_bytes':True,'wrong_column_order_control_rejected':True,'f_change_id':identity,'parent_commit':parent,'tracked_digests':current,'audit_script_sha256':sha(Path(__file__).read_bytes()),'wrong_byte_control_rejected':True,'cmm_precision_verified':False,'cairo_fidelity_verified':False,'runtime_resources_verified':False,'accepted_project_delivered':False}
(base/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('AUDITED',len(paths),'complete tracked bytes;',len(before),'prior paths preserved;',len(protected),'protected originals;',len(set(current)-set(before)),'new evidence paths; exact archives/profile memory/source-column identities/frozen subjects/links/open jj boundary')
