import gzip,hashlib,json,re,shutil,subprocess,sys,sysconfig,zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from bookscan import dependencies
from preparation_semantics import pages,faults
root=Path('/Users/antony/Development/BookScanBuilder')
base=Path('/private/tmp/bookscan-k63-memory-work')
out=base/'evidence';out.mkdir()
cache=base/'helper cache';ready=dependencies.preflight(cache)
identity=ready['helper']['inputs']
subjects={root/p for p in subprocess.check_output(['jj','file','list'],cwd=root,text=True).splitlines()}
subjects|={base/n for n in ['verify.py','installed-run.py','build-run.py','preparation_semantics.py','before.json']}
subjects|={Path(p) for g in ready['linked'].values() for p in g['files']}
subjects|={p for p in Path(sysconfig.get_path('stdlib')).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
subjects|={p for p in (root/'.venv/lib').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
subjects|={p for p in cache.rglob('*') if p.is_file()}
subjects|={p for p in (base/'final-fixtures').rglob('*') if p.is_file()}
truth=json.loads((base/'final-fixtures/truth.json').read_text())
subjects|={Path(p) for p in truth['build_subjects_before']}
subjects|={Path(p).resolve() for p in [sys.executable,*[shutil.which(x) for x in ['uv','task','jj','pdftocairo','pdftoppm','pdftotext','clang','pkg-config','otool']]] if p}
subjects|={Path(identity[k]['path']) for k in ['compiler','pkg_config','poppler','leptonica']}
subjects.add(Path(identity['compiler']['driver_path']))
subjects|={Path(p) for p in identity['headers']}
subjects|={Path('/usr/bin/sw_vers'),Path('/usr/bin/xcrun'),Path('/usr/bin/otool'),Path(subprocess.check_output(['xcrun','--find','otool'],text=True).strip()),Path(subprocess.check_output(['xcrun','--find','ld'],text=True).strip())}
experiment_root=subprocess.check_output(['uv','run','--no-project','--python','3.12','--with','pytest==8.4.2','--with','pillow==11.3.0','--with','numpy==2.2.6','python','-c','import pathlib,pytest;print(pathlib.Path(pytest.__file__).parent.parent)'],text=True).strip()
subjects|={p for p in Path(experiment_root).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
def hashes(paths):return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
subjects|={base/n for n in ['lcms2.h','cmsgamma.c','cmsvirt.c','cmsio0.c']}
before=hashes(subjects)
mutated=dict(before);mutated[next(iter(mutated))]='0'*64
try:assert before==mutated
except AssertionError:pass
else:raise AssertionError('Broken unchanged-file comparator')
commands=[]
def run(name,command,cwd=root):
 print('START',name,flush=True)
 r=subprocess.run(command,cwd=cwd,capture_output=True,text=True)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 commands.append({'name':name,'command':command,'cwd':str(cwd),'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr.encode()).hexdigest()})
 print('END',name,r.returncode,flush=True)
 assert r.returncode==0,r.stdout+r.stderr
 return r
run('process-check',['task','--exit-code','process:check'])
run('prepare-check',['task','--exit-code','prepare:check'])
run('staff-check',['task','--exit-code','geometry:staff-check'])
run('task-discovery',['task','--list-all'])
legacy=run('helper-preflight',['task','--exit-code','process:preflight',f'NATIVE_CACHE={cache}'])
assert json.loads(legacy.stdout)==ready['helper']
run('fixture-rebuild',['task','--exit-code','process:memory-fixtures',f'ARTIFACTS={out}/rebuilt-fixtures'])
rebuilt=json.loads((out/'rebuilt-fixtures/truth.json').read_text())
assert rebuilt['build_subjects_before']==rebuilt['build_subjects_after']==truth['build_subjects_before']
for name in ['base/input.icc','base/source.pdf']:assert rebuilt['files'][name]==truth['files'][name]
records=[]
def legacy_semantic(r):
 return {k:r[k] for k in ['format','version','source_sha256','input_sha256','plain_rgb_sha256','observed_rgb_sha256','pixels','semantic','controls','observer_rgb_unchanged','serialized_matrix_only','cmm_precision_verified','cairo_fidelity_verified','runtime_resources_verified','accepted_project_delivered']}
def semantic(r):
 result={k:r[k] for k in ['format','version','source_sha256','rgb_sha256','pixels','controls','profile_memory_observed','cmm_pipeline_observed','cmm_precision_verified','cairo_fidelity_verified','runtime_resources_verified','accepted_project_delivered']}
 result['captured']={k:v for k,v in r['captured'].items() if k!='raw'}
 result['legacy']=legacy_semantic(r['legacy'])
 return result
def units(p):return {(n.attrib['classname'],n.attrib['name']):[c.tag for c in n if c.tag in ['error','failure','skipped']] for n in ET.parse(p).iter('testcase')}
for repeat in ['a','b']:
 run('target-'+repeat,['task','--exit-code','process:memory-acceptance',f'FIXTURES={base}/final-fixtures',f'ARTIFACTS={out}/native-{repeat}'])
 records.append(json.loads((out/f'native-{repeat}/report.json').read_text()))
 run('unit-'+repeat,['uv','run','--locked','pytest','-q','tests/test_target_observation.py','tests/test_profile_memory.py','--junitxml='+str(out/f'unit-{repeat}.xml')])
assert semantic(records[0])==semantic(records[1])
a,b=[units(out/f'unit-{r}.xml') for r in ['a','b']]
assert a==b and len(a)==48 and all(not v for v in a.values())
fixture_paths={p for p in (out/'native-a').rglob('*') if p.is_file()};fixtures_before=hashes(fixture_paths)
run('wheel-build',['uv','run','--no-project','--with','hatchling==1.27.0','python',str(base/'build-run.py'),str(out/'wheel')])
wheel=next((out/'wheel').glob('*.whl'));build=json.loads((out/'wheel/build-verification.json').read_text())
assert build['read_subjects_before']==build['read_subjects_after']
with zipfile.ZipFile(wheel) as z:
 for p in (root/'src/bookscan').rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':assert z.read('bookscan/'+str(p.relative_to(root/'src/bookscan')))==p.read_bytes()
installed_root=out/'installed';installed_root.mkdir();(installed_root/'runners').mkdir()
shutil.copy(base/'installed-run.py',installed_root/'installed-run.py')
for n in ['target_acceptance.py','target_observation.py','test_target_observation.py','icc_matrix_truth.py','icc_fixtures.py','runtime_acceptance.py','runtime_loader.py','memory_acceptance.py','profile_memory.py','test_profile_memory.py']:shutil.copy(root/'tests'/n,installed_root/'runners'/n)
run('installed-wheel',['uv','run','--no-project','--with',str(wheel),'--with','pytest==8.4.2','python',str(installed_root/'installed-run.py')],cwd=installed_root)
installed=json.loads((installed_root/'installed-verification.json').read_text())
assert installed['read_subjects_before']==installed['read_subjects_after']
assert semantic(installed['report'])==semantic(records[0])
assert {json.dumps((json.loads(k)[0].replace('runners.','tests.'),json.loads(k)[1])):v for k,v in installed['unit_outcomes'].items()}=={json.dumps(k):v for k,v in a.items()}
preps=[]
for repeat in ['a','b']:
 run('prepare-synthetic-'+repeat,['task','--exit-code','prepare:acceptance','MODE=synthetic',f'ARTIFACTS={out}/prepare-{repeat}','COLLECTION=/private/tmp/no-collection'])
 preps.append(json.loads((out/f'prepare-{repeat}/report.json').read_text()))
 assert preps[-1]['digests_before']==preps[-1]['digests_after']
assert pages(preps[0],out/'prepare-a')==pages(preps[1],out/'prepare-b')
new_faults=faults(preps[0],out/'prepare-a')
assert new_faults==faults(preps[1],out/'prepare-b') and len(new_faults)==38
old=json.loads(gzip.decompress((root/'docs/acceptance/baseline-target-observation/verification.json.gz').read_bytes()))
assert new_faults==old['preparation_fault_outcomes']
old_p=root/'docs/acceptance/prepared-pdf-k19-synthetic-report.json'
old_pages=pages(json.loads(old_p.read_text()),Path('/private/tmp/bookscan-prepared-k19-synthetic'))
assert pages(preps[0],out/'prepare-a')==old_pages
assert len(old_pages)==9 and sum(map(len,old_pages.values()))==24
# Actual mapped non-system subjects must already be among the frozen files.
for r in records+[installed['report']]:
 for native in [r['native'],r['disabled_native'],r['legacy']['native'],r['legacy']['disabled_native']]:
  for item in native['mapped_images']:
   if 'resolved' in item:
    path=item['resolved'];assert path in before and hashlib.sha256(Path(path).read_bytes()).hexdigest()==item['sha256']==before[path]
after=hashes(subjects);assert before==after
assert fixtures_before==hashes(fixture_paths)
record={'format':'BookScanBuilderMemoryVerification','version':1,'read_subjects_before':before,'read_subjects_after':after,'commands':commands,'fixture_subjects_before':fixtures_before,'fixture_subjects_after':hashes(fixture_paths),'semantic':semantic(records[0]),'unit_outcomes':{json.dumps(k):v for k,v in a.items()},'unit_itemwise_equal':True,'target_itemwise_equal':True,'installed_itemwise_equal':True,'helper_preflight_unchanged':True,'preparation_pages':old_pages,'preparation_fault_outcomes':new_faults,'wrong_digest_control_rejected':True,'build_verification':build,'runtime_resources_verified':False,'comparison_rules':'Every memory binary rational, full table entry, serialized record/delta and control compared itemwise; raw PID/handle/date/path/dyld records retained separately. JUnit installed prefix relocation only. Preparation normalizes only ephemeral paths/PIDs with observed writer/barrier identity.'}
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('VERIFIED',len(before),'subjects; 48 cases; five memory controls and four legacy controls; A/B/wheel; 9 preparation cases/24 pages/38 faults',flush=True)
