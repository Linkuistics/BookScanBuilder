import hashlib, json, re, shlex, shutil, subprocess, sys, sysconfig, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from bookscan import dependencies
root = Path('/Users/antony/Development/BookScanBuilder')
base = Path('/private/tmp/bookscan-k63-matrix-work')
out = base/'evidence-v2'; out.mkdir()
cache = Path('/private/tmp/bookscan-k63-cancel-final/evidence/setup cache')
old = Path('/private/tmp/bookscan-k63-samples-work/evidence-v2/prepare-synthetic/report.json')
ready = dependencies.preflight(cache)
identity = ready['helper']['inputs']
paths = subprocess.check_output(['jj','file','list'],cwd=root,text=True).splitlines()
subjects = {root/p for p in paths}
subjects |= {Path(__file__),base/'installed-run.py',base/'build-run.py',base/'icc.pdf',base/'srgb.pdf',base/'ImageCms.py',base/'cmsxform.c',base/'cmstypes.c',base/'before.json',old}
subjects |= {Path('/private/tmp/bookscan-k63-render-work/poppler-26.10.0/poppler/GfxState.cc'),Path('/private/tmp/bookscan-k63-render-work/poppler-26.10.0/poppler/CairoOutputDev.cc')}
subjects |= {Path(p) for g in ready['linked'].values() for p in g['files']}
subjects |= {p for p in Path(sysconfig.get_path('stdlib')).rglob('*')
             if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
subjects |= {p for p in (root/'.venv/lib').rglob('*')
             if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
subjects |= {p for p in cache.rglob('*') if p.is_file()}
subjects |= {Path(p).resolve() for p in [sys.executable,*[shutil.which(x) for x in
             ['uv','task','jj','pdftocairo','pdftoppm','pdftotext','clang','pkg-config','otool']]] if p}
subjects |= {Path(identity[k]['path']) for k in ['compiler','pkg_config','poppler','leptonica']}
subjects.add(Path(identity['compiler']['driver_path']))
subjects |= {Path(p) for p in identity['headers']}
subjects |= {Path('/usr/bin/sw_vers'),Path('/usr/bin/xcrun'),Path('/usr/bin/otool'),
             Path(subprocess.check_output(['xcrun','--find','otool'],text=True).strip()),
             Path(subprocess.check_output(['xcrun','--find','ld'],text=True).strip())}
subjects |= {root/'experiments/staff_coordinates.py',root/'experiments/test_staff_coordinates.py'}
experiment_root = subprocess.check_output(['uv','run','--no-project','--python','3.12',
    '--with','pytest==8.4.2','--with','pillow==11.3.0','--with','numpy==2.2.6','python','-c',
    'import pathlib,pytest;print(pathlib.Path(pytest.__file__).parent.parent)'],text=True).strip()
subjects |= {p for p in Path(experiment_root).rglob('*')
             if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
def hashes(paths):
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
from PIL import ImageCms
assert Path(ImageCms.__file__).read_bytes() == (base/'ImageCms.py').read_bytes()
before = hashes(subjects)
mutated = dict(before); mutated[next(iter(mutated))] = '0'*64
def unchanged(want, observed):
    assert want == observed, 'subject digest changed'
try: unchanged(before,mutated)
except AssertionError: pass
else: raise AssertionError('wrong-digest control escaped')
commands = []
def run(name,command,cwd=root):
    print('START',name,flush=True)
    result = subprocess.run(command,cwd=cwd,capture_output=True,text=True)
    (out/(name+'.stdout')).write_text(result.stdout)
    (out/(name+'.stderr')).write_text(result.stderr)
    commands.append({'name':name,'command':command,'cwd':str(cwd),'exit_code':result.returncode,
                     'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest(),
                     'stderr_sha256':hashlib.sha256(result.stderr.encode()).hexdigest()})
    print('END',name,result.returncode,flush=True)
    assert result.returncode == 0,result.stdout+result.stderr
    return result
run('process-check',['task','--exit-code','process:check'])
run('prepare-check',['task','--exit-code','prepare:check'])
run('staff-check',['task','--exit-code','geometry:staff-check'])
run('task-discovery',['task','--list-all'])
legacy = run('helper-preflight',['task','--exit-code','process:preflight',f'NATIVE_CACHE={cache}'])
assert json.loads(legacy.stdout) == ready['helper']
records = []
for repeat in ['a','b']:
    run('matrix-'+repeat,['task','--exit-code','process:matrix-acceptance',f'ARTIFACTS={out}/native-{repeat}'])
    report = json.loads((out/f'native-{repeat}/report.json').read_text())
    records.append(report)
    run('unit-'+repeat,['uv','run','--locked','pytest','-q','tests/test_icc_matrix_truth.py','--junitxml='+str(out/f'unit-{repeat}.xml')])
assert records[0] == records[1]
fixture_paths = {p for p in (out/'native-a').iterdir() if p.is_file()}
fixtures_before = hashes(fixture_paths)
def units(path):
    return {(n.attrib['classname'],n.attrib['name']):[c.tag for c in n
            if c.tag in ['error','failure','skipped']] for n in ET.parse(path).iter('testcase')}
a,b = [units(out/f'unit-{r}.xml') for r in ['a','b']]
assert a == b and len(a) == 31 and all(not v for v in a.values())
run('wheel-build',['uv','run','--no-project','--with','hatchling==1.27.0',
                  'python',str(base/'build-run.py'),str(out/'wheel')])
wheel = next((out/'wheel').glob('*.whl'))
build = json.loads((out/'wheel/build-verification.json').read_text())
assert build['read_subjects_before'] == build['read_subjects_after']
with zipfile.ZipFile(wheel) as archive:
    for path in (root/'src/bookscan').rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            assert archive.read('bookscan/'+str(path.relative_to(root/'src/bookscan'))) == path.read_bytes()
installed_root = out/'installed'; installed_root.mkdir(); (installed_root/'runners').mkdir()
shutil.copy(base/'installed-run.py', installed_root/'installed-run.py')
for name in ['matrix_acceptance.py','icc_fixtures.py','icc_matrix_truth.py','test_icc_matrix_truth.py']:
    shutil.copy(root/'tests'/name, installed_root/'runners'/name)
run('installed-wheel',['uv','run','--no-project','--with',str(wheel),'--with','pytest==8.4.2',
                       'python',str(installed_root/'installed-run.py')],cwd=installed_root)
installed = json.loads((installed_root/'installed-verification.json').read_text())
assert installed['read_subjects_before'] == installed['read_subjects_after']
assert installed['report'] == records[0]
assert all(json.loads(k)[0] == 'runners.test_icc_matrix_truth' for k in installed['unit_outcomes'])
assert {json.dumps(('tests.test_icc_matrix_truth',json.loads(k)[1])):v for k,v in
        installed['unit_outcomes'].items()} == {json.dumps(k):v for k,v in a.items()}
run('prepare-synthetic',['task','--exit-code','prepare:acceptance','MODE=synthetic',
                        f'ARTIFACTS={out}/prepare-synthetic','COLLECTION=/private/tmp/no-collection'])
new,previous = [json.loads(p.read_text()) for p in [out/'prepare-synthetic/report.json',old]]
def normalize(value,folder):
    if isinstance(value,dict): return {k:normalize(v,folder) for k,v in value.items() if k != 'pid'}
    if isinstance(value,list): return [normalize(v,folder) for v in value]
    if isinstance(value,str): return re.sub(r'\.bookscan-prepare-[0-9a-f]{32}\.tmp',
                                            '<OWNED_PRIVATE_NAME>',value.replace(str(folder),'<RUN>'))
    return value
def pages(report,folder):
    return {case['case']:[{'output_page':p['output_page'],'source':Path(p['source']).name,
        'source_page':p['source_page'],'role':p['role'],'geometry':p['geometry'],
        'raw_streams':p['raw_streams'],'renders':normalize(p['renders'],folder)}
        for p in case['pages']] for case in report['cases']}
assert pages(new,out/'prepare-synthetic') == pages(previous,old.parent)
assert new['digests_before'] == new['digests_after']
def faults(report,folder):
    rows = {}
    for item in report['fault_checks']['observed_signal_and_kill_cases']:
        assert item['pid'] == item['observed_barrier']['pid'] and item['writer_reaped'] and item['source_unchanged']
        key = json.dumps([item['hook'],item.get('dry_run',False),item['signal'],item.get('signals_sent',1)])
        assert key not in rows; rows[key] = normalize(item,folder)
    return rows
new_faults = faults(new,out/'prepare-synthetic')
assert new_faults == faults(previous,old.parent) and len(new_faults) == 38
assert len(pages(new,out/'prepare-synthetic')) == 9
assert sum(len(p) for p in pages(new,out/'prepare-synthetic').values()) == 24
after = hashes(subjects); unchanged(before,after)
assert fixtures_before == hashes(fixture_paths)
record = {'format':'BookScanBuilderMatrixVerification','version':1,
          'read_subjects_before':before,'read_subjects_after':after,'commands':commands,
          'fixture_subjects_before':fixtures_before,'fixture_subjects_after':hashes(fixture_paths),
          'report':records[0],'unit_outcomes':{json.dumps(k):v for k,v in a.items()},
          'unit_itemwise_equal':True,'matrix_itemwise_equal':True,'installed_itemwise_equal':True,
          'helper_preflight_unchanged':True,'preparation_itemwise_equal':list(pages(new,out/'prepare-synthetic')),
          'preparation_fault_outcomes':new_faults,'wrong_digest_control_rejected':True,
          'build_verification':build,'runtime_resources_verified':False,
          'scope':'Enumerated code/packages/static native files/cache/ICC and normative inputs frozen; complete font/profile/config/environment resource discovery remains unverified.',
          'comparison_rules':'Complete matrix construction reports compare byte-semantically itemwise. Installed test relocation normalizes only tests/runners prefix; raw JUnit names retained. Preparation per-item comparison normalizes only ephemeral private paths/PIDs, keeping actual barrier-owner identity.'}
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('VERIFIED',len(before),'enumerated subjects; 31 unit identities; 3 matrix cases/2 native diagnostic controls; installed wheel; 9 preparation cases/24 pages/38 faults',flush=True)
