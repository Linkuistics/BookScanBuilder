/private/tmp/bookscan-k63-runtime-work/evidence/fixtures/leaf73.dylib: \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/antony/Development/BookScanBuilder/tests/native/loader_leaf.c
