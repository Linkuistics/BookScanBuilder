import copy
import gzip
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/Users/antony/Development/BookScanBuilder')
HERE = Path('/private/tmp/bookscan-k63-native-header.ip551gyh')
DEST = ROOT / 'docs/acceptance/baseline-native-header'
TASK = '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'
NOTES = {TASK: 'task.prefix', 'docs/acceptance/baseline-finite.md': 'acceptance.prefix'}
EXISTING = {
    TASK, 'docs/acceptance/baseline-finite.md', 'Taskfile.yml',
    'src/bookscan/project_header.py', 'tests/checkpoint_acceptance.py',
    'tests/checkpoint_worker.py', 'tests/native_inventory_acceptance.py',
    'tests/test_analysis_record.py', 'tests/test_fontconfig_cache_record.py',
    'tests/test_fontconfig_discovery_record.py', 'tests/test_fontconfig_record.py',
    'tests/test_linked_record.py', 'tests/test_native_sample_record.py',
    'tests/test_occurrence_record.py', 'tests/test_project_header.py',
    'tests/test_render_record.py', 'tests/test_resource_record.py',
    'tests/test_source_record.py', 'tests/test_triage_record.py',
}
NEW = {'tests/test_native_header.py'} | {
    'docs/acceptance/baseline-native-header/' + name for name in (
        'README.md', 'verify.py', 'controls.py', 'controls-result.json', 'coverage.json',
        'index.json.gz', 'boundary.py.gz', 'boundary-result.json',
        *(f'raw-{n:03}.zippart' for n in range(5)),
    )
}

def sha(raw): return hashlib.sha256(raw).hexdigest()

def jj(rev, template):
    return subprocess.check_output(['jj','log','-r',rev,'--no-graph','--no-pager','-T',template],cwd=ROOT,text=True)

def require(ok, message):
    if not ok: raise ValueError(message)

def validate(observed):
    require(observed['change'] == 'ryouonnvvlkzyyxmxrpqxnuqrysrqtvy', 'Task-owned change')
    require(observed['parent'] == '03eb30abe1ae485696e5deec25bfb229a42ecf69', 'Task parent')
    require(observed['description'] == '', 'No partial description')
    require(observed['conflicts'] == '', 'No conflicts')
    require(set(observed['changed']) <= EXISTING and set(observed['new']) <= NEW, 'Foreign path')
    require(observed['prefixes'], 'Append-only notes and Taskfile')

before = json.loads((HERE/'starting.json').read_bytes())
paths = subprocess.check_output(['jj','file','list'],cwd=ROOT,text=True).splitlines()
now = {p: sha((ROOT/p).read_bytes()) for p in paths if (ROOT/p).is_file()}
changed = sorted(p for p,d in before.items() if now.get(p) != d)
new = sorted(set(now) - set(before))
prefixes = all((ROOT/p).read_bytes().startswith((HERE/name).read_bytes()) for p,name in NOTES.items())
prefixes = prefixes and (ROOT/'Taskfile.yml').read_bytes().startswith((HERE/'taskfile.prefix').read_bytes())
observed = {
    'change': jj('@','change_id'), 'parent': jj('@-','commit_id'),
    'description': jj('@','description'), 'conflicts': jj('conflicts() & @','change_id'),
    'changed': changed, 'new': new, 'prefixes': prefixes,
}
validate(observed)
controls = []
for label,field,value in (
    ('wrong-change','change','foreign'), ('wrong-parent','parent','foreign'),
    ('partial-description','description','premature milestone'), ('conflict','conflicts','foreign'),
    ('foreign-path','new',['src/bookscan/foreign.py']), ('lost-prefix','prefixes',False),
):
    altered = copy.deepcopy(observed); altered[field] = value
    try: validate(altered)
    except ValueError as error: controls.append({'control':label,'refused':str(error)})
    else: raise AssertionError(label)
frozen = json.loads(gzip.decompress((HERE/'final/subjects-before.json.gz').read_bytes()))
require(frozen == json.loads(gzip.decompress((HERE/'final/subjects-after.json.gz').read_bytes())), 'Measurement freeze')
for name, saved in frozen.items():
    path = Path(name)
    if name in {str(ROOT/p) for p in NOTES}:
        raw = path.read_bytes()[:saved['identity'][3]]
        require(sha(raw) == saved['sha256'], 'Measured note prefix: '+name)
    else:
        info = path.lstat()
        raw = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
        native = [info.st_dev,info.st_ino,info.st_mode,info.st_size,info.st_mtime_ns,info.st_ctime_ns]
        require(sha(raw) == saved['sha256'] and native == saved['identity'], 'Frozen subject: '+name)
report = {'starting_paths':len(before),'current_paths':len(now),'frozen_subjects':len(frozen),
          'observed':observed,'controls':controls,'public_finite_delivery':False}
print(json.dumps(report,indent=2))
