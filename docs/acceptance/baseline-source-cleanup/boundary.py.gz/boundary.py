import gzip
import hashlib
import io
import json
import subprocess
import zipfile
from pathlib import Path

root = Path.cwd()
p = Path('/private/tmp/bookscan-source-cleanup-20261015.7ryix5')
start = json.loads((p / 'starting.json').read_text())
files = subprocess.check_output(['jj', 'file', 'list', '--no-pager'], text=True).splitlines()
expected = {
    'src/bookscan/initial_import.py', 'src/bookscan/project_reservation.py',
    'tests/test_initial_import.py', 'tests/test_project_reservation.py',
    'Taskfile.yml', 'docs/acceptance/baseline-finite.md',
    '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md',
}
changed = {name for name, fact in start.items()
           if hashlib.sha256((root / name).read_bytes()).hexdigest() != fact['sha256']}
assert changed == expected, changed
assert set(start) <= set(files)
added = set(files) - set(start)
assert added and all(x.startswith('docs/acceptance/baseline-source-cleanup/') for x in added), added
for name in ['Taskfile.yml', '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md',
             'docs/acceptance/baseline-finite.md']:
    assert (root / name).read_bytes().startswith((p / ('prefix-' + Path(name).name)).read_bytes())
before = json.loads(gzip.decompress((p / 'final/subjects-before.json.gz').read_bytes()))
for name in expected - {'Taskfile.yml', 'docs/acceptance/baseline-finite.md',
                        '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'}:
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == before[str(root / name)]['sha256']
out = root / 'docs/acceptance/baseline-source-cleanup'
x = json.loads((out / 'index.json').read_text())
with zipfile.ZipFile(io.BytesIO(b''.join((out / part['path']).read_bytes() for part in x['parts']))) as z:
    for name in ['Taskfile.yml', '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md']:
        assert (root / name).read_bytes().startswith(z.read('repo/' + name))
    assert gzip.decompress((out / 'measurement.json.gz').read_bytes()) == z.read('run/measurement.json')
current = subprocess.check_output([
    'jj', 'log', '-r', '@', '--no-pager', '--no-graph', '-T',
    'change_id ++ "\n" ++ description ++ "\n" ++ parents.map(|r| r.commit_id()).join(" ") ++ "\n"'
], text=True).splitlines()
assert current == ['ryouonnvvlkzyyxmxrpqxnuqrysrqtvy', '',
                   '03eb30abe1ae485696e5deec25bfb229a42ecf69'], current
conflicts = subprocess.check_output([
    'jj', 'log', '-r', 'conflicts() & @', '--no-pager', '--no-graph', '-T', 'change_id'
], text=True).strip()
assert not conflicts, conflicts
report = {
    'starting_paths': len(start), 'current_paths': len(files), 'changed': sorted(changed),
    'added': sorted(added), 'open_change': current[0], 'parent': current[2],
    'measured_prefixes_preserved': True, 'conflicts': False, 'retirement': False,
}
(p / 'boundary.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report))
