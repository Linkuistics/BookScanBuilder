import os
from pathlib import Path
from writer_hooks import install
install('validation', Path('/private/tmp/bookscan-rgb-close-bbx929lf/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_va0/barrier.json'))
