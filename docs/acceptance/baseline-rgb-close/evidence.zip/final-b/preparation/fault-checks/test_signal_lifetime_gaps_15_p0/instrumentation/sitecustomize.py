import os
from pathlib import Path
from writer_hooks import install
install('plan-emit', Path('/private/tmp/bookscan-rgb-close-bbx929lf/final-b/preparation/fault-checks/test_signal_lifetime_gaps_15_p0/barrier.json'))
