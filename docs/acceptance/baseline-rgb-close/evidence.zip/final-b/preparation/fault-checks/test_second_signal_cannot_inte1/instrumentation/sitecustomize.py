import os
from pathlib import Path
from writer_hooks import install
install('cleanup-interrupted', Path('/private/tmp/bookscan-rgb-close-bbx929lf/final-b/preparation/fault-checks/test_second_signal_cannot_inte1/barrier.json'))
