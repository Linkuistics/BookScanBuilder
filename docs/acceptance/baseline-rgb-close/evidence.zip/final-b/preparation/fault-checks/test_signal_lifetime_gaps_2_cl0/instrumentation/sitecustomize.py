import os
from pathlib import Path
from writer_hooks import install
install('cleanup-error', Path('/private/tmp/bookscan-rgb-close-bbx929lf/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_cl0/barrier.json'))
