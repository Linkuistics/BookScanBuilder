"""Freeze declared inputs around sequential Taskfile measurements; one writer."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()

def digest(path):
 info=path.stat()
 return {'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':info.st_size,'device':info.st_dev,'inode':info.st_ino,'mode':info.st_mode,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns}

def subjects():
 files=set()
 for name in ['src','tests','experiments','.grove','.venv','docs/adr']:
  for path in (repo/name).rglob('*'):
   if '__pycache__' not in path.parts and path.is_file(): files.add(path.resolve())
 for path in (repo/'docs/specs').rglob('*'):
  if path.is_file(): files.add(path.resolve())
 for name in ['Taskfile.yml','pyproject.toml','uv.lock','CONTEXT.md']:
  files.add((repo/name).resolve())
 for name in ['task','uv','pdftoppm','pdftotext','clang','pkg-config']:
  files.add(Path(shutil.which(name)).resolve())
 files.add(Path(sys.executable).resolve())
 for path in Path(sys.base_prefix).rglob('*'):
  if '__pycache__' not in path.parts and path.is_file(): files.add(path.resolve())
 files.add(Path(__file__).resolve())
 
 for name in ['compare.py','disproof.py','measure.py','native-preflight.json','native-prior.json']:
  files.add((base/name).resolve())
 cache=Path('/private/tmp/bookscan-k63-render-record/native-cache')
 files.update(p.resolve() for p in cache.rglob('*') if p.is_file())
 for graph in json.loads((base/'native-preflight.json').read_text())['linked'].values():
  files.update(Path(p).resolve() for p in graph['files'])
 return {str(p):digest(p) for p in sorted(files)}

for reading in ['final-a','final-b']:
 out=base/reading;out.mkdir()
 before=subjects();(out/'subjects-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
 commands=[('product',['task','--exit-code','process:check']),('focused',['task','--exit-code','process:rgb-close-check']),('staff',['task','--exit-code','geometry:staff-check']),('preparation',['task','--exit-code','prepare:acceptance','MODE=synthetic','ARTIFACTS='+str(out/'preparation')]),('asset-workers',['task','--exit-code','process:asset-acceptance','ARTIFACTS='+str(out/'asset-workers')]),('native',['task','--exit-code','process:initial-import-acceptance','ARTIFACTS='+str(out/'native'),'NATIVE_CACHE=/private/tmp/bookscan-k63-render-record/native-cache']),('source-workers',['task','--exit-code','process:source-acceptance','ARTIFACTS='+str(out/'source-workers')])]
 results=[]
 for name,command in commands:
  env=os.environ.copy()
  if name in ['product','focused','staff']: env['PYTEST_ADDOPTS']='--junitxml='+str(out/(name+'.xml'))
  with (out/(name+'.log')).open('wb') as log:
   done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
  results.append({'name':name,'command':command,'exit_code':done.returncode})
  print(reading,name,done.returncode,flush=True)
  if done.returncode: break
 after=subjects();(out/'subjects-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
 (out/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
 assert before==after, 'Measured subjects changed'
 assert all(r['exit_code']==0 for r in results),results
print('Both sequential readings complete with unchanged subjects',len(before),flush=True)
