import os
from pathlib import Path
from writer_hooks import install
install('recheck', Path('/private/tmp/bookscan-rgb-close-bbx929lf/final-a/preparation/fault-checks/test_signal_lifetime_gaps_2_re0/barrier.json'))
