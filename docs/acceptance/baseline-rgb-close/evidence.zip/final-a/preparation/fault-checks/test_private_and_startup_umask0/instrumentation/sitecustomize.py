import os
from pathlib import Path
from writer_hooks import install
os.umask(23)
install('writing', Path('/private/tmp/bookscan-rgb-close-bbx929lf/final-a/preparation/fault-checks/test_private_and_startup_umask0/barrier.json'))
