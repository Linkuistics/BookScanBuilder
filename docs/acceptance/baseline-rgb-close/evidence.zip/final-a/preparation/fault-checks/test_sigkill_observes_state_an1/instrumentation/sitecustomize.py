import os
from pathlib import Path
from writer_hooks import install
install('after-link', Path('/private/tmp/bookscan-rgb-close-bbx929lf/final-a/preparation/fault-checks/test_sigkill_observes_state_an1/barrier.json'))
