import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-rgb-close-bbx929lf/retry-close/src')
from bookscan import assets
import pytest
for module in [assets]:
 p=Path(module.__file__); assert p.is_relative_to(Path('/private/tmp/bookscan-rgb-close-bbx929lf/retry-close/src'))
 print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(["-q",'/Users/antony/Development/BookScanBuilder/tests/test_rgb_close.py',"--junitxml=/private/tmp/bookscan-rgb-close-bbx929lf/retry-close/tests.xml"]))
