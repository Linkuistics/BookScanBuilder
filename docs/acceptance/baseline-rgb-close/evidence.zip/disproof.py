"""Run the new filesystem challenges against isolated predecessor/mutated code."""
import hashlib,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for case in ['predecessor','no-notes','caller-exception','retry-close']:
 root=base/case
 shutil.copytree(base/'before/src' if case=='predecessor' else repo/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__'))
 path=root/'src/bookscan/assets.py'
 if case!='predecessor':
  raw=path.read_text()
  if case=='no-notes':
   old='selected.add_note("RGB descriptor close: " + str(error))'
   assert raw.count(old)==1
   raw=raw.replace(old,'pass')
  elif case=='caller-exception':
   old='selected: BaseException | None = None'
   assert raw.count(old)==1
   raw=raw.replace(old,'selected: BaseException | None = __import__("sys").exception()')
  else:
   old='except OSError as error:\n            if selected is not None:'
   assert raw.count(old)==1
   raw=raw.replace(old,'except OSError as error:\n            os.close(descriptor)\n            if selected is not None:')
  path.write_text(raw)
 script=root/'run.py'
 script.write_text('import sys,json,hashlib\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(root/'src'))+')\nfrom bookscan import assets\nimport pytest\nfor module in [assets]:\n p=Path(module.__file__); assert p.is_relative_to(Path('+repr(str(root/'src'))+'))\n print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main(["-q",'+repr(str(repo/'tests/test_rgb_close.py'))+',"--junitxml='+str(root/'tests.xml')+'"]))\n')
 with (root/'run.log').open('wb') as log:
  done=subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==1,(case,done.returncode)
 cases=list(ET.parse(root/'tests.xml').iter('testcase'))
 assert len(cases)==34 and not any(c.find('error') is not None for c in cases)
 failed=[c.get('name') for c in cases if c.find('failure') is not None]
 assert failed
 rows.append({'case':case,'exit':done.returncode,'failed':failed,'passed':[c.get('name') for c in cases if c.find('failure') is None],'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'case':r['case'],'failed':len(r['failed']),'passed':len(r['passed'])} for r in rows]))
