import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-store-close-WWeDWZ/inode-only/src')
from bookscan import project_reservation
import pytest
p=Path(project_reservation.__file__)
assert p==Path('/private/tmp/bookscan-store-close-WWeDWZ/inode-only/src/bookscan/project_reservation.py')
print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(["-q",'/Users/antony/Development/BookScanBuilder/tests/test_store_close.py',"--junitxml=/private/tmp/bookscan-store-close-WWeDWZ/inode-only/tests.xml"]))
