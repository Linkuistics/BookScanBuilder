import os
from pathlib import Path
from writer_hooks import install
install('blocked', Path('/private/tmp/bookscan-store-close-WWeDWZ/final-b/preparation/fault-checks/test_real_signals_at_observed_12/barrier.json'))
