import os
from pathlib import Path
from writer_hooks import install
install('validation', Path('/private/tmp/bookscan-store-close-WWeDWZ/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_va0/barrier.json'))
