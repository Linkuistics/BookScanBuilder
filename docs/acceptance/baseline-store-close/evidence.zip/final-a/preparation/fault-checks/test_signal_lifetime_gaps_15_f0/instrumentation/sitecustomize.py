import os
from pathlib import Path
from writer_hooks import install
install('finish', Path('/private/tmp/bookscan-store-close-WWeDWZ/final-a/preparation/fault-checks/test_signal_lifetime_gaps_15_f0/barrier.json'))
