import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for case in ['predecessor','no-parent-check','inode-only']:
 root=base/case
 shutil.copytree(base/'before/src',root/'src')
 path=root/'src/bookscan/project_reservation.py'
 if case!='predecessor':
  raw=(repo/'src/bookscan/project_reservation.py').read_text()
  if case=='no-parent-check':
   old='if _identity(os.fstat(parent)) != parent_identity:'
   assert raw.count(old)==1
   raw=raw.replace(old,'if False:')
  else:
   start=raw.index('def _rollback_closed_store('); end=raw.index('@contextmanager\ndef provision_store',start)
   part=raw[start:end]; old='return _file_stamp(entry) == stamp'
   assert part.count(old)==1
   part=part.replace(old,'return _identity(entry) == _identity(captured)')
   raw=raw[:start]+part+raw[end:]
  path.write_text(raw)
 script=root/'run.py'
 script.write_text('import sys,json,hashlib\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(root/'src'))+')\nfrom bookscan import project_reservation\nimport pytest\np=Path(project_reservation.__file__)\nassert p==Path('+repr(str(path))+')\nprint(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main(["-q",'+repr(str(repo/'tests/test_store_close.py'))+',"--junitxml='+str(root/'tests.xml')+'"]))\n')
 with (root/'run.log').open('wb') as log:
  result=subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT)
 assert result.returncode==1,(case,result.returncode)
 import xml.etree.ElementTree as ET
 cases=list(ET.parse(root/'tests.xml').iter('testcase'))
 failed=[c.get('name') for c in cases if c.find('failure') is not None]
 assert not any(c.find('error') is not None for c in cases)
 assert failed
 rows.append({'case':case,'exit':result.returncode,'failed':failed,'passed':[c.get('name') for c in cases if c.find('failure') is None],'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'case':r['case'],'failed':len(r['failed']),'passed':len(r['passed'])} for r in rows]))
