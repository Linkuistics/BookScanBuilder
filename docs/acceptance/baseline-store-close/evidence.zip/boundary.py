"""Verify the bounded producer change against the captured pre-edit source."""
import hashlib,json
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd();before=base/'before'
changed=[];unchanged=[];new=[]
for tree in ['src','tests']:
 for original in sorted((before/tree).rglob('*')):
  if not original.is_file(): continue
  rel=original.relative_to(before); current=repo/rel
  assert current.is_file(), str(rel)
  if original.read_bytes()!=current.read_bytes(): changed.append(str(rel))
  else: unchanged.append(str(rel))
 for current in (repo/tree).rglob('*'):
  if current.is_file() and '__pycache__' not in current.parts and not (before/current.relative_to(repo)).exists():
   new.append(str(current.relative_to(repo)))
assert changed==['src/bookscan/project_reservation.py'],changed
assert new==['tests/test_store_close.py'],new
old=(before/changed[0]).read_text();current=(repo/changed[0]).read_text()
prefix=old[:old.index('@contextmanager\ndef provision_store(')]
suffix=old[old.index('\ndef reserve('):]
assert current.startswith(prefix) and current.endswith(suffix)
for rel in ['Taskfile.yml','.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md']:
 assert (repo/rel).read_bytes().startswith((before/rel).read_bytes())
for rel in ['pyproject.toml','uv.lock']:
 assert (repo/rel).read_bytes()==(before/rel).read_bytes()
measured=changed+new+['Taskfile.yml']
result={'changed_existing_code':changed,'new_code':new,'unchanged_source_test_files':unchanged,
        'outside_provision_and_new_helper_byte_exact':True,'original_task_and_recipe_prefixes_preserved':True,
        'manifest_lock_unchanged':True,'current_measured_source_sha256':{p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in measured}}
(base/'boundary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'unchanged_source_test_files':len(unchanged),'measured_files':measured,'passed':True}))
