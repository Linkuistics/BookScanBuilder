import hashlib,json,subprocess,sys,sysconfig,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'runners'))
from formatter_acceptance import run
from bookscan import intake,render,samples,dependencies
import bookscan,pikepdf,PIL,pytest
root=Path(__file__).parent
base=root.parent.parent
module_paths={n:str(Path(m.__file__).resolve()) for n,m in [('bookscan',bookscan),('intake',intake),('render',render),('samples',samples),('pikepdf',pikepdf),('PIL',PIL),('pytest',pytest)]}
assert all(not p.startswith('/Users/antony/Development/BookScanBuilder/') for p in module_paths.values())
subjects={Path(__file__),Path(sys.executable).resolve()}
subjects|={p for p in (root/'runners').iterdir() if p.is_file()}
for module in [bookscan,pikepdf,PIL,pytest]:
 subjects|={p for p in Path(module.__file__).parent.parent.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
subjects|={p for p in Path(sysconfig.get_path('stdlib')).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
ready=dependencies.preflight(base/'helper cache')
subjects|={Path(p) for g in ready['linked'].values() for p in g['files']}
subjects|={p for p in (base/'final-fixtures').rglob('*') if p.is_file()}
subjects|={Path('/usr/bin/sw_vers'),Path('/usr/bin/otool'),Path('/usr/bin/xcrun'),Path(subprocess.check_output(['xcrun','--find','otool'],text=True).strip())}
def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(subjects)}
before=hashes()
report=run(base/'final-fixtures',root/'measured')
r=subprocess.run([sys.executable,'-m','pytest','-q',str(root/'runners/test_target_observation.py'),str(root/'runners/test_profile_memory.py'),str(root/'runners/test_transform_formatters.py'),'--junitxml='+str(root/'units.xml')],capture_output=True,text=True)
(root/'units.stdout').write_text(r.stdout);(root/'units.stderr').write_text(r.stderr);assert r.returncode==0,r.stdout+r.stderr
units={json.dumps((n.attrib['classname'],n.attrib['name'])):[c.tag for c in n if c.tag in ['error','failure','skipped']] for n in ET.parse(root/'units.xml').iter('testcase')}
assert len(units)==67 and all(not v for v in units.values())
after=hashes();assert before==after
(root/'installed-verification.json').write_text(json.dumps({'module_paths':module_paths,'report':report,'unit_outcomes':units,'read_subjects_before':before,'read_subjects_after':after,'runtime_resources_verified':False},indent=2)+'\n')
print('Installed target observation:',len(before),'enumerated frozen subjects; 67 cases')
