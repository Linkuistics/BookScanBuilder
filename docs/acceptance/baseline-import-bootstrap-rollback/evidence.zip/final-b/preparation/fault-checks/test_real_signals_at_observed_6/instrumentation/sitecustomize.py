import os
from pathlib import Path
from writer_hooks import install
install('committed', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-b/preparation/fault-checks/test_real_signals_at_observed_6/barrier.json'))
