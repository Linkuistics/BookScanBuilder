import os
from pathlib import Path
from writer_hooks import install
install('dry-traversal', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_dr0/barrier.json'))
