import os
from pathlib import Path
from writer_hooks import install
install('cleanup-interrupted', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-b/preparation/fault-checks/test_second_signal_cannot_inte0/barrier.json'))
