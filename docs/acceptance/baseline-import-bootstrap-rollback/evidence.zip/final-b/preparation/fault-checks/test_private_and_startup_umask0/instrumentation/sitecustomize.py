import os
from pathlib import Path
from writer_hooks import install
os.umask(23)
install('writing', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-b/preparation/fault-checks/test_private_and_startup_umask0/barrier.json'))
