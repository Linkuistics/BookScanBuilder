import os
from pathlib import Path
from writer_hooks import install
os.umask(63)
install('writing', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-b/preparation/fault-checks/test_private_and_startup_umask1/barrier.json'))
