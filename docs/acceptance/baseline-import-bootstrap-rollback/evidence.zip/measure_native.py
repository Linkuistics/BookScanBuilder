"""Supplement primary gates with unchanged real native initial-import acceptance."""
import hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent
cache=Path('/private/tmp/bookscan-k63-render-record/native-cache')
preflight=json.loads((base/'native-preflight.json').read_text())
paths={Path(p) for p in json.loads((base/'final-a/subjects-before.json').read_text())}
paths.update(p.resolve() for p in cache.rglob('*') if p.is_file())
for graph in preflight['linked'].values():paths.update(Path(p).resolve() for p in graph['files'])
paths.update([Path(__file__),base/'native-preflight.json',base/'native-prior.json',base/'final-a/subjects-before.json',Path('/private/tmp/bookscan-k63-acquired-lock-cleanup/native/comparison.json')])
def freeze():
 result={}
 for p in sorted(paths):
  info=p.stat()
  result[str(p)]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':info.st_size,'device':info.st_dev,'inode':info.st_ino,'mode':info.st_mode,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns}
 return result
out=base/'native';out.mkdir()
before=freeze();(out/'subjects-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
reports=[];outcomes=[];runs=[]
for reading in ['a','b']:
 folder=out/reading;folder.mkdir()
 for name,command in [('focused',['task','--exit-code','process:initial-import-check']),('import',['task','--exit-code','process:initial-import-acceptance','ARTIFACTS='+str(folder/'artifacts'),'NATIVE_CACHE='+str(cache)])]:
  env=os.environ.copy()
  if name=='focused':env['PYTEST_ADDOPTS']='--junitxml='+str(folder/'focused.xml')
  with (folder/(name+'.log')).open('wb') as log:done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
  runs.append({'reading':reading,'name':name,'command':command,'exit_code':done.returncode})
  assert done.returncode==0,(reading,name,done.returncode)
  print(reading,name,'passed',flush=True)
 report=json.loads((folder/'artifacts/report.json').read_text());reports.append(report)
 assert all(report[k] is True for k in ['source_loss_resume','resource_loss_resume','native_resume_launch_denied'])
 assert report['public_finite_delivery'] is False and report['composition_fidelity_verified'] is False
 assert len(report['baseline_sha256'])==7 and len(report['controls'])==7
 cases={}
 for row in ET.parse(folder/'focused.xml').iter('testcase'):
  key=row.get('classname')+'::'+row.get('name')
  assert key not in cases and not any(c.tag in {'failure','error','skipped'} for c in row)
  cases[key]='passed'
 outcomes.append(cases)
after=freeze();(out/'subjects-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
assert before==after,'Native subjects changed'
assert outcomes[0]==outcomes[1] and outcomes[0]
fields=['format','version','truth_sha256','baseline_sha256','controls','source_loss_resume','resource_loss_resume','native_resume_launch_denied','public_finite_delivery','composition_fidelity_verified','limitations']
meaning=[{k:r[k] for k in fields} for r in reports]
assert meaning[0]==meaning[1]
prior=json.loads(Path('/private/tmp/bookscan-k63-acquired-lock-cleanup/native/comparison.json').read_text())
assert meaning[0]==prior['per_case'],'Changed native construction meaning'
(out/'commands.json').write_text(json.dumps(runs,indent=2)+'\n')
summary={'named_subjects':len(before),'focused_cases':len(outcomes[0]),'per_case':meaning[0],'prior_meaning_file':'/private/tmp/bookscan-k63-acquired-lock-cleanup/native/comparison.json','prior_meaning_sha256':hashlib.sha256(Path('/private/tmp/bookscan-k63-acquired-lock-cleanup/native/comparison.json').read_bytes()).hexdigest(),'limitations':'Native construction/import/resume only; no public create/barrier or real fidelity/relocated compatibility claim.'}
(out/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Native paired meaning and predecessor agree;',len(before),'subjects unchanged',flush=True)
