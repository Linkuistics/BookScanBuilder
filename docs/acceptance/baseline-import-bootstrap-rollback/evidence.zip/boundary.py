"""Verify this continuation's bounded changes against captured actual source."""
import hashlib,json
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd();before=base/'before'
changed=[];unchanged=[];new=[]
for tree in ['src','tests']:
 for original in sorted((before/tree).rglob('*')):
  if not original.is_file(): continue
  rel=original.relative_to(before); current=repo/rel
  assert current.is_file(),str(rel)
  (changed if original.read_bytes()!=current.read_bytes() else unchanged).append(str(rel))
 for current in sorted((repo/tree).rglob('*')):
  if current.is_file() and '__pycache__' not in current.parts and not (before/current.relative_to(repo)).exists():
   new.append(str(current.relative_to(repo)))
assert changed==['src/bookscan/initial_import.py','src/bookscan/project_header.py','tests/test_initial_import.py'],changed
assert new==['tests/test_import_bootstrap_rollback.py'],new
for rel in ['Taskfile.yml','.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md']:
 assert (repo/rel).read_bytes().startswith((before/rel).read_bytes()),rel
for rel in ['pyproject.toml','uv.lock']:
 assert (repo/rel).read_bytes()==(before/rel).read_bytes(),rel
measured=changed+new+['Taskfile.yml']
result={'changed_existing_code':changed,'new_code':new,'unchanged_source_test_files':unchanged,
        'original_task_and_recipe_prefixes_preserved':True,'manifest_lock_unchanged':True,
        'current_measured_source_sha256':{p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in measured}}
(base/'boundary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'unchanged_source_test_files':len(unchanged),'measured_files':measured,'passed':True}))
