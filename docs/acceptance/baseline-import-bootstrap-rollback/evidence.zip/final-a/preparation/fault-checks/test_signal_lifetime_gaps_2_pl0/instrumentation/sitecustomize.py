import os
from pathlib import Path
from writer_hooks import install
install('plan-emit', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-a/preparation/fault-checks/test_signal_lifetime_gaps_2_pl0/barrier.json'))
