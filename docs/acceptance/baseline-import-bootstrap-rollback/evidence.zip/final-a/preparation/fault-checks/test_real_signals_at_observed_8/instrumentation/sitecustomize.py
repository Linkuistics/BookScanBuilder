import os
from pathlib import Path
from writer_hooks import install
install('writing', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-a/preparation/fault-checks/test_real_signals_at_observed_8/barrier.json'))
