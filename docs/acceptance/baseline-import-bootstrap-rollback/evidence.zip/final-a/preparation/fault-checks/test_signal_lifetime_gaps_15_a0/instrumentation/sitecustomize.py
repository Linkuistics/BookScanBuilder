import os
from pathlib import Path
from writer_hooks import install
install('after-open', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-a/preparation/fault-checks/test_signal_lifetime_gaps_15_a0/barrier.json'))
