import os
from pathlib import Path
from writer_hooks import install
os.umask(511)
install('writing', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-a/preparation/fault-checks/test_private_and_startup_umask2/barrier.json'))
