import os
from pathlib import Path
from writer_hooks import install
install('finish', Path('/private/tmp/bookscan-post-provision-uaj3uomc/final-a/preparation/fault-checks/test_signal_lifetime_gaps_2_fi0/barrier.json'))
