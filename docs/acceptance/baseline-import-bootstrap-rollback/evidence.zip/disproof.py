"""Run the new filesystem challenges against isolated predecessor/mutated code."""
import hashlib,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for case in ['predecessor','no-parent-check','inode-only']:
 root=base/case
 shutil.copytree(base/'before/src' if case=='predecessor' else repo/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__'))
 path=root/'src/bookscan/project_header.py'
 if case!='predecessor':
  raw=path.read_text()
  if case=='no-parent-check':
   old='if _native(os.fstat(parent)) != original_parent:'
   assert raw.count(old)==1
   raw=raw.replace(old,'if False:')
  else:
   old='if not stat.S_ISDIR(named.st_mode) or _stamp(named) != stamp:'
   assert raw.count(old)==1
   raw=raw.replace(old,'if not stat.S_ISDIR(named.st_mode) or (named.st_dev, named.st_ino) != stamp[:2]:')
  path.write_text(raw)
 script=root/'run.py'
 script.write_text('import sys,json,hashlib\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(root/'src'))+')\nfrom bookscan import project_header,initial_import\nimport pytest\nfor module in [project_header,initial_import]:\n p=Path(module.__file__); assert p.is_relative_to(Path('+repr(str(root/'src'))+'))\n print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main(["-q",'+repr(str(repo/'tests/test_import_bootstrap_rollback.py'))+',"--junitxml='+str(root/'tests.xml')+'"]))\n')
 with (root/'run.log').open('wb') as log:
  done=subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==1,(case,done.returncode)
 cases=list(ET.parse(root/'tests.xml').iter('testcase'))
 assert len(cases)==38 and not any(c.find('error') is not None for c in cases)
 failed=[c.get('name') for c in cases if c.find('failure') is not None]
 assert failed
 rows.append({'case':case,'exit':done.returncode,'failed':failed,'passed':[c.get('name') for c in cases if c.find('failure') is None],'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'case':r['case'],'failed':len(r['failed']),'passed':len(r['passed'])} for r in rows]))
