import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-post-provision-uaj3uomc/no-parent-check/src')
from bookscan import project_header,initial_import
import pytest
for module in [project_header,initial_import]:
 p=Path(module.__file__); assert p.is_relative_to(Path('/private/tmp/bookscan-post-provision-uaj3uomc/no-parent-check/src'))
 print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(["-q",'/Users/antony/Development/BookScanBuilder/tests/test_import_bootstrap_rollback.py',"--junitxml=/private/tmp/bookscan-post-provision-uaj3uomc/no-parent-check/tests.xml"]))
