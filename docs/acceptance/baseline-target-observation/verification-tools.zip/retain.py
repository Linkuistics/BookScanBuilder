import gzip,hashlib,json,shutil,zipfile
from pathlib import Path
base=Path('/private/tmp/bookscan-k63-target-final');out=base/'evidence-v2'
dest=Path('/Users/antony/Development/BookScanBuilder/docs/acceptance/baseline-target-observation');dest.mkdir()
def compressed(name,value):
 data=(json.dumps(value,indent=2)+'\n').encode();encoded=gzip.compress(data,mtime=0)
 (dest/name).write_bytes(encoded);assert gzip.decompress(encoded)==data
 return {'file':name,'sha256':hashlib.sha256(encoded).hexdigest()}
record=json.loads((out/'verification.json').read_text())
original=(out/'verification.json').read_bytes()
record['read_subjects_before']=compressed('primary-subjects.json.gz',record['read_subjects_before'])
record['read_subjects_after']=dict(record['read_subjects_before'])
record['build_verification']=compressed('build-verification.json.gz',record['build_verification'])
compressed('verification.json.gz',record)
compressed('installed-verification.json.gz',json.loads((out/'installed/installed-verification.json').read_text()))
restored=json.loads(gzip.decompress((dest/'verification.json.gz').read_bytes()))
for key in ['read_subjects_before','read_subjects_after','build_verification']:
 ref=restored[key];data=(dest/ref['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==ref['sha256'];restored[key]=json.loads(gzip.decompress(data))
assert (json.dumps(restored,indent=2)+'\n').encode()==original
for repeat in ['a','b']:shutil.copy(out/f'native-{repeat}/report.json',dest/f'target-{repeat}.json')
shutil.copy(base/'fixtures/truth.json',dest/'truth.json')
archives={
 'fixtures.zip': [(p,'fixtures/'+str(p.relative_to(base/'fixtures'))) for p in (base/'fixtures').iterdir() if p.is_file()]+[(p,name+'/'+str(p.relative_to(out/name))) for name in ['native-a','native-b','installed/measured','rebuilt-fixtures'] for p in (out/name).rglob('*') if p.is_file()]+[(p,'wheel/'+p.name) for p in (out/'wheel').glob('*.whl')],
 'verification-tools.zip':[(base/n,n) for n in ['verify.py','installed-run.py','build-run.py','preparation_semantics.py','before.json','retain.py']]+[(p,'runners/'+p.name) for p in (out/'installed/runners').iterdir() if p.is_file()],
 'command-records.zip':[(p,p.name) for p in out.iterdir() if p.is_file() and p.suffix in ['.stdout','.stderr','.xml']]+[(out/f'prepare-{r}/report.json',f'prepare-{r}-report.json') for r in ['a','b']]+[(out/'installed/units.xml','installed-units.xml')]+[(out/'installed/units.stdout','installed-units.stdout')]
}
for name,members in archives.items():
 with zipfile.ZipFile(dest/name,'w',zipfile.ZIP_DEFLATED) as z:
  for path,key in members:z.writestr(key,path.read_bytes())
 with zipfile.ZipFile(dest/name) as z:
  assert len(z.namelist())==len(members)
  for path,key in members:assert z.read(key)==path.read_bytes()
assert all(p.stat().st_size<1048576 for p in dest.iterdir())
print('Retained exact measured record, captures/ICC/PNG/wheel/tools/commands:',{p.name:p.stat().st_size for p in dest.iterdir()})
