import gzip,hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path('/Users/antony/Development/BookScanBuilder')
HERE=Path('/private/tmp/bookscan-occurrence-core.NPk5Mh')
TASK='.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'
BASE='020c57b2ab5456e9c686d62b7e9dd0ec5aca00ff'
CHANGE='ryouonnvvlkzyyxmxrpqxnuqrysrqtvy'
PARENT='03eb30abe1ae485696e5deec25bfb229a42ecf69'
expected={TASK,'Taskfile.yml','docs/acceptance/baseline-finite.md','src/bookscan/occurrence_record.py','src/bookscan/source_record.py','tests/test_occurrence_record.py'}
for name in ('index.json.gz','verify.py','controls.py','controls-result.json','boundary.py.gz','boundary-result.json'):
    expected.add('docs/acceptance/baseline-occurrence-core/'+name)
for ordinal in range(5):
    expected.add(f'docs/acceptance/baseline-occurrence-core/raw-{ordinal:03d}.zippart')

def jj(args):
    return subprocess.run(['jj',*args],cwd=ROOT,text=True,capture_output=True,check=True).stdout

def validate(facts):
    assert facts['change']==CHANGE
    assert facts['parent']==PARENT
    assert facts['description']==''
    assert facts['conflict']=='false'
    assert set(facts['paths'])==expected
    assert facts['live']

facts={'change':jj(['log','--no-pager','--no-graph','-r','@','-T','change_id']).strip(),
'parent':jj(['log','--no-pager','--no-graph','-r','@-','-T','commit_id']).strip(),
'description':jj(['log','--no-pager','--no-graph','-r','@','-T','description']),
'conflict':jj(['log','--no-pager','--no-graph','-r','@','-T','conflict']).strip(),
'paths':jj(['diff','--no-pager','--from',BASE,'--name-only']).splitlines(),
'live':(ROOT/TASK).is_file()}
validate(facts)
controls=[]
for key,value in [('change','other'),('parent','other'),('description','sealed partial'),('conflict','true'),('paths',[*facts['paths'],'foreign.py']),('paths',[p for p in facts['paths'] if not p.endswith('index.json.gz')]),('live',False)]:
    try: validate({**facts,key:value})
    except AssertionError: controls.append(key)
    else: raise AssertionError('Boundary control accepted')
for name,original in [(TASK,'task-before.md'),('docs/acceptance/baseline-finite.md','acceptance-before.md')]:
    assert (ROOT/name).read_bytes().startswith((HERE/original).read_bytes())
subjects=json.loads(gzip.decompress((HERE/'frozen/subjects-before.json.gz').read_bytes()))
notes={str(ROOT/TASK),str(ROOT/'docs/acceptance/baseline-finite.md')}
for name,wanted in subjects.items():
    path=Path(name)
    info=path.lstat()
    raw=os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
    if name in notes:
        assert hashlib.sha256(raw[:wanted['size']]).hexdigest()==wanted['sha256'],name
    else:
        observed={'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw),'device':info.st_dev,'inode':info.st_ino,'mode':info.st_mode,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns,'symlink':path.is_symlink()}
        assert observed==wanted,name
print(json.dumps({'verified':True,'change':CHANGE,'parent':PARENT,'base':BASE,'live':True,'empty_description':True,'changed_paths':sorted(expected),'subjects':len(subjects),'notes_prefixes_preserved':True,'controls_refused':controls},indent=2))
