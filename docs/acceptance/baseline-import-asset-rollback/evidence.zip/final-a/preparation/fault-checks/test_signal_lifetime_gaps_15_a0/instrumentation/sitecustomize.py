import os
from pathlib import Path
from writer_hooks import install
install('after-open', Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/final-a/preparation/fault-checks/test_signal_lifetime_gaps_15_a0/barrier.json'))
