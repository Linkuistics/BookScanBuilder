import os
from pathlib import Path
from writer_hooks import install
install('after-block', Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/final-a/preparation/fault-checks/test_real_signals_at_observed_11/barrier.json'))
