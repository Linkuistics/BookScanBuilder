import sys,hashlib,json
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/no-checkpoint-guard/src')
from bookscan import initial_import,assets,native_blobs,project_header
import pytest
for module in [initial_import,assets,native_blobs,project_header]:
 p=Path(module.__file__); assert p.is_relative_to(Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/no-checkpoint-guard/src'))
 print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(["-q",'/Users/antony/Development/BookScanBuilder/tests/test_import_asset_rollback.py',"--junitxml=/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/no-checkpoint-guard/tests.xml"]))
