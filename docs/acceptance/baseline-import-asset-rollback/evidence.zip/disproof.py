"""Exercise real filesystem tests against copied predecessor and faulty variants."""
import hashlib,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for case in ['predecessor','no-checkpoint-guard','size-only-files','no-cleanup-transition']:
 root=base/case
 shutil.copytree(base/'before/src' if case=='predecessor' else repo/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__'))
 if case=='no-checkpoint-guard':
  path=root/'src/bookscan/project_header.py'
  text=path.read_text();old='if _stamp(history) != original["checkpoints"]:'
  assert text.count(old)==1;text=text.replace(old,'if False:')
 elif case=='size-only-files':
  path=root/'src/bookscan/import_publications.py'
  text=path.read_text();old='stamp(named) != captured:'
  assert text.count(old)==1;text=text.replace(old,'named.st_size != captured[4]:')
 elif case=='no-cleanup-transition':
  path=root/'src/bookscan/import_publications.py'
  text=path.read_text();old='if current[:3] != self.directory_stamp[:3]:'
  assert text.count(old)==1;text=text.replace(old,'if False:')
 else:
  path=root/'src/bookscan/initial_import.py';text=path.read_text()
 path.write_text(text)
 script=root/'run.py'
 script.write_text('import sys,hashlib,json\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(root/'src'))+')\nfrom bookscan import initial_import,assets,native_blobs,project_header\nimport pytest\nfor module in [initial_import,assets,native_blobs,project_header]:\n p=Path(module.__file__); assert p.is_relative_to(Path('+repr(str(root/'src'))+'))\n print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main(["-q",'+repr(str(repo/'tests/test_import_asset_rollback.py'))+',"--junitxml='+str(root/'tests.xml')+'"]))\n')
 with (root/'run.log').open('wb') as log:
  done=subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==1,(case,done.returncode)
 cases=list(ET.parse(root/'tests.xml').iter('testcase'))
 assert len(cases)==33 and not any(c.find('error') is not None for c in cases)
 failed=[c.get('name') for c in cases if c.find('failure') is not None]
 assert failed
 rows.append({'case':case,'exit':done.returncode,'failed':failed,'passed':[c.get('name') for c in cases if c.find('failure') is None],'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'case':r['case'],'failed':len(r['failed']),'passed':len(r['passed'])} for r in rows]))
