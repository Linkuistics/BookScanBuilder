import os
from pathlib import Path
from writer_hooks import install
os.umask(63)
install('writing', Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/final-b/preparation/fault-checks/test_private_and_startup_umask1/barrier.json'))
