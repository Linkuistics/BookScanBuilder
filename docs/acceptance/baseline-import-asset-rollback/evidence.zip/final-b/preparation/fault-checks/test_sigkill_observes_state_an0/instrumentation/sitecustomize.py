import os
from pathlib import Path
from writer_hooks import install
install('writing', Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/final-b/preparation/fault-checks/test_sigkill_observes_state_an0/barrier.json'))
