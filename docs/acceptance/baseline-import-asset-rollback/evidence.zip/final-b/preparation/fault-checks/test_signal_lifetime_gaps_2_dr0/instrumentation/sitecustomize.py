import os
from pathlib import Path
from writer_hooks import install
install('dry-traversal', Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_dr0/barrier.json'))
