import os
from pathlib import Path
from writer_hooks import install
install('after-open', Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_af0/barrier.json'))
