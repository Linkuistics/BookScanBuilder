import os
from pathlib import Path
from writer_hooks import install
install('pending', Path('/private/tmp/bookscan-k63-asset-rollback.rmer0ydn/final-b/preparation/fault-checks/test_real_signals_at_observed_2/barrier.json'))
