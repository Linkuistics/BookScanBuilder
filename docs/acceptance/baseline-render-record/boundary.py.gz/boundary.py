"""Verify same live F owner, exact changed scope, note prefixes and frozen subjects."""
import gzip
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT=Path('/Users/antony/Development/BookScanBuilder')
HERE=Path('/private/tmp/bookscan-k63-render-record')
DEST=ROOT/'docs/acceptance/baseline-render-record'
TASK='.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md'
NOTES={TASK,'docs/acceptance/baseline-finite.md'}
ALLOWED=NOTES|{'Taskfile.yml','tests/assessment_acceptance.py'}
NEW={'src/bookscan/render_record.py','tests/test_render_record.py'}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def command(*args): return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def require(value,what):
    if not value: raise ValueError(what)

def check(start,subjects,change,parent,description,conflicts,current):
    require(change=='ryouonnvvlkzyyxmxrpqxnuqrysrqtvy','wrong change')
    require(parent=='03eb30abe1ae485696e5deec25bfb229a42ecf69','wrong parent')
    require(description=='','partial sealing/description')
    require(conflicts=='','conflict')
    require((ROOT/TASK).is_file(),'terminal or missing leaf')
    require(set(start)<=set(current),'missing prior path')
    changed={p for p in start if sha((ROOT/p).read_bytes())!=start[p]}
    require(changed==ALLOWED,'foreign or missing change')
    added=set(current)-set(start)
    require(NEW<=added,'missing new product/tests')
    require(all(p in NEW or p.startswith('docs/acceptance/baseline-render-record/') for p in added),'foreign new path')
    for name in NOTES:
        prefix=archive[Path(name).name]
        require((ROOT/name).read_bytes().startswith(prefix),'lost starting prefix')
    for name,info in subjects.items():
        path=Path(name); meta=path.lstat()
        raw=os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
        if path.is_relative_to(ROOT) and path.relative_to(ROOT).as_posix() in NOTES:
            require(sha(raw[:info['size']])==info['sha256'],'lost measured prefix')
            continue
        got={'sha256':sha(raw),'size':len(raw),'device':meta.st_dev,'inode':meta.st_ino,'mode':meta.st_mode,'mtime_ns':meta.st_mtime_ns,'ctime_ns':meta.st_ctime_ns,'symlink':path.is_symlink()}
        require(got==info,'frozen subject changed: '+name)
    return sorted(changed|added)

import importlib.util
spec=importlib.util.spec_from_file_location('render_evidence',DEST/'verify.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
archive=module.load(DEST)
start=json.loads(archive['starting.json'])
subjects=json.loads(gzip.decompress(archive['frozen/subjects-before.json.gz']))
change=command('jj','log','-r','@','--no-graph','--no-pager','-T','change_id')
parent=command('jj','log','-r','@-','--no-graph','--no-pager','-T','commit_id')
description=command('jj','log','-r','@','--no-graph','--no-pager','-T','description')
conflicts=command('jj','log','-r','conflicts() & @','--no-graph','--no-pager','-T','commit_id')
current=command('jj','file','list','--no-pager').splitlines()
paths=check(start,subjects,change,parent,description,conflicts,current)
controls={}
for name,c,p,d,f in [('change','wrong',parent,description,conflicts),('parent',change,'wrong',description,conflicts),('description',change,parent,'partial',conflicts),('conflict',change,parent,description,'conflict')]:
    try: check(start,subjects,c,p,d,f,current)
    except ValueError as error: controls[name]=str(error)
    else: raise AssertionError(name)
try: check(start,subjects,change,parent,description,conflicts,current+['foreign.txt'])
except ValueError as error: controls['foreign-path']=str(error)
else: raise AssertionError('foreign-path')
result={'passed':True,'change_id':change,'parent':parent,'starting_paths':len(start),'changed_paths':paths,'frozen_subjects':len(subjects),'notes_preserve_starting_and_measured_prefixes':True,'controls':controls}
(DEST/'boundary-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
