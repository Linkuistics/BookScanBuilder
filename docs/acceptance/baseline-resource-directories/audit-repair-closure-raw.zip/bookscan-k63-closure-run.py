import gzip
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/antony/Development/BookScanBuilder')
ARTIFACTS = Path('/private/tmp/bookscan-k63-closure-final')
ARTIFACTS.mkdir()
TOOL = 'docs/acceptance/baseline-resource-directories/audit-repair-closure.py'
TESTS = 'docs/acceptance/baseline-resource-directories/audit-repair-closure-tests.py'
source = Path(__file__).read_bytes()
checks = []
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
commands = [
    ['uv', 'run', '--locked', 'python', TOOL, '--output', str(ARTIFACTS / 'a.json')],
    ['uv', 'run', '--locked', 'ruff', 'check', TOOL, TESTS],
    ['uv', 'run', '--locked', 'ruff', 'format', '--check', TOOL, TESTS],
    ['uv', 'run', '--locked', 'pyright', TOOL, TESTS],
    ['uv', 'run', '--locked', 'pytest', '-q', TESTS, '--junitxml=' + str(ARTIFACTS / 'tests.xml')],
    ['uv', 'run', '--locked', 'python', TOOL, '--output', str(ARTIFACTS / 'b.json')],
]
for command in commands:
    result = subprocess.run(command, cwd=ROOT, env=environment, text=True, capture_output=True)
    checks.append(dict(command=command, exit=result.returncode, stdout=result.stdout, stderr=result.stderr))
    print(command[3], result.returncode, flush=True)
    if result.returncode:
        (ARTIFACTS / 'failed.json').write_text(json.dumps(checks, indent=2))
        print(result.stdout, result.stderr)
        sys.exit(result.returncode)
a = json.loads((ARTIFACTS / 'a.json').read_bytes())
b = json.loads((ARTIFACTS / 'b.json').read_bytes())
assert a == b, 'Complete per-item closure readings differ'
assert a['inputs_before'] == a['inputs_after'] == b['inputs_before'] == b['inputs_after']
assert source == Path(__file__).read_bytes()
record = dict(version=1, checks=checks, itemwise_equal=True, entire_subjects_unchanged=True,
              driver_sha256=hashlib.sha256(source).hexdigest(), subjects=a['current_input_subjects'],
              historical_subjects=a['historical_input_subjects'],
              scope='Evidence closure only; finite F live and unsealed; no product delivery')
(ARTIFACTS / 'verification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k != 'checks'}), flush=True)
