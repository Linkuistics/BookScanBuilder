"""Challenge checked copies of the owner; never mutate measured live sources."""
import json, shutil, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for case in ['predecessor','no-private-stamp','no-private-mode','adopt-private-inventory']:
 root=base/case
 shutil.copytree(base/'before/src' if case=='predecessor' else repo/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
 if case!='predecessor':
  path=root/'src/bookscan/import_publications.py';text=path.read_text()
  a=text.index('    def refused(');b=text.index('    def completed(',a);part=text[a:b]
  if case=='no-private-stamp':
   for line in ['            or stamp(held) != expected\n','            or stamp(named) != expected\n']:
    assert part.count(line)==1;part=part.replace(line,'')
   old='files = self._files | {name: expected}'
   assert part.count(old)==1;part=part.replace(old,'files = self._files | {name: stamp(held)}')
  elif case=='no-private-mode':
   old='current[:3] != self.directory_stamp[:3]';assert part.count(old)==1
   part=part.replace(old,'current[:2] != self.directory_stamp[:2]')
  else:
   old='files = self._files | {name: expected}';assert part.count(old)==1
   part=part.replace(old,'files = {entry: stamp(os.stat(entry, dir_fd=directory, follow_symlinks=False)) for entry in os.listdir(directory)}')
  path.write_text(text[:a]+part+text[b:])
 script=root/'run.py'
 script.write_text('import sys,hashlib,json\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(root/'src'))+')\nfrom bookscan import initial_import,assets,native_blobs,import_publications\nimport pytest\nfor module in [initial_import,assets,native_blobs,import_publications]:\n p=Path(module.__file__);assert p.is_relative_to(Path('+repr(str(root/'src'))+'))\n print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main(["-q",'+repr(str(repo/'tests/test_private_import_rollback.py'))+',"--junitxml='+str(root/'tests.xml')+'"]))\n')
 with (root/'run.log').open('wb') as log:done=subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==1,(case,done.returncode)
 cases=list(ET.parse(root/'tests.xml').iter('testcase'))
 assert len(cases)==44 and not any(c.find('error') is not None for c in cases)
 failed=[c.get('name') for c in cases if c.find('failure') is not None]
 passed=[c.get('name') for c in cases if c.find('failure') is None]
 expected={'predecessor':20,'no-private-stamp':6,'no-private-mode':2,'adopt-private-inventory':4}[case]
 assert len(failed)==expected,(case,failed)
 rows.append({'case':case,'exit':done.returncode,'failed':failed,'passed':passed})
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'case':r['case'],'failed':len(r['failed']),'passed':len(r['passed'])} for r in rows]))
