import os
from pathlib import Path
from writer_hooks import install
install('after-open', Path('/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/final-b/preparation/fault-checks/test_signal_lifetime_gaps_15_a0/barrier.json'))
