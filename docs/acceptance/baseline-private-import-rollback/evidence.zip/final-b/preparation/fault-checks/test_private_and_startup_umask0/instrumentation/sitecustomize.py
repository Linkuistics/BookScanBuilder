import os
from pathlib import Path
from writer_hooks import install
os.umask(23)
install('writing', Path('/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/final-b/preparation/fault-checks/test_private_and_startup_umask0/barrier.json'))
