import os
from pathlib import Path
from writer_hooks import install
install('pre-region', Path('/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/final-b/preparation/fault-checks/test_real_signals_at_observed_1/barrier.json'))
