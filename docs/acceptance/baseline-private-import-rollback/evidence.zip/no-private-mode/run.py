import sys,hashlib,json
from pathlib import Path
sys.path.insert(0,'/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/no-private-mode/src')
from bookscan import initial_import,assets,native_blobs,import_publications
import pytest
for module in [initial_import,assets,native_blobs,import_publications]:
 p=Path(module.__file__);assert p.is_relative_to(Path('/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/no-private-mode/src'))
 print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(["-q",'/Users/antony/Development/BookScanBuilder/tests/test_private_import_rollback.py',"--junitxml=/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/no-private-mode/tests.xml"]))
