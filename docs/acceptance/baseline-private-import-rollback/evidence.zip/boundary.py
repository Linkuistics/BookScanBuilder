"""Check this bounded continuation against its captured starting sources."""
import hashlib,json,difflib
from pathlib import Path
base=Path(__file__).resolve().parent;repo=Path.cwd()
changed=[];unchanged=[];current={}
expected={'src/bookscan/assets.py','src/bookscan/native_blobs.py','src/bookscan/import_publications.py'}
new={'tests/test_private_import_rollback.py'}
for tree in ['src','tests']:
 before={str(p.relative_to(base/'before')):p for p in (base/'before'/tree).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 after={str(p.relative_to(repo)):p for p in (repo/tree).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 assert set(after)-set(before)=={p for p in new if p.startswith(tree+'/')}
 assert not (set(before)-set(after))
 for name,path in before.items():
  if path.read_bytes()==after[name].read_bytes():unchanged.append(name)
  else:changed.append(name)
 for name,path in after.items():current[name]=hashlib.sha256(path.read_bytes()).hexdigest()
assert set(changed)==expected
for name in ['pyproject.toml','uv.lock']:
 assert (base/'before'/name).read_bytes()==(repo/name).read_bytes()
 current[name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
assert (repo/'Taskfile.yml').read_bytes().startswith((base/'before/Taskfile.yml').read_bytes())
current['Taskfile.yml']=hashlib.sha256((repo/'Taskfile.yml').read_bytes()).hexdigest()
result={'changed_original_source':sorted(changed),'new_source':sorted(new),'unchanged_original_source':sorted(unchanged),'current_measured_source_sha256':current,'manifest_and_lock_unchanged':True,'original_recipe_prefix_unchanged':True}
(base/'boundary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'changed':sorted(changed),'new':sorted(new),'unchanged':len(unchanged)}))
