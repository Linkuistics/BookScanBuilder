import os
from pathlib import Path
from writer_hooks import install
install('finish', Path('/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/final-a/preparation/fault-checks/test_signal_lifetime_gaps_2_fi0/barrier.json'))
