import os
from pathlib import Path
from writer_hooks import install
install('writing', Path('/private/var/folders/z1/nw_wk3gj3hqchs4_73xrf2dw0000gn/T/bookscan-private-rollback-boiq1fdf/final-a/preparation/fault-checks/test_sigkill_observes_state_an0/barrier.json'))
