import sys,hashlib,json
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-analysis-cleanup-lS08wx/no-file-stamp/src')
from bookscan import native_setup, analysis_workspace, skew
import pytest
for module in [native_setup,analysis_workspace,skew]:
 p=Path(module.__file__);assert p.is_relative_to(Path('/private/tmp/bookscan-analysis-cleanup-lS08wx/no-file-stamp/src'))
 print(json.dumps({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(['-q', '/Users/antony/Development/BookScanBuilder/tests/test_analysis_cleanup.py', '--junitxml=/private/tmp/bookscan-analysis-cleanup-lS08wx/no-file-stamp/tests.xml']))
