import os
from pathlib import Path
from writer_hooks import install
install('recheck', Path('/private/tmp/bookscan-analysis-cleanup-lS08wx/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_re0/barrier.json'))
