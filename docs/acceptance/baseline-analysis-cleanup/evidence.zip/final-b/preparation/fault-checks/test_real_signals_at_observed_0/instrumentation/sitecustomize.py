import os
from pathlib import Path
from writer_hooks import install
install('writing', Path('/private/tmp/bookscan-analysis-cleanup-lS08wx/final-b/preparation/fault-checks/test_real_signals_at_observed_0/barrier.json'))
