import os
from pathlib import Path
from writer_hooks import install
install('after-open', Path('/private/tmp/bookscan-analysis-cleanup-lS08wx/final-a/preparation/fault-checks/test_signal_lifetime_gaps_15_a0/barrier.json'))
