import os
from pathlib import Path
from writer_hooks import install
install('after-link', Path('/private/tmp/bookscan-analysis-cleanup-lS08wx/final-a/preparation/fault-checks/test_real_signals_at_observed_13/barrier.json'))
