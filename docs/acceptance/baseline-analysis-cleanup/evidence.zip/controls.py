"""Disprove the paired comparator on altered per-item records, without editing them."""
import copy
import hashlib
import json
from pathlib import Path
import compare

root = Path(__file__).resolve().parent
script = root / 'controls.py'
before = hashlib.sha256(script.read_bytes()).hexdigest()
original = compare.read
rows = []
for label in ['preparation', 'writer-pid', 'asset-rgb', 'native-rgb']:
    def altered(path):
        value = original(path)
        relative = path.relative_to(root).as_posix()
        if label == 'preparation' and relative == 'final-a/preparation/report.json':
            value = copy.deepcopy(value)
            value['cases'][0]['id'] = 'wrong-per-item-case'
        elif label == 'writer-pid' and relative == 'final-a/source-workers/report.json':
            value = copy.deepcopy(value)
            value['cases'][0]['writer_pid'] += 1
        elif label == 'asset-rgb' and relative == 'final-a/asset-workers/result.json':
            value = copy.deepcopy(value)
            value['records'][0]['barrier']['reference']['rgb_sha256'] = '0' * 64
        elif label == 'native-rgb' and relative == 'final-a/native/report.json':
            value = copy.deepcopy(value)
            value['baseline_sha256'][0] = '0' * 64
        return value
    compare.read = altered
    try:
        compare.main()
    except AssertionError:
        rows.append({'control':label, 'rejected':True})
    else:
        raise AssertionError('Altered per-item control passed: ' + label)
    finally:
        compare.read = original
assert hashlib.sha256(script.read_bytes()).hexdigest() == before
(root / 'controls.json').write_text(json.dumps({'script_sha256':before, 'records':rows}, indent=2) + '\n')
print(json.dumps(rows, indent=2))
