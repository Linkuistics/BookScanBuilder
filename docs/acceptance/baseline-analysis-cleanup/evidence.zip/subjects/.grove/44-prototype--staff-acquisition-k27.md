# staff-acquisition-k27


## Goal

Test whether exact native pixel addressing can resolve the rejected manual
acquisition on the unchanged selected music page. First establish automatic
coordinate prerequisites and genuine manual extents; mark densely only if that
evidence leaves the manual question justified. Deliver independently verified
source observations, blind whole-trace repeats and unchanged native preflight,
or the precise source-only reason to stop, with explicit human dispositions.
Generate no fitted model, rigid image or corrected image in this session.



## Context

- `corrected-book-k21` records why this repair, rather than another correction
  family, is commissioned; `staff-guides-k20` and `staff-coordinates-k26` carry
  the original supplied-trace isolation contract and rejected acquisition.
  Read `.grove/20-k20/_staff-guides.md` in full. `corrected-book-k30` records
  the review integration and any human-confirmed sequencing choice.
  Consume the independent `norwegian-gutter-k31` result and its fresh planning
  handoff before this repair; neither supplies music or preparation acceptance.
  `norwegian-gutter-k34` commissions source-only `norwegian-measurement-k35`
  and its fresh planner before this leaf on every outcome. Consume their actual
  evidence/protocol limitations; numerical addressing or acquisition success
  on text baselines grants no admissibility to this music-rule repair.
  Read `norwegian-gutter-k37`'s verified review disposition: k35 now checks
  addressing and frozen physical-mask feasibility before dense marking, and
  separates glyph-class, sampling/compression and shared systematic uncertainty.
  Carry applicable instrument limitations into this rule-centre protocol;
  neither a Norwegian gate failure nor JPEG/glyph contrasts calibrate music.
- `docs/experiments/staff-guides.md`, its selection/first-pass/report records,
  and `experiments/staff_coordinates.json`: frozen rejected diagnostics, not
  input to a real fit. Preserve these records; put new passes/results in
  separately identified ordinary files and a linked durable experiment note.
- Candidate: `Raw Scans/Fundamentals of Musical Composition.pdf`, one-based
  PDF page 20 / printed 6, relative to `/Volumes/Glass/Book Conversion`.
  Full-page Poppler RGB 300 dpi, 1702 × 2440; source SHA-256
  `3235a842d619a18b11e2fbdb3b5b6666adeb223959cafd4b1d67f27f0dbfe780`.
  Verify the selection record's complete render identity before marking.
  Page 140 is the historical unsupported-layout diagnostic, not this fit.
- Existing `geometry:staff-views`, `geometry:staff-preflight` and
  `geometry:staff-check` provide source reproduction and exact gate evidence.
  The current preflight reads the rejected record; it cannot become a fresh
  observation just by rerunning it. Inspect its input/admissibility contract
  before adding a new-record path, preserving historical reproduction.
- Separate historical views: `/private/tmp/bookscan-geometry-k4-final/geometry-review.pdf`
  and `preparation-review.pdf`; current preparation comparisons come from
  `/private/tmp/bookscan-prepared-k19-all`, as recorded in
  `docs/acceptance/prepared-pdf.md`. Both responses are “Not inspected yet”.
- `corrected-book-k28` is the already-live fresh planning consumer after this
  leaf, on every outcome. It owns the next experiment, not this prototype.

## Done when

The human's current geometry-only scope in k41 governs references below to the
intermediate product: page/book geometry, any-page review and image-only export.
Reordering and OCR are external; consume the revised actual design and its
book-side/alignment limitations, not Draft v1's removed requirements. This changes
none of the source-only music observation/gate protocol, pending historical
responses or k28's ownership of full within-page evidence and acceptance.

- Consume k43's charter clarification with k41's actual handoff: its design
  needs a recorded scoped human signature; universal unverified nonrigidity is
  distinct from per-page triage. Carry numerical and visual product dispositions
  separately to k28, including any reaction-pending scope. This changes none of
  this repair's source-only acquisition, gates or historical-response criteria.

- Consume k40's `rotation-processor-k41` design and actual lazy planning/working
  handoff before this source repair. Its complete intermediate rotation/review/
  assembly/aligned-OCR/export increment is distinct from music or within-page
  acceptance. Design or working export does not alter this source-only protocol,
  authorize a fit or accept music/geometry/preparation. Keep k28 as the fresh
  consumer of this repair on every outcome, carrying the actual intermediate
  artifacts/limitations and all unresolved k40/k28 obligations. No Norwegian
  study or repeated identical missing-response completion is commissioned by
  k40. Both Norwegian source replies remain unavailable independently; preserve
  any later actual reply explicitly. This repair still owns the separate exact
  historical geometry/preparation response questions below.

- Read `norwegian-measurement-k38`, `geometry-policy-k39` and its actual fresh
  planning consumer `geometry-policy-k40`. Carry exact per-half source
  dispositions
  and policy choices. k39's first policy reply is “yes”: record numerical source
  evidence admissibility separately from the human source-view reaction.
  Unavailable review does not veto otherwise verified numerical evidence;
  numerical evidence supplies no visual approval or missing physical/systematic
  proof. The human replied “agreed” to considering an intermediate processor
  that straightens rotation and flags unresolved distortion while nonrigid
  evidence continues. Its design, complete useful handoff and own acceptance
  still bind, with within-page/fixed-case/root obligations live. This repair
  chooses no processor or correction method. k39 re-presented both source/control
  questions; replies remain unavailable separately, with no human inspected
  path/defect/approval or actual “Not inspected yet”. Retain future actual
  replies explicitly, keeping historical geometry/preparation responses separate.
  k38 commissions human completion, no new Norwegian study. Do not treat a
  source-view reply as calibrated addressing or real staff uncertainty. The fixed
  16× grid remains failed; any genuinely changed music format/method still needs
  its own blind known-centre controls for actual observer classes before manual
  endpoints or dense marks. Automatic
  extraction-only diagnostics retain their existing independent scope/order.
  Historical geometry/preparation responses remain owned here separately.
- Consume k31/k34 and k35 plus its fresh planner's actual dispositions before
  this repair. Carry any source-instrument limitations into the music protocol
  without treating text-baseline success/failure as music-rule evidence. Keep
  unresolved Norwegian comparisons and their planner's precise next question
  for k28; this repair grants no Norwegian, control or preparation acceptance.
- Before dense marking, freeze the complete roster: five physical rules in
  each fitting unit T/B/D/I, with whole evaluation staffs A/E/H and the exact
  frozen exclusion rectangles. Ex.4 c first staff, Ex.6 and Ex.7 a–e remain
  untraced/not counted. No new fit staff is added to rescue this attempt;
  k28 owns any separately justified roster change. Derive a marking packet
  containing source/render identity, unmarked native patches, unit/rule ids,
  declared x-columns and source rectangles, with rejected y-values, old marks,
  repeats and coordinate-derived overlays stripped. The fresh first marker
  must never have received those coordinates; reading the historical evidence
  is the supervising/analysis context's job, not the marking context's.
- First retain the unchanged automatic extractor's complete line list on the
  selected page, with the same A/E/H whole-unit exclusions, full canvas,
  threshold/settings and exact native count/rounding/coverage diagnostics.
  Check physical-rule identities and exclusion leakage separately from numeric
  prerequisites. Verify an extraction-only instrument path before running it:
  the current C command writes a rigid image and continues into model fitting,
  so neither its `fit` nor `diagnostic` invocation meets this charter. A narrow
  source-only extraction path may reuse the pinned native functions; preserve
  historical command behaviour and reproduce the unchanged extraction steps.
  No model/default-validity conclusion follows from these coordinates. If
  physically verified automatic guides meet the acquisition prerequisites,
  stop before dense manual marking and hand k28 the changed automatic-acquisition
  question. A missing/unverified automatic diagnostic is an instrument/source
  prerequisite gap, not evidence that automatic extraction failed on page 20.
- If the manual question remains justified, observe only genuine first/last
  unobscured points of each declared fitting rule before its dense pass. Pass
  those extents through native .8 filtering and first-point count/coverage
  checks on the full canvas; retain observed endpoints, omitted/ambiguous ends,
  unique rule identities and retained list, especially lower unit I. Equal old
  x-extents are not observations. Inadequate/ambiguous physical extents or native
  coverage stop the dense pass with the exact acquisition/coverage question for
  k28. An endpoint gate pass is only eligibility to continue, not dense-source
  admissibility. Do not invent endpoints, crop, move holdouts or add fit units.
- State the hypothesis before marking: exact source-pixel addressing and
  unobscured native patches can remove the wide-strip centre/occlusion errors
  exposed by k26, while retaining sufficient physical guides after the same
  holdouts. This tests manual observation feasibility, not correction quality.
  Predeclare the failure comparison against k26's T/A/D/E/H/I maxima
  1/4/6/4/1.5/2.5 pixels and its recorded rise/curvature disagreements: recurrence
  of comparable errors, including the middle-band 4–6-pixel discrepancy pattern,
  fails to demonstrate removal of the historical marking error. Compare common
  unobscured columns/identities and disclose differences in repeat coverage;
  those old spot checks are a failure reference, not calibrated truth or a new
  acceptance threshold. Even reduced disagreement does not qualify if uncertainty
  cannot resolve the source's nonrigid variation. Reject invented, obscured or
  outside-rule observations. Absent/ambiguous centres, inadequate coverage,
  unresolved calibration and repeatable-but-too-coarse evidence are distinct
  inconclusive outcomes. Do not increase the old ±3-pixel assertion to admit it.
- Recheck source/render hashes and complete canvas. Start a genuinely fresh
  first pass from unmarked source patches. Native 1:1 pixels or labelled
  nearest-neighbour integer zoom must preserve exact pixel-centre addressing;
  retain each inspected patch's source rectangle, scale, identity and origin.
  No bicubic strip approximation, transfer of rejected y-values, pixel snapping,
  automatic centre extraction, interpolated gap or assumed five-line spacing
  may masquerade as a manually observed physical-rule point.
- Retain individual physical-rule identities and fit/evaluation roles, with
  source observations across upper/middle/lower and left/centre/right content.
  Declare dense sampling and obscured-gap handling before output: mark actual
  rule centres where visible, retain omitted/ambiguous columns and reasons,
  and distinguish display connectors from observations. Do not invent end
  points through notation or shorten long rules merely to pass filtering.
  Retain the prior whole-staff/system evaluation units A/E/H and their complete
  exclusion rectangles from the frozen record, without weakening or moving
  them to salvage coverage. Reconfirm their physical extent on the unchanged
  source; a discrepancy is a named prerequisite gap for k28, not permission
  to silently redraw holdouts. Admit fitting points only outside exclusions.
- Before any model/output exists, repeat a declared representative subset of
  whole rule traces in every band and both roles, in a fresh context that never
  received rejected or first-pass y-values, marks, coordinate lists or derived
  overlays. Supply only the coordinate-free roster, declared columns and
  unmarked source patches; record exactly what each observer received. Merely
  hiding a previously read list is not blindness. Retain both passes, common
  unobscured columns, disagreements, positional/slope/curvature differences,
  marker/method and the limits of measured repeatability. Report per-rule rise
  and curvature alongside those limits, including cross-rule slope variation
  and residual curvature that a common rigid angle cannot explain; raw page
  tilt alone is not a nonrigid effect. Separate repeatability from shared
  systematic error. A same-context repeat is a failure-detecting diagnostic
  only; even fresh-context same-observer/model agreement is not ground truth.
  Spot checks alone cannot establish dense-trace uncertainty. Where centres
  are ambiguous, record that fact rather than tune observations to agreement.
- Declare a point-by-point verification record for all fitting/evaluation
  observations: physical rule id, column, source patch/hash/rectangle, observed
  centre, verifier/method, accepted/ambiguous/invalid decision and reason. A
  verifier independent of the marker checks each point against native source;
  self-inspection and a sampled human response cannot verify the rest. Unverified
  points remain ineligible; disclose any sample and recheck whether its eligible
  subset still supplies the complete dense/whole-unit contract. Labelled
  synthetic known-centre patches may separately check addressing and observer
  bias, without seeding real marks or replacing manual observation. They cannot
  prove real-page accuracy; retain shared/systematic uncertainty and hand any
  unresolved bias or unavailable independent verification to k28. No automatic
  centroid/snapping estimator is commissioned as a substitute acquisition.
- Inspect full-page and native-patch source overlays against the unmarked
  source, including fitting as well as evaluation rules, in the verifier's
  context. Overlays may verify a frozen first pass before the repeat, but never
  enter the fresh repeat context. Declared omitted/ambiguous columns stay
  explicit before freeze. An invented/obscured/outside-rule point discovered
  after freeze voids the attempt; do not silently drop it, tune a mark or turn
  it into an omitted column. Retain the failed attempt for k28's repair question.
  Freeze complete admissibility decisions, both passes, uncertainty, exclusions,
  source/render
  identities and instrument digests before the final coordinate-only run.
  The record's hand-set admissibility flag may be true only after the linked
  per-point/per-rule verification and repeat/calibration evidence establish it;
  retain the derivation and unavailable evidence, not merely the boolean.
- Reuse/verify pinned Leptonica 1.87.0 semantics: native 0.8 longest-line
  filtering, unique physical-rule counts, fifteen retained long lines, native
  NUMA first-point rounding, at least four retained first points in each half,
  and full-height span strictly greater than 0.50. Report exact retained
  lists/coordinates, half counts/positions/span, nearest fit distances for each
  complete held-out unit and separation overlays. No duplicate traces, borrowed
  evaluation points, cropped canvas, relaxed gate, forced model or neighbour
  substitution is permitted. `dewarpFindVertDisparity` is the possible later
  trace entry, not a call made by this source-only trial.
- Record the first applicable outcome with later observations separate:
  unavailable instrument/source diagnostics prevents the corresponding decision;
  source-verified automatic prerequisite success changes the question and stops
  manual marking; otherwise invalid manual acquisition, insufficient genuine
  extent/separation/coverage, unresolved measurement/independent verification,
  repeatable but too coarse to resolve source nonrigidity, then admissible manual
  source evidence for considering the next trial. Record the human source-view
  reaction separately as received, missing or ambiguous; it does not change
  numerical admissibility or supply visual acceptance. A repeat that retains
  k26-scale disagreements or whose calibrated limits overlap the observed
  nonrigid variation does not reach
  admissible-for-trial evidence merely because its centres lie on rules.
  A gate pass alone proves neither physical admissibility nor vertical model
  support. On every outcome, hand k28 the exact remaining observation;
  do not automatically commission a fit, another marking pass, interpolation,
  a two-axis field or expanded music cases. Even successful acquisition still
  needs the complete same-page automatic/manual, rigid, independent output,
  control/sampler and human comparison governed by k20/k21.
- Present the new source overlay with this precise question: do the new marks
  follow genuine unobscured staff rules in the shown native patches, and which
  inspected rule/patch remains wrong or uncertain? Record inspected paths,
  response and ambiguity. Ask the historical questions separately: (geometry)
  do the music/control/rigid/forced-sampler views support rejecting the automatic
  page-140 extractor without a render/detail concern; (preparation) do the
  working-command pairs preserve music/faint marks, colour, margins, the whole
  Norwegian spread, Counterpoint landscape canvas, Algorithm Design and both
  assigned Strings covers? Reuse present views; if missing, reproduce exact
  views with verified recipes/manifests. Record each disposition separately,
  including “Not inspected yet” or unavailable; neither silence nor source
  approval supplies historical approval. Give k28 any defect/view and any exact
  unanswered response for its completion/repair decision.
- Keep originals untouched and all artifacts outside the collection. Extend
  the existing Taskfile only for actual reproducible source-acquisition needs;
  preserve historical recipes/wrappers, run new/changed and affected tasks,
  `geometry:staff-check` and `prepare:check`. Freeze every read subject before
  and after final runs with one writer/no mid-run edits; compare reruns item by
  item. Retain ordinary coordinates/patches/overlays/report and a durable note.

## Notes

k35 now records failure of all blind known-cell readings on its fixed 16×
grid/view_image method in `docs/experiments/norwegian-measurement.md` and its
linked observer/verification records. Each Norwegian half stops before real
marks, holdouts or masked extraction; source and output reactions remain
unavailable/unperformed as recorded, independently of historical views.
Read its fresh planner before this repair. Do not reuse that failed grid method
as calibrated music addressing or transfer synthetic errors to real staff
uncertainty. A changed music observation format/method still requires its own
known-centre controls and complete source verification under this charter.


This is a complete source-evidence slice. No matched automatic/manual model,
rigid/correction output, sampler or OCR is generated here, even on success.
The independent automatic Norwegian-gutter question is commissioned as k31
before this repair, regardless of music status; its fresh planner runs here
first. It cannot accept music or preparation. Production
representative cases, processor design and final acceptance remain outstanding.

Fresh observation contexts are part of the evidence protocol, not just relief
for session size. If they require separate Grove sessions, decompose lazily:
the first child delivers the complete baseline/extent decision and, if justified,
a frozen independently source-verified first-pass evidence handoff. A decisive
prerequisite failure or changed automatic question may close the source trial
with its explicit handoff. A first-pass-only child may finish that evidence
handoff but must state that overall acquisition is unfinished and unclassified;
keep concrete fresh-repeat/final-preflight/reaction children live inside k27,
ahead of k28, with coordinate-free observation packets. No setup/adapter-only
child is cut, no partial marks earn a fit, and the parent cannot close or report
admissible acquisition until repeatability, independent verification, final
preflight and the explicit reaction disposition are complete. Stop on a later
decisive failed prerequisite and carry every unperformed obligation to k28.
