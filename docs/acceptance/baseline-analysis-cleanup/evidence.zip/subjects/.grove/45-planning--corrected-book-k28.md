# corrected-book-k28


## Goal

Consume `staff-acquisition-k27` in fresh context on every outcome; commission
only the next justified geometry or response completion, then preserve the
complete default-processor and optional-appearance working increments.



## Context

Read the committed `corrected-book-k21` plan and `staff-acquisition-k27`
result/log/durable evidence. Read the full inherited decision contract in k21,
not just its running log: it owns the fixed representative cases and the
processor constraints carried below. k20/k26's rejected source records remain
historical diagnostics; k27 is the new observation, never a completed correction.
Read `corrected-book-k25`'s confirmed unchanged-fixture/gate and independent
gutter-sequencing policies, `docs/experiments/staff-guides.md`, k4's frozen
`docs/experiments/page-geometry.md` and `docs/research/scan-geometry-a.md`.
Read the full `.grove/20-k20/_staff-guides.md` comparison contract and
`corrected-book-k30`'s integration/confirmed ordering, together with any
`norwegian-gutter-k31` result and the fresh planning handoff it cuts before k27.
The committed `norwegian-gutter-k34` decision commissions source-only
`norwegian-measurement-k35` and its fresh planning consumer before k27 on every
outcome; read their complete contracts and actual result, not an assumed fit.
Read `norwegian-gutter-k37`'s classifications and any actual human policy replies.
It repairs k35's early addressing/frozen-mask checks and systematic-limit contract;
the review's universal right-half impossibility claim was not established.
Preparation's working contract/evidence are `docs/specs/prepared-pdf.md` and
`docs/acceptance/prepared-pdf.md`. k22 and k23 remain successor consumers.

## Done when

**Actual k44 working handoff and missing acceptance:** consume `page-review-k47`
→ `rigid-pages-k48` → `spread-pages-k49` → `book-placement-k50` and their actual
earned reviews/integrations and durable packets, not queued promises. These
complete useful supported technical slices can retire under the root's explicit
reaction-pending policy. This leaf owns every missing intermediate import-fidelity,
orientation/rigid/crop/split/book-placement and fixed-case visual response,
unavailable real numerical truth or defect/preservation remedy before k22/k23.
Known import detail loss remains failed preservation even with exact baseline
bytes; name its remedy/representation-policy question rather than granting a pass.
Retain complete within-page evidence/design extension/implementation and full
book-geometry acceptance here. No identical missing-response loop, initial-design
re-agreement, OCR/reordering subtree or Norwegian study is commissioned by k44.
This clause adds ownership; every current scope/protocol/criterion below remains.

**k52's repaired handoff:** k47 is now a node whose actual sequence is
`baseline-review-k53` -> `page-orientation-k54` before k48/k49/k50. Read both
complete handoffs, their earned reviews/packets and the unchanged node closure
criteria. Neither baseline export nor technical orientation retirement supplies
full geometry or source-native acceptance. Consume cross-stage project fixtures
and separate per-case fidelity outcomes. Real signed >300-ppi resolution loss
earns an actual policy consumer before image-edit dependents, not only here;
read that scoped answer/repair chain if it exists. No such loss or new signature
is inferred by the plan. This leaf still owns every unresolved real comparator/
reaction and full-default preservation remedy; colour/decoder/placement/<=300-ppi
detail defects are implementation repairs, never signed limitations. Preserve
all criteria and music/Norwegian/appearance/root ownership below.

**Latest human scope, before the inherited applicability clauses:** the tool
focuses on page and book geometry, including page alignment/matching and explicit
odd/even or left/right treatment. Processor reordering and OCR are external and
are no longer work/acceptance obligations despite historical wording below.
Consume k41's revised actual agreement and geometry-only working handoff. Preserve
all source occurrences/default order except genuine spread expansion, accepted
image review, book-side/group/parity/alignment semantics and image-only export
without stale old text. Retain full within-page evidence/representative acceptance
and all source protocols before k22/k23; the scope change approves no method.

The local applicability clauses below govern the two inherited production
bullets where they appear. Their original criteria remain intact: they bind
complete nonrigid commitment and its extension of k41, not another initial
intermediate design. Consume k43's clarification and k41's recorded human
signature, independent numerical/visual dispositions and review-state lifecycle.
An unsigned design is live work, and a numerical pass with reaction pending is
missing acceptance, not an accepted intermediate/full-default handoff. Retain
precise missing work before k22/k23; do not infer agreement from a retired leaf.

- Consume k40's commissioned `rotation-processor-k41` agreement and its ACTUAL
  planning/working successors, plus the planning review/integration, alongside
  k27's complete source result. The intermediate increment includes full-page
  render, supported rigid rotation with unknown distortion usable/flagged, safe
  borders/spread split, review and adjustment of any page, post-split decisions
  and accepted-image/aligned-English-OCR/export with its own acceptance. Its
  design may precede demonstrated nonrigid evidence under “agreed”; do not
  recommission the same initial processor design from older prerequisite wording.
  Once its design is agreed, its planner owns complete working slices, keeping
  representation/review/reader/export together. If its actual handoff lacks an
  agreed design or complete useful product, retain the precise missing work
  before k22; do not assume the queued design delivered it. All within-page,
  representative geometry/reaction and full-default criteria below remain owned
  here. The older representative-geometry prerequisites for production below
  govern complete nonrigid commitment; intermediate implementation requires its
  OWN complete rotation/preservation/review/assembly/OCR acceptance, not an
  assumed Norwegian or music correction. Extend/revise the coherent processor
  design from actual nonrigid evidence
  and obtain that agreement before its implementation planning. Intermediate
  rotation/preservation acceptance cannot accept unmeasured curvature, and a
  flag cannot satisfy correction. Appearance requires accepted complete default
  correction, not the intermediate alone. Commission no new Norwegian study
  without the separately justified explicit changed-observation choice, and no
  automatic identical response/planning loop. Pass every inherited obligation
  through ANY evidence/response completion to a fresh planner on EVERY outcome.

- Consume `norwegian-measurement-k38`'s actual human-completion plan,
  `geometry-policy-k39` and its fresh planning consumer `geometry-policy-k40`
  before using k27's result. k38 commissions no new Norwegian study or production method; k39
  obtains the exact two k37 policy choices and separate existing left/right
  source/control reactions. k39's first policy reply is “yes”: numerical source
  evidence admissibility and human source-view reaction have independent
  dispositions. Missing review does not veto otherwise verified numerical
  evidence, and numerical evidence grants no visual approval. The human replied
  “agreed” to considering an intermediate working processor that straightens
  rotation and flags unresolved distortion while nonrigid evidence continues.
  The fresh planner may consider that complete useful processor's design before
  demonstrated nonrigid correction; design agreement and its own acceptance
  still bind, and all within-page/fixed-case/root obligations remain live. k39
  re-presented the existing source/control questions independently; both replies
  remain unavailable, with no human inspected path/defect/approval or invented
  “Not inspected yet”. Preserve later actual replies explicitly and keep
  historical geometry/preparation's actual “Not inspected yet” separate. Policy
  approval supplies neither numerical source admissibility nor representative
  visual acceptance; a source reaction cannot erase the failed fixed-grid
  controls. Another instrument study needs its separately justified human choice
  of a genuinely changed selected-cell/readout observation and fresh blind
  exact-format controls before real marks, with all shared-baseline uncertainty
  and conditional comparison work retained. Do not recommission a same-grid
  trial or repeatedly cut the identical unanswered response completion.
- Classify k27 by its ordered source-only outcomes and retain automatic and
  manual acquisition separately. Check complete extraction-only automatic
  diagnostics, the declared T/B/D/I fit and A/E/H evaluation roster, genuine
  endpoint preflight, fresh-context provenance, per-point/per-rule independent
  source verification, exact prerequisite coverage/separation, repeatability,
  systematic uncertainty and per-rule rise/curvature; record the source-view
  reaction independently from numerical admissibility under k39's first choice.
  Automatic coordinate prerequisite success stops manual marking and earns a
  changed automatic-trial question; it does not establish default model validity.
  Admissible manual source evidence is only acquisition for a possible model
  trial, not supported correction;
  a numerical pass on invalid points proves neither. A failed native gate,
  ambiguous marks/repeatability, unresolved independent verification/bias,
  repeatable-but-too-coarse evidence, unavailable source response or unavailable
  instrument has its own precise observation-completion question. Compare
  recorded uncertainty against source nonrigidity rather than raw global tilt;
  reduced disagreement or a hand-set true flag alone cannot warrant a trial.
  No failed source result diagnoses model/sampler/two-axis quality. Do not automatically
  rerun the same acquisition; name the changed observation and falsifiable
  hypothesis before cutting any further completion. A roster change, including
  formerly untraced staffs, requires its own predeclared acquisition question;
  preserve complete A/E/H exclusions and unchanged gates. Fixture reselection
  stays within k25's six surveyed pages 20/40/60/100/180/220; 60/180 were not
  exhaustively preflight-rejected, so do not claim the pool exhausted from their
  visual nonselection. Leaving that pool needs a fresh human decision. No new
  fixture, changed roster or unconditional manual retry follows silently.
- If admissible acquisition warrants it, commission the complete bounded
  matched automatic/manual music trial on the same page 20 / printed 6,
  unchanged family/settings/whole-staff holdouts and fresh pre-output freeze.
  Retain automatic diagnostics on that fixture, actual model/default-validity
  status/field/application and fallback distinctions, rigid comparison,
  independently marked output geometry with measured uncertainty, detail/shape/
  clipping checks, verified control and nonidentity fractional sampler checks,
  and the user's separate traced-view reaction. k20's complete contract applies.
  A trace-input seam and its usable comparison belong together, not in a
  horizontal adapter-only leaf. Page 140 remains unsupported diagnostic;
  page-20 success cannot repair its automatic extraction or replace fixed cases.
- On any acquisition outcome, consume the independently sequenced
  `norwegian-gutter-k31` and its fresh planning result. Its k21/k25 question is:
  can the existing per-page vertical
  candidate improve both manually separated page-20 / printed-36–37 halves
  beyond rigid deskew at unchanged validity/native-sampler settings, preserving
  shape/detail and verified Algorithm Design page-20 control? Do not commission
  the same trial again merely because this charter previously retained permission
  for it. Keep exact per-half acquisition/coverage/model/application/measurement/
  reaction distinctions and any named completion; a further observation needs
  a changed falsifiable question and another fresh planner. Unsupported halves
  stay usable/flagged; no borrowed fit or forced validity. This independent
  result supplies no expansion/acceptance of music or preparation. Carry every
  unresolved obligation from k31 and its consumer alongside k27's handoff.
  Specifically consume k34's commissioned `norwegian-measurement-k35` result
  and its unconditional fresh planner before k27. Its exact changed observation
  is pixel-addressed native glyph anchoring with per-point independent source
  verification, blind whole-line repeats and measured shared systematic limits,
  predeclared exclusions and exact masked native prerequisites. Classify each
  half by actual instrument/acquisition/coverage/verification/systematic-limit/
  too-coarse/source-reaction evidence. A source-only success is no model or
  corrected result; failed or unavailable measurement earns only a precisely
  changed next observation, not the same viewer retry. Retain the complete
  conditional rigid/automatic vertical/default-validity/field/application/copy,
  independent output measurement beyond rigid, shape/faint-detail/clipping,
  verified control and nonidentity fractional native-sampler comparisons plus
  separate left/right/control human reactions. Missing output views mean those
  reactions are unperformed; k33 source/instrument silence is unavailable,
  distinct from historical geometry/preparation's “Not inspected yet”. No
  source result diagnoses native damage or a two-axis need, grants music/
  preparation acceptance or licenses production. Further completion still
  requires a changed falsifiable question and fresh planning on every outcome.
  Consume k37's ordering repair: a failed frozen-mask/native feasibility check
  stops that half before dense marking and retains all unperformed comparison
  work. Its result proves only that frozen attempt's outcome. An archived
  removal-only bound does not decide general masked re-extraction. Require
  exact-format addressing controls and positional glyph-class/sampling/JPEG/
  resampling limits; internal contrasts and repeat agreement alone do not
  establish baseline accuracy. A fixture change, different holdout concept or
  changed gate is a separately stated policy question, never a silent rescue.
  Respect k25's music pool permission/limits; Norwegian fixture/holdout/gate
  changes have no blanket permission from that music-only rule. Put any proposed
  contract change to the human with its evidence, while retaining the failed
  attempt and the independent half's obligations.
- Read k37 and k39's actual human policy dispositions before changing either
  dependency. The human answered “yes” to (a): measurement admissibility is
  separate from an unavailable source reaction, with no implied visual approval.
  All independent physical-source/calibration/systematic evidence requirements
  still bind, and k35's failed controls remain failed. The human answered
  “agreed” to (b): a rigid-plus-flagged intermediate processor may be considered
  while nonrigid evidence continues, before demonstrated nonrigid correction.
  This permits a design question, not a chosen method or production acceptance.
  Do not re-ask either settled policy or replace a missing visual response with
  another trial. Both choices still require processor design before
  implementation planning, the complete useful default handoff and its own
  evidence/reactions, with all within-page and fixed-case root criteria live.
- Obtain or retain precise response-completion work for the historical
  geometry and preparation views separately, using k27's recorded inspected
  paths/responses and the exact questions in its charter. “Not inspected yet”,
  silence or ambiguity grants no approval and invents no repair defect.
  A rejected view earns bounded defect-specific repair/recomparison ahead of
  its consumer. Present exact existing comparisons rather than rerendering
  absent a named missing artifact. Keep preparation approval separate from
  geometry/source approval, automated equality and code review.
- After ANY commissioned trial, acquisition/measurement/instrument completion
  or visual-response completion, cut a fresh planning consumer BEFORE
  `appearance-cleanup-k22`, on supported, rejected and inconclusive branches.
  Pass every unresolved obligation forward. Never let an unsupported music
  branch fall through to appearance or choose a larger model by availability.
  Alternative interpolation requires demonstrated native detail damage;
  two-axis correction requires observed width/barline failure after a valid
  applied vertical result. Otherwise commission the specific evidence gap.

**Applicability of the following representative-production criterion:** it
governs complete nonrigid production commitment. k41 and its actual successors
own the initial intermediate increment's separate rotation/preservation
acceptance. Its acceptance does not satisfy this representative geometry work.

- Before production commitment, independently assess and obtain reactions for
  all fixed k21 cases: Norwegian spread 20 (both gutters), Garbage Collection
  30 (indentation/glyphs/boxes/arrows), Counterpoint 20 (single landscape page,
  both columns), Fundamentals 40 (prose/faint detail), SchoenbergComposition
  cover 1 (colour/sparse rules/unsupported outcome), and verified Algorithm
  Design 20 (nondegradation plus nonzero fractional sampler). Retain original
  music 140's unresolved diagnostic/acceptance work. A selected music fixture
  does not replace any representative case; automatic extraction and manually
  supplied-guide success are different claims. No unknown threshold is invented.

**Applicability of the following processor-design criterion:** the initial
intermediate design is k41's. This later agreement extends/revises that coherent
design for evidence-supported within-page correction and complete default
acceptance, retaining every product criterion below; do not commission the same
initial design again. Agreement precedes that extension's implementation planner.

- Once correction/adjustment needs and representative acceptance support it,
  cut a processor design agreement and then its implementation-planning
  consumer before production. Preserve one useful default product increment:
  full-page render, genuine-spread splitting, safe border crop/warp, flagged
  review and adjustment of any page, accepted visible-image edits, post-split
  assembly decisions, final English OCR and exported searchable PDF. Its data
  representation and working reader/export land together; each implementation
  slice works independently with public-seam checks and docs. No schema-only,
  OCR-engine-only or test-only product staging is justified.
- The revised design/working acceptance preserves every complete accepted image,
  split-half provenance and default order in an ordinary image-only PDF, omitting
  earlier hidden text rather than retaining stale geometry. Blank/duplicate
  halves remain present for external removal/reordering. Verify book-side/group
  assignments, parity breaks, common canvas/margins and the agreed translation/
  scale policy through page-pair/group views and independent synthetic controls.
  No OCR engine or processor reordering implementation is commissioned.
- The processor receives one prepared or ordinary unmarked already-assembled
  PDF, optional advisory roles only, without collection discovery or reopening
  sources through hints. Covers and previously processed pages still receive
  geometry assessment. Keep colour/faint print/music/illustrations and already-
  correct pages, with safe default border removal. Demonstrate the actual
  collection-isolated public seam from working preparation to final export.
- Insert every default-processor prerequisite and earned review/repair before
  k22. Its optional preview/apply/revert whitening/noise-removal increment
  follows working default export and must cut planning/implementation before
  `workflow-acceptance-k23`. Keep k23 live for the whole root acceptance,
  including optional cleanup, and add missing scope before root closure.
  All working slices reconcile shared Taskfile/setup and `process:` tasks,
  verify new/changed and affected existing recipes including preparation,
  original digests, fixed subjects and human judgments. No separate workspace,
  cross-tree landing or driver launch is commissioned.

## Notes

Actual k35 handoff: each half fails the fixed 16× labelled-grid/view_image blind
addressing controls, before physical roster/holdout freeze or masked extraction.
Read `docs/experiments/norwegian-measurement.md`, every retained readback/error,
packet and its fresh planner. Do not reinterpret this as a native gate/model
failure, admit real coordinates, or repeat the same format by default. Both
source/instrument reactions are unavailable; real-anchor and correction views
were not generated, so those reactions are unperformed. k39 records the human's
“yes” to separate numerical evidence from visual source review and “agreed” to
consider a rigid-plus-flagged intermediate processor while nonrigid evidence
continues. k39 re-presented both existing source/control views at verified
identities; their replies remain unavailable separately, with no inspected
path/defect/approval inferred. No method, representative acceptance or root
completion follows. `geometry-policy-k40` before k27 consumes this exact result
and carries every inherited comparison/product obligation, rather than
automatically cutting another trial.


The current next music evidence is source acquisition only. k40 now commissions
k41's complete intermediate design before k27; its agreed artifact and actual
working handoff are consumed here, not assumed. The nonrigid field/confidence
policy and any additional adjustment needs remain evidence-dependent; revise
the coherent design when that question is concrete. This leaf must leave
actionable upstream work before k22 on every incomplete outcome, never treat
a retired experiment or intermediate flagged export as complete root geometry.
