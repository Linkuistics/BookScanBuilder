"""Retain measured subjects and outputs without chmod or following symlinks."""
import hashlib
import json
import os
import stat
import zipfile
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path.cwd()
out = repo / 'docs/acceptance/baseline-analysis-cleanup'
subjects = json.loads((base / 'final-a/subjects-before.json').read_text())
for name, wanted in subjects.items():
    source = Path(name)
    if not source.is_relative_to(repo):
        continue
    rel = source.relative_to(repo)
    if rel.parts[0] not in {'src','tests','experiments','.grove','docs'} and str(rel) not in {'Taskfile.yml','pyproject.toml','uv.lock','CONTEXT.md'}:
        continue
    raw = source.read_bytes()
    if str(rel) == '.grove/40-k47/01-k53/11-impl--baseline-finite-k63.md':
        raw = raw.split(b'\nFinal sequential readings agree itemwise on 3,331', 1)[0]
    assert hashlib.sha256(raw).hexdigest() == wanted['sha256'], str(rel)
    target = base / 'subjects' / rel
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(raw)

archive = out / 'evidence.zip'
entries = []
unreadable = []
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for path in sorted(base.rglob('*')):
        if '__pycache__' in path.parts:
            continue
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        rel = path.relative_to(base).as_posix()
        if stat.S_ISLNK(info.st_mode):
            raw = os.fsencode(os.readlink(path))
            kind = 'symlink'
        elif stat.S_ISREG(info.st_mode):
            try:
                raw = path.read_bytes()
            except PermissionError:
                unreadable.append({'path':rel,'mode':info.st_mode,'size':info.st_size})
                continue
            kind = 'file'
        else:
            raise AssertionError('Unexpected archive member: ' + rel)
        item = zipfile.ZipInfo(rel)
        item.create_system = 3
        item.external_attr = info.st_mode << 16
        item.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(item,raw)
        entries.append({'path':rel,'kind':kind,'mode':info.st_mode,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
index = {'format':'BookScanBuilderAnalysisCleanupEvidence','version':1,
         'archive':'evidence.zip','archive_size':archive.stat().st_size,
         'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
         'members':entries,'unreadable':unreadable,
         'measurement_root':str(base),'comparison':json.loads((base/'comparison.json').read_text())}
(out / 'index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'size':index['archive_size'],'sha256':index['archive_sha256'],'members':len(entries),'unreadable':unreadable},indent=2))
