"""Check copied analysis cleanup mutations without editing the live package."""
import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path.cwd()
rows = []
for label in ('predecessor', 'no-file-stamp', 'no-root-inventory', 'empty-identity-only'):
    root = base / label
    shutil.copytree(repo / 'src', root / 'src', ignore=shutil.ignore_patterns('__pycache__'))
    path = root / 'src/bookscan/analysis_workspace.py'
    text = path.read_text()
    selection = ''
    if label == 'predecessor':
        path = root / 'src/bookscan/native_setup.py'
        path.write_bytes((base / 'before/src/bookscan/native_setup.py').read_bytes())
        selection = 'changed_analysis_entries_are_preserved or unchanged_analysis_cleans'
    elif label == 'no-file-stamp':
        old = '                or stamp(self.path.lstat()) != self.file_stamp\n'
        assert text.count(old) == 1
        text = text.replace(old, '')
        old = '"whole.png", matches=lambda entry: stamp(entry) == self.file_stamp'
        assert text.count(old) == 1
        path.write_text(text.replace(old, '"whole.png", matches=lambda entry: True'))
    elif label == 'no-root-inventory':
        old = '                stamp(self.reservation.path.lstat()) != self.directory_stamp\n                or {entry.name for entry in self.reservation.path.iterdir()} != {"whole.png"}\n                or stamp(self.path.lstat()) != self.file_stamp\n'
        assert text.count(old) == 1
        path.write_text(text.replace(old, '                stamp(self.path.lstat()) != self.file_stamp\n'))
    else:
        old = '    with closing(\n        project_reservation.reserve(directory / (".analysis-" + uuid.uuid4().hex))\n    ) as reserved:\n'
        assert text.count(old) == 1
        path.write_text(text.replace(old, '    with project_reservation.reserve(directory / (".analysis-" + uuid.uuid4().hex)) as reserved:\n'))
    script = root / 'run.py'
    args = ['-q', str(repo / 'tests/test_analysis_cleanup.py'), '--junitxml=' + str(root / 'tests.xml')]
    if selection:
        args += ['-k', selection]
    script.write_text(
        'import sys,hashlib,json\nfrom pathlib import Path\n'
        + 'sys.path.insert(0,' + repr(str(root / 'src')) + ')\n'
        + 'from bookscan import native_setup, analysis_workspace, skew\n'
        + 'import pytest\n'
        + 'for module in [native_setup,analysis_workspace,skew]:\n'
        + ' p=Path(module.__file__);assert p.is_relative_to(Path(' + repr(str(root / 'src')) + '))\n'
        + ' print(json.dumps({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\n'
        + 'raise SystemExit(pytest.main(' + repr(args) + '))\n'
    )
    with (root / 'run.log').open('wb') as log:
        result = subprocess.run([sys.executable, str(script)], stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 1, (label, result.returncode)
    cases = list(ET.parse(root / 'tests.xml').iter('testcase'))
    assert cases and not any(c.find('error') is not None for c in cases)
    failed = [c.get('name') for c in cases if c.find('failure') is not None]
    passed = [c.get('name') for c in cases if c.find('failure') is None]
    rows.append({'case':label, 'mutated':str(path), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'failed':failed, 'passed':passed})
    print(label, len(failed), len(passed), flush=True)
(base / 'disproof.json').write_text(json.dumps(rows, indent=2) + '\n')
