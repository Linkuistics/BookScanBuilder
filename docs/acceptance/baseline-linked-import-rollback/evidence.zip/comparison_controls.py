"""Reject altered per-item evidence, rather than relying on equal totals."""
import copy,hashlib,json
from pathlib import Path
import compare
root=Path(__file__).resolve().parent
before=hashlib.sha256((root/'compare.py').read_bytes()).hexdigest()
original=compare.read
out=[]
for label in ['preparation','worker-reading','source-digest','worker-event']:
 def altered(path):
  value=original(path)
  if label=='preparation' and path==root/'final-b/preparation/report.json':
   value=copy.deepcopy(value);value['cases'][0]['name']='deliberately wrong case'
  if label=='worker-reading' and path==root/'final-b/source-workers/report.json':
   value=copy.deepcopy(value);value['cases'][0]['exit_code']=999
  if label=='source-digest' and path==root/'final-b/source-workers/initial-assets-complete-0.json':
   value=copy.deepcopy(value);value['event']['source']['source_sha256']='0'*64
  if label=='worker-event' and path==root/'final-b/source-workers/initial-assets-complete-0.json':
   value=copy.deepcopy(value);value['event']['writer_pid']=0
  return value
 compare.read=altered
 try:
  if label=='preparation':
   assert compare.checked_preparation(root/'final-a')==compare.checked_preparation(root/'final-b')
  else: compare.checked_workers(root/'final-b')
 except AssertionError:
  out.append(label)
 else: raise AssertionError('Wrong per-item record accepted: '+label)
 finally: compare.read=original
assert hashlib.sha256((root/'compare.py').read_bytes()).hexdigest()==before
result={'rejected_controls':out,'comparator_before_after_sha256':before}
(root/'comparison-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
