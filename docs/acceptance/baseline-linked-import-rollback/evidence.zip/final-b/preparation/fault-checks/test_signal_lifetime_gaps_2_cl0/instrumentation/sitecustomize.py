import os
from pathlib import Path
from writer_hooks import install
install('cleanup-error', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_cl0/barrier.json'))
