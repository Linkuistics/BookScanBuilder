import os
from pathlib import Path
from writer_hooks import install
install('after-link', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-b/preparation/fault-checks/test_sigkill_observes_state_an1/barrier.json'))
