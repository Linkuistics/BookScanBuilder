import os
from pathlib import Path
from writer_hooks import install
install('after-link', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-b/preparation/fault-checks/test_real_signals_at_observed_13/barrier.json'))
