import os
from pathlib import Path
from writer_hooks import install
os.umask(23)
install('writing', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-b/preparation/fault-checks/test_private_and_startup_umask0/barrier.json'))
