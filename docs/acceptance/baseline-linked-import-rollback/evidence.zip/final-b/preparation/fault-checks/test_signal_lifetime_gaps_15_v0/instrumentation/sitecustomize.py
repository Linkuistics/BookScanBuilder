import os
from pathlib import Path
from writer_hooks import install
install('validation', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-b/preparation/fault-checks/test_signal_lifetime_gaps_15_v0/barrier.json'))
