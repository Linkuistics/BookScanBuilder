import os
from pathlib import Path
from writer_hooks import install
install('after-open', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-b/preparation/fault-checks/test_signal_lifetime_gaps_2_af0/barrier.json'))
