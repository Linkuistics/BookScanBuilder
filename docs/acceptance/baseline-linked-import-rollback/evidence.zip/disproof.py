"""Disprove live changes through checked copies, never mutate measured originals."""
import json, shutil, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for case in ['predecessor','adopt-after-refusal','no-alias-transition-check','allow-extra-link']:
 root=base/case
 shutil.copytree(base/'before/src' if case=='predecessor' else repo/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
 if case=='adopt-after-refusal':
  for name,stamp in [('assets.py','_file_identity'),('native_blobs.py','_identity')]:
   p=root/'src/bookscan'/name;s=p.read_text()
   old='                                    expected,\n'
   assert s.count(old)==1
   p.write_text(s.replace(old,'                                    '+stamp+'(os.fstat(descriptor)),\n'))
 elif case=='no-alias-transition-check':
  p=root/'src/bookscan/import_publications.py';s=p.read_text()
  a=s.index('                if (\n',s.index('            for alias, before'))
  b=s.index('                self._files[alias] = after',a)
  p.write_text(s[:a]+s[b:])
 elif case=='allow-extra-link':
  p=root/'src/bookscan/import_publications.py';s=p.read_text()
  old='            or held.st_nlink != (1 if linked_name is None else 2)\n'
  assert s.count(old)==1;p.write_text(s.replace(old,''))
 script=root/'run.py'
 script.write_text('import sys,hashlib,json\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(root/'src'))+')\nfrom bookscan import initial_import,assets,native_blobs,import_publications\nimport pytest\nfor module in [initial_import,assets,native_blobs,import_publications]:\n p=Path(module.__file__);assert p.is_relative_to(Path('+repr(str(root/'src'))+'))\n print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)\nraise SystemExit(pytest.main(["-q",'+repr(str(repo/'tests/test_linked_import_rollback.py'))+',"--junitxml='+str(root/'tests.xml')+'"]))\n')
 with (root/'run.log').open('wb') as log:
  done=subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==1,(case,done.returncode)
 cases=list(ET.parse(root/'tests.xml').iter('testcase'))
 assert len(cases)==78 and not any(c.find('error') is not None for c in cases)
 failed=[c.get('name') for c in cases if c.find('failure') is not None]
 passed=[c.get('name') for c in cases if c.find('failure') is None]
 rows.append({'case':case,'exit':done.returncode,'failed':failed,'passed':passed})
 print(case,len(failed),len(passed),flush=True)
(base/'disproof.json').write_text(json.dumps(rows,indent=2)+'\n')
