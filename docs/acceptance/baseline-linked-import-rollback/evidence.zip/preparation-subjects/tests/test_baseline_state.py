"""An initial checkpoint cannot mix independently valid import contexts.

Constructed saved RGB tests persistence, not rendering fidelity. Coherent record
rehashes catch missing association checks; restart must use saved source/assets.
"""

import copy
import hashlib
import json
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any, cast

import pytest
from test_assessed_record import owner as owner
from test_assessed_record import state as assessed_fixture
from test_dependency_record import RENDERER
from test_dependency_record import literal as dependency_literal
from test_fontconfig_discovery_record import literal as discovery_literal
from test_fontconfig_discovery_record import snapshot_literal

from bookscan import ownership, project_header
from bookscan.ownership import Writer
from bookscan.project_header import Stores


@pytest.fixture
def evidence(owner: Writer, tmp_path: Path) -> tuple[Stores, dict[str, Any]]:  # noqa: F811
    build = cast(
        Callable[[Writer, Path], tuple[Stores, dict[str, object]]],
        getattr(assessed_fixture, "__wrapped__"),
    )
    stores, assessed = build(owner, tmp_path)
    dependencies, binding = dependency_literal()
    value: dict[str, Any] = dict(
        assessed, dependencies=dependencies, resource_binding=binding, fontconfig=None
    )
    for page in value["occurrences"]:
        page["render"]["command"][0] = RENDERER
        page["render"]["resource_binding"] = copy.deepcopy(binding)
    return stores, value


def configured(value: dict[str, Any], kind: str) -> None:
    discovery = snapshot_literal() if kind == "copy" else discovery_literal(cache=kind == "cache")
    # Production discovery captures the renderer graph and executable context.
    discovery = json.loads(json.dumps(discovery).replace("/historical/program", RENDERER))
    discovery["linked"]["executable_context"] = RENDERER
    if "resource_snapshot" in discovery:
        discovery["resource_snapshot"]["original"]["linked"]["executable_context"] = RENDERER
    value["dependencies"]["linked"]["pdftocairo"] = copy.deepcopy(discovery["linked"])
    binding = value["resource_binding"]
    names = {item["path"] for item in binding["files"]}
    binding["files"].extend(
        item for item in discovery["binding"]["files"] if item["path"] not in names
    )
    cast(list[dict[str, Any]], binding["files"]).sort(key=lambda item: item["path"])
    binding["directories"] = copy.deepcopy(discovery["binding"]["directories"])
    binding["fontconfig_scope_guard"] = copy.deepcopy(
        discovery["binding"]["fontconfig_scope_guard"]
    )
    value["fontconfig"] = discovery
    for page in value["occurrences"]:
        page["render"]["resource_binding"] = copy.deepcopy(binding)


def digest(domain: str, value: object) -> str:
    raw = json.dumps(
        {"domain": domain, "value": value},
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(raw).hexdigest()


@pytest.mark.parametrize("kind", ["absent", "scope", "cache", "copy"])
def test_initial_retention_has_no_review_or_ack_and_distinct_identities(
    evidence: tuple[Stores, dict[str, Any]],
    kind: str,
) -> None:
    from bookscan import baseline_state

    stores, value = evidence
    if kind != "absent":
        configured(value, kind)
    record = baseline_state.initial(stores, value)
    result = baseline_state.restore(stores, record)
    assert result.project_id == "project-" + stores.header.lock.token
    assert [page.core.id for page in result.occurrences] == [
        "occ-000001",
        "occ-000002",
        "occ-000003",
    ]
    assert result.occurrences[0].core.baseline == result.occurrences[1].core.baseline
    assert result.image_revisions[0] == result.image_revisions[1]
    assert result.snapshot_id != result.review_revision
    assert record["review"] == {
        "dispositions": [],
        "inspections": [],
        "acknowledgements": [],
        "retries": [],
    }
    assert result.fontconfig is None if kind == "absent" else result.fontconfig is not None
    assert "Historical" in result.limitations[0]
    assert record["snapshot_id"] == digest("BookScanBuilderExportSnapshot-v1", record["snapshot"])
    assert record["review_revision"] == digest(
        "BookScanBuilderReview-v1",
        {
            "project_id": record["project_id"],
            "import": value,
            "dispositions": [],
            "inspections": [],
        },
    )
    before = copy.deepcopy(record)
    value["occurrences"][0]["render"]["diagnostics"] = "changed externally"
    assert record == before and result.occurrences[0].render.diagnostics == "decoder café"


FAULTS = (
    "format",
    "version",
    "version-bool",
    "extra",
    "missing",
    "foreign-project",
    "review-digest",
    "snapshot-digest",
    "snapshot-fields",
    "image-revision",
    "disposition",
    "inspection",
    "acknowledgement",
    "retry",
    "review-extra",
    "missing-render-binding",
    "render-environment",
    "render-cwd",
    "render-native",
    "render-extra-file",
    "missing-discovery",
    "discovery-environment",
    "discovery-cwd",
    "discovery-native",
    "discovery-extra-file",
    "discovery-directory",
    "discovery-architecture",
    "discovery-build",
    "discovery-context",
    "orphan-discovery",
    "analysis-version",
    "scope-change",
    "tuple",
    "nan",
    "surrogate",
    "nonstring-key",
)


def corrupt(record: dict[str, Any], fault: str) -> None:
    if fault in ("format", "version", "version-bool", "foreign-project"):
        record[{"foreign-project": "project_id", "version-bool": "version"}.get(fault, fault)] = (
            True if fault == "version-bool" else 2 if fault == "version" else "foreign"
        )
    elif fault == "extra":
        record["accepted"] = True
    elif fault == "missing":
        del record["fontconfig"]
    elif fault in ("review-digest", "snapshot-digest"):
        record["review_revision" if fault == "review-digest" else "snapshot_id"] = "0" * 64
    elif fault == "snapshot-fields":
        record["snapshot"]["limitation"] = "verified"
    elif fault == "image-revision":
        record["image_revisions"][0] = "0" * 64
    elif fault in ("disposition", "inspection", "acknowledgement", "retry"):
        key = {
            "disposition": "dispositions",
            "inspection": "inspections",
            "acknowledgement": "acknowledgements",
            "retry": "retries",
        }[fault]
        record["review"][key] = [{"claimed": True}]
    elif fault == "review-extra":
        record["review"]["accepted"] = True
    elif fault == "missing-render-binding":
        del record["occurrences"][1]["render"]["resource_binding"]
    elif fault.startswith("render-"):
        binding = record["occurrences"][1]["render"]["resource_binding"]
        if fault == "render-environment":
            binding["environment_sha256"] = "1" * 64
        elif fault == "render-cwd":
            binding["working_directory_identity"] = [3, 4]
        elif fault == "render-native":
            binding["files"][0]["inode"] += 1
        else:
            binding["files"].append({**binding["files"][0], "path": "/zzz-extra"})
    elif fault == "missing-discovery":
        record["fontconfig"] = None
    elif fault.startswith("discovery-"):
        discovery = record["fontconfig"]
        binding = discovery["binding"]
        if fault == "discovery-environment":
            binding["environment_sha256"] = "1" * 64
        elif fault == "discovery-cwd":
            binding["working_directory_identity"] = [3, 4]
        elif fault == "discovery-native":
            binding["files"][0]["inode"] += 1
        elif fault == "discovery-extra-file":
            binding["files"].append({**binding["files"][0], "path": "/zzz-extra"})
        elif fault == "discovery-directory":
            binding["directories"][0]["entries"] = None
        else:
            discovery["linked"][
                {
                    "discovery-architecture": "architecture",
                    "discovery-build": "os_build",
                    "discovery-context": "executable_context",
                }[fault]
            ] = (
                "x86_64"
                if fault == "discovery-architecture"
                else "other"
                if fault == "discovery-build"
                else "/foreign/python"
            )
    elif fault == "orphan-discovery":
        del record["resource_binding"]["fontconfig_scope_guard"]
        for page in record["occurrences"]:
            del page["render"]["resource_binding"]["fontconfig_scope_guard"]
    elif fault == "analysis-version":
        record["occurrences"][0]["analysis"]["library_version"] = "future"
    elif fault == "scope-change":
        record["occurrences"][0]["render"]["resource_binding"]["fontconfig_scope_guard"]["scope"][
            "font_dirs"
        ] = []
    elif fault == "tuple":
        record["image_revisions"] = tuple(record["image_revisions"])
    elif fault == "nan":
        record["version"] = float("nan")
    elif fault == "surrogate":
        record["format"] = "\ud800"
    elif fault == "nonstring-key":
        cast(dict[object, object], record)[1] = "invalid"
    else:
        raise AssertionError(fault)


def reseal(record: dict[str, Any]) -> None:
    """Independently recompute declared identities after a semantic corruption."""
    value = {
        key: record[key]
        for key in (
            "source",
            "occurrences",
            "baselines",
            "native_blobs",
            "dependencies",
            "resource_binding",
            "fontconfig",
        )
    }
    record["review_revision"] = digest(
        "BookScanBuilderReview-v1",
        {
            "project_id": record["project_id"],
            "import": value,
            "dispositions": [],
            "inspections": [],
        },
    )
    for page, shown in zip(value["occurrences"], record["snapshot"]["pages"], strict=True):
        for key in ("geometry", "analysis", "triage_reasons"):
            shown[key] = copy.deepcopy(page[key])
    record["snapshot"]["toolchain"] = copy.deepcopy(value["dependencies"])
    record["snapshot_id"] = digest("BookScanBuilderExportSnapshot-v1", record["snapshot"])


@pytest.mark.parametrize("fault", FAULTS)
def test_rehashed_contradiction_never_becomes_accepted_state(
    evidence: tuple[Stores, dict[str, Any]],
    fault: str,
) -> None:
    from bookscan import baseline_state

    stores, value = evidence
    configured(value, "scope")
    record = baseline_state.initial(stores, value)
    corrupt(record, fault)
    if fault.startswith(("render-", "discovery-")) or fault in (
        "missing-render-binding",
        "missing-discovery",
        "orphan-discovery",
        "analysis-version",
        "scope-change",
    ):
        reseal(record)
    # The outer checkpoint writer may coherently rehash any corrupt payload.
    # It must still fail this semantic verifier, without changing saved bytes.
    before = copy.deepcopy(record)
    with pytest.raises(baseline_state.BaselineStateError) as caught:
        baseline_state.restore(stores, record)
    assert caught.value.code == "INVALID_PROJECT" and caught.value.exit_code == 3
    if fault != "nan":
        assert record == before


@pytest.mark.parametrize(
    "fault", ["valid", "render-native", "discovery-context", "acknowledgement"]
)
def test_source_loss_history_verifies_all_predecessors_and_releases_ownership(
    evidence: tuple[Stores, dict[str, Any]],
    fault: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from bookscan import baseline_state

    stores, value = evidence
    configured(value, "scope")
    record = baseline_state.initial(stores, value)
    prior = copy.deepcopy(record)
    if fault != "valid":
        corrupt(prior, fault)
        reseal(prior)
    previous = stores.checkpoints.commit(
        prior, expected=None, verify_state=lambda _: None
    ).checkpoint
    stores.checkpoints.commit(record, expected=previous, verify_state=lambda _: None)
    path = stores.owner.path
    stores.owner.close()
    before = {p.name: p.read_bytes() for p in (path / "checkpoints").iterdir()}

    def denied(*args: object, **kwargs: object) -> object:
        raise PermissionError("native launch forbidden")

    monkeypatch.setattr(subprocess, "Popen", denied)
    with pytest.raises(PermissionError):
        subprocess.Popen(["forbidden"])

    def verify(held: Stores, payload: dict[str, object]) -> None:
        baseline_state.restore(held, payload)

    if fault == "valid":
        with project_header.resume(path, verify_state=verify) as (_, current):
            assert current.revision == 2
    else:
        with pytest.raises(baseline_state.BaselineStateError):
            with project_header.resume(path, verify_state=verify):
                pytest.fail("Corrupt predecessor accepted")
    assert before == {p.name: p.read_bytes() for p in (path / "checkpoints").iterdir()}
    with ownership.Writer.acquire(path, stores.header.lock):
        pass


def test_caller_held_owner_and_selected_cancellation_are_preserved(
    evidence: tuple[Stores, dict[str, Any]],
) -> None:
    from bookscan import baseline_state

    stores, value = evidence
    record = baseline_state.initial(stores, value)
    with pytest.raises(ownership.OwnershipError) as busy:
        ownership.Writer.acquire(stores.owner.path, stores.header.lock)
    assert busy.value.code == "PROJECT_BUSY"
    selected = OSError("operation-owner selected cancellation")
    count = 0

    def cancel() -> None:
        nonlocal count
        count += 1
        if count == 7:
            raise selected

    with pytest.raises(OSError) as caught:
        baseline_state.restore(stores, record, check_cancel=cancel)
    assert caught.value is selected
    stores.verify()


@pytest.mark.parametrize("operation", ["initial", "restore"])
@pytest.mark.parametrize("boundary", [1, 7, 25])
def test_selected_domain_failure_keeps_exact_identity(
    evidence: tuple[Stores, dict[str, Any]],
    operation: str,
    boundary: int,
) -> None:
    from bookscan import baseline_state

    stores, value = evidence
    record = baseline_state.initial(stores, value)
    selected = baseline_state.BaselineStateError("Selected operation outcome")
    count = 0

    def cancel() -> None:
        nonlocal count
        count += 1
        if count == boundary:
            raise selected

    with pytest.raises(baseline_state.BaselineStateError) as caught:
        if operation == "initial":
            baseline_state.initial(stores, value, check_cancel=cancel)
        else:
            baseline_state.restore(stores, record, check_cancel=cancel)
    assert caught.value is selected
    stores.verify()
