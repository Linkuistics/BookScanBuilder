import sys,hashlib,json
from pathlib import Path
sys.path.insert(0,'/private/tmp/bookscan-linked-import.pFgKlV/adopt-after-refusal/src')
from bookscan import initial_import,assets,native_blobs,import_publications
import pytest
for module in [initial_import,assets,native_blobs,import_publications]:
 p=Path(module.__file__);assert p.is_relative_to(Path('/private/tmp/bookscan-linked-import.pFgKlV/adopt-after-refusal/src'))
 print(json.dumps({"imported":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
raise SystemExit(pytest.main(["-q",'/Users/antony/Development/BookScanBuilder/tests/test_linked_import_rollback.py',"--junitxml=/private/tmp/bookscan-linked-import.pFgKlV/adopt-after-refusal/tests.xml"]))
