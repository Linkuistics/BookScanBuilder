import os
from pathlib import Path
from writer_hooks import install
install('cleanup-interrupted', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-a/preparation/fault-checks/test_second_signal_cannot_inte1/barrier.json'))
