import os
from pathlib import Path
from writer_hooks import install
install('pre-region', Path('/private/tmp/bookscan-linked-import.pFgKlV/final-a/preparation/fault-checks/test_real_signals_at_observed_9/barrier.json'))
