"""Retain ordinary ZIP evidence; unreadable outputs keep their native permissions."""
import difflib,hashlib,json,os,stat,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent; repo=Path.cwd()
folder=repo/'docs/acceptance/baseline-linked-import-rollback';folder.mkdir(exist_ok=True)
entries={};unreadable=[]
def add(name,path):
 info=path.lstat()
 if stat.S_ISLNK(info.st_mode): data=os.fsencode(os.readlink(path))
 elif stat.S_ISREG(info.st_mode):
  try:data=path.read_bytes()
  except PermissionError:
   unreadable.append({'member':name,'source':str(path),'mode':info.st_mode,'device':info.st_dev,'inode':info.st_ino,'size':info.st_size,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns});return
 else:return
 entries[name]=(data,info.st_mode)
for name in ['red.log','red.xml','green.log','green.xml','green-2.log','green-2.xml','alias-boundaries.log','alias-boundaries.xml','complete.log','complete.xml','disproof.py','disproof.json','disproof.log','measure.py','compare.py','compare.log','comparison.json','comparison_controls.py','comparison-controls.json','comparison-controls.log','boundary.py','boundary.json','graph.json','archive.py','native-preflight.json','native-prior.json','preflight.log','helper-check.json','predecessor-evidence.log']:
 add(name,base/name)
for name in ['predecessor','adopt-after-refusal','no-alias-transition-check','allow-extra-link','final-a','final-b']:
 for path in sorted((base/name).rglob('*')):
  if '__pycache__' not in path.parts and (path.is_symlink() or not path.is_dir()): add(str(path.relative_to(base)),path)
for name in ['src/bookscan/assets.py','src/bookscan/native_blobs.py','src/bookscan/import_publications.py','Taskfile.yml']:
 add('before/'+name,base/'before'/name);add('after/'+name,repo/name)
 old=(base/'before'/name).read_text();new=(repo/name).read_text()
 entries['diff/'+name+'.diff']=(''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='before/'+name,tofile='after/'+name)).encode(),stat.S_IFREG|0o644)
add('after/tests/test_linked_import_rollback.py',repo/'tests/test_linked_import_rollback.py')
for reading in ['final-a','final-b']:
 report=json.loads((base/reading/'preparation/report.json').read_text())
 assert report['digests_before']==report['digests_after']
 for filename,digest in report['digests_before'].items():
  path=Path(filename)
  if path.is_relative_to(repo):
   assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
   add('preparation-subjects/'+str(path.relative_to(repo)),path)
entries['unreadable.json']=(json.dumps(unreadable,indent=2).encode()+b'\n',stat.S_IFREG|0o644)
archive=folder/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as saved:
 for name,(data,mode) in sorted(entries.items()):
  entry=zipfile.ZipInfo(name);entry.create_system=3;entry.external_attr=mode<<16;entry.compress_type=zipfile.ZIP_DEFLATED
  saved.writestr(entry,data)
index={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'measurement_root':str(base),'repository_root':str(repo),'members':{name:{'sha256':hashlib.sha256(data).hexdigest(),'size':len(data),'mode':mode} for name,(data,mode) in sorted(entries.items())},'unreadable':unreadable}
(folder/'index.json').write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'members':len(entries),'unreadable':unreadable}))
